<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BackpackTravelerInstagramHelper
 */
class BackpackTravelerInstagramHelper {
	/**
	 * Generates HTML for given image from Instagram feed. Defines backpacktraveler_instagram_image_atts filter
	 *
	 * @param $image associative array of image informations
	 * @param $imageSize image size that we want to show
	 *
	 * @return string generated HTML string
	 */
	public function getImageHTML( $image ) {
		$atts = '';
		
		$imageAtts = apply_filters( 'backpacktraveler_instagram_image_atts',
			array(
				'src'   => $this->getImageSrc( $image ),
				'alt'   => $this->getImageAlt( $image ),
			) );
		
		if ( is_array( $imageAtts ) && count( $imageAtts ) ) {
			foreach ( $imageAtts as $attName => $attValue ) {
				$atts .= $attName . '="' . $attValue . '" ';
			}
		}
		
		return '<img ' . $atts . ' />';
	}
	
	/**
	 * Returns URL to Instagram image
	 *
	 * @param        $imageArr associative array of image informations
	 * @param string $size image size that we want to show
	 *
	 * @return string URL to Instagram image
	 */
	public function getImageSrc( $imageArr ) {
		
		if ( isset( $imageArr['thumbnail_url'] ) ) {
			return $imageArr['thumbnail_url'];
		} else if ( isset( $imageArr['media_url'] ) ) {
			return $imageArr['media_url'];
		} else {
			return '';
		}
	}
	
	/**
	 * Returns image description
	 *
	 * @param $imageArr associative array of image informations
	 *
	 * @return string image alt text
	 */
	public function getImageAlt( $imageArr ) {
		
		if ( isset( $imageArr['caption'] ) ) {
			return $imageArr['caption'];
		} else {
			return '';
		}
	}
	
	/**
	 * Returns a link to instagram image
	 *
	 * @param $imageArr
	 *
	 * @return string
	 */
	public function getImageLink( $imageArr ) {

		if ( isset( $imageArr['permalink'] ) ) {
			return $imageArr['permalink'];
		} else {
			return '';
		}
	}

	public function getImageStatus( $imageArr ) {
		if ( array_key_exists( 'caption', $imageArr ) ) {



			$text = $imageArr['caption'];
			$maxchar = 88;
			$end = '...';

			if (strlen($text) > $maxchar || $text == '') {
				$words = preg_split('/\s/', $text);
				$output = '';
				$i      = 0;
				while (1) {
					$length = strlen($output)+strlen($words[$i]);
					if ($length > $maxchar) {
						break;
					}
					else {
						$output .= " " . $words[$i];
						++$i;
					}
				}
				$output .= $end;
			}
			else {
				$output = $text;
			}
			return $output;
		}

		return '';
	}

	public function getImageUser( $imageArr ) {

		if ( array_key_exists( 'username', $imageArr ) ) {
			return $imageArr['username'];
		}

		return '';
	}
}