<?php
/*
Plugin Name: BackpackTraveler Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Mikado Themes
Version: 2.1.2
*/
define('BACKPACKTRAVELER_INSTAGRAM_FEED_VERSION', '2.1.2');
define('BACKPACKTRAVELER_INSTAGRAM_ABS_PATH', dirname(__FILE__));
define('BACKPACKTRAVELER_INSTAGRAM_REL_PATH', dirname(plugin_basename(__FILE__ )));
define( 'BACKPACKTRAVELER_INSTAGRAM_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'BACKPACKTRAVELER_INSTAGRAM_ASSETS_PATH', BACKPACKTRAVELER_INSTAGRAM_ABS_PATH . '/assets' );
define( 'BACKPACKTRAVELER_INSTAGRAM_ASSETS_URL_PATH', BACKPACKTRAVELER_INSTAGRAM_URL_PATH . 'assets' );
define( 'BACKPACKTRAVELER_INSTAGRAM_SHORTCODES_PATH', BACKPACKTRAVELER_INSTAGRAM_ABS_PATH . '/shortcodes' );
define( 'BACKPACKTRAVELER_INSTAGRAM_SHORTCODES_URL_PATH', BACKPACKTRAVELER_INSTAGRAM_URL_PATH . 'shortcodes' );

include_once 'load.php';

if ( ! function_exists( 'backpacktraveler_instagram_theme_installed' ) ) {
    /**
     * Checks whether theme is installed or not
     * @return bool
     */
    function backpacktraveler_instagram_theme_installed() {
        return defined( 'MIKADO_ROOT' );
    }
}

if ( ! function_exists( 'backpacktraveler_instagram_elementor_installed' ) ) {
    /**
     * Checks whether elementor is installed or not
     * @return bool
     */
    function backpacktraveler_instagram_elementor_installed() {
        return defined('ELEMENTOR_VERSION');
    }
}

if ( ! function_exists( 'backpacktraveler_instagram_feed_text_domain' ) ) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function backpacktraveler_instagram_feed_text_domain() {
		load_plugin_textdomain( 'backpacktraveler-instagram-feed', false, BACKPACKTRAVELER_INSTAGRAM_REL_PATH . '/languages' );
	}
	
	add_action( 'plugins_loaded', 'backpacktraveler_instagram_feed_text_domain' );
}