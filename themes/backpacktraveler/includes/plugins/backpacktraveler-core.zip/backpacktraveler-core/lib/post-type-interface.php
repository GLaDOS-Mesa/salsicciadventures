<?php

namespace BackpackTravelerCore\Lib;

/**
 * interface PostTypeInterface
 * @package BackpackTravelerCore\Lib;
 */
interface PostTypeInterface {
	/**
	 * @return string
	 */
	public function getBase();
	
	/**
	 * Registers custom post type with WordPress
	 */
	public function register();
}