<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'backpacktraveler_core_add_google_maps_extensions' ) ) {
    function backpacktraveler_core_add_google_maps_extensions( $extensions ) {
        $items      = array(
            'geometry',
            'places'
        );
        $extensions = array_unique( array_merge( $extensions, $items ) );

        return $extensions;
    }

    add_filter( 'backpacktraveler_mikado_filter_google_maps_extensions_array', 'backpacktraveler_core_add_google_maps_extensions' );
}

if ( ! function_exists( 'backpacktraveler_core_enable_google_maps_in_admin' ) ) {
    function backpacktraveler_core_enable_google_maps_in_admin() {
        return true;
    }

    add_action( 'backpacktraveler_mikado_filter_google_maps_in_backend', 'backpacktraveler_core_enable_google_maps_in_admin' );
}

if ( ! function_exists( 'backpacktraveler_core_set_global_map_variables' ) ) {
    /**
     * Function for setting global map variables
     */
    function backpacktraveler_core_set_global_map_variables() {
        $global_map_variables = array();

        $global_map_variables['mapStyle']          = json_decode( backpacktraveler_mikado_options()->getOptionValue( 'destination_map_style' ) );
        $global_map_variables['scrollable']        = backpacktraveler_mikado_options()->getOptionValue( 'destination_maps_scrollable' ) == 'yes' ? true : false;
        $global_map_variables['draggable']         = backpacktraveler_mikado_options()->getOptionValue( 'destination_maps_draggable' ) == 'yes' ? true : false;
        $global_map_variables['streetViewControl'] = backpacktraveler_mikado_options()->getOptionValue( 'destination_maps_street_view_control' ) == 'yes' ? true : false;
        $global_map_variables['zoomControl']       = backpacktraveler_mikado_options()->getOptionValue( 'destination_maps_zoom_control' ) == 'yes' ? true : false;
        $global_map_variables['mapTypeControl']    = backpacktraveler_mikado_options()->getOptionValue( 'destination_maps_type_control' ) == 'yes' ? true : false;

        $global_map_variables = apply_filters( 'backpacktraveler_core_filter_js_global_map_variables', $global_map_variables );

        wp_localize_script( 'backpacktraveler-mikado-modules', 'mkdfMapsVars', array(
            'global' => $global_map_variables
        ) );
    }

    add_action( 'wp_enqueue_scripts', 'backpacktraveler_core_set_global_map_variables', 20 );
}

/* MULTIPLE MAP FUNCTIONS - START */
if ( ! function_exists( 'backpacktraveler_core_set_multiple_map_variables' ) ) {
    /**
     * Function for setting single map variables
     *
     * @param $query - $query is used just for multiple type. $query is Wp_Query args object containing destination items which should be presented on map
     * @param $return - whether map object should be returned (for ajax call) or passed to localize script
     *
     * @return array - array with addresses parameters
     */
    function backpacktraveler_core_set_multiple_map_variables( $query = '', $return = false ) {
        $map_variables = array();
        $items         = backpacktraveler_core_get_cpt_items( 'destination-item', $query );

        if ( ! empty( $items ) ) {
            foreach ( $items as $id => $title ) {
                $map_variables['addresses'][] = backpacktraveler_core_generate_destination_map_params( $id );
            }
        }

        if ( $return ) {
            return $map_variables;
        }

        wp_localize_script( 'backpacktraveler-mikado-modules', 'mkdfMultipleMapVars', array(
            'multiple' => $map_variables
        ) );
    }

    if( backpacktraveler_core_is_elementor_installed() ) {
        add_action('wp_enqueue_scripts', 'backpacktraveler_core_set_multiple_map_variables', 20);
    }
}

if ( ! function_exists( 'backpacktraveler_core_get_destination_multiple_map' ) ) {
    /**
     * Function that renders map holder for multiple destination item
     *
     * @param $query - $query is used just for multiple type. $query is Wp_Query object containing destination items which should be presented on map
     *
     * @return string
     */
    function backpacktraveler_core_get_destination_multiple_map( $query = '' ) {
        backpacktraveler_core_set_multiple_map_variables( $query );

        $html = '<div id="mkdf-destination-multiple-map-holder"></div>';

        do_action( 'backpacktraveler_core_action_after_destination_map' );

        return $html;
    }
}

/* MULTIPLE MAP FUNCTIONS - START */

/* MAP ITEMS FUNCTIONS START - */
if ( ! function_exists( 'backpacktraveler_core_marker_info_template' ) ) {
    /**
     * Template with placeholders for marker info window
     *
     * uses underscore templates
     */
    function backpacktraveler_core_marker_info_template() {

        $html = '<script type="text/template" class="mkdf-info-window-template">
				<div class="mkdf-info-window">
					<div class="mkdf-info-window-inner">
					    <a itemprop="url" class="mkdf-info-window-link" href="<%= itemUrl %>"></a>
						<% if ( featuredImage ) { %>
							<div class="mkdf-info-window-image">
							    <span class="icon_close"></span>
								<img itemprop="image" src="<%= featuredImage[0] %>" alt="<%= title %>" width="<%= featuredImage[1] %>" height="<%= featuredImage[2] %>">
							</div>
						<% } %>
						<div class="mkdf-info-window-details">
							<h6 itemprop="name" class="mkdf-info-window-title"><%= title %></h6>
							<p itemprop="name" class="mkdf-info-window-excerpt"><%= excerpt %></p>
						</div>
					</div>
				</div>
			</script>';

        print backpacktraveler_mikado_get_module_part($html);
    }

    add_action( 'backpacktraveler_core_action_after_destination_map', 'backpacktraveler_core_marker_info_template' );
}

if ( ! function_exists( 'backpacktraveler_core_marker_template' ) ) {
    /**
     * Template with placeholders for marker
     */
    function backpacktraveler_core_marker_template() {

        $html = '<script type="text/template" class="mkdf-marker-template">
				<div class="mkdf-map-marker">
					<div class="mkdf-map-marker-inner">
					<svg version="1.1" id="Layer_1" xmlns:x="&ns_extend;" xmlns:i="&ns_ai;" xmlns:graph="&ns_graphs;"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19.333px"
	 height="33.001px" viewBox="0 0 19.333 33.001" enable-background="new 0 0 19.333 33.001" xml:space="preserve">
<metadata>
	<sfw  xmlns="&ns_sfw;">
		<slices></slices>
		<sliceSourceBounds  width="18.611" height="31.841" y="-479.007" x="166.673" bottomLeftOrigin="true"></sliceSourceBounds>
	</sfw>
</metadata>
<path fill="#F3756A" stroke="#000000" stroke-miterlimit="10" d="M9.645,32.277c0,0-0.779-6.072-2.927-11.174
	c-2.069-4.916-5.879-6.435-5.879-11.298S4.782,1,9.645,1c4.863,0,8.806,3.942,8.806,8.806c0,3.197-2.194,5.05-4.077,8.446
	C14.374,18.252,9.589,26.451,9.645,32.277z"/>
<circle cx="9.698" cy="9.892" r="3.854"/>
</svg>
					</div>
				</div>
			</script>';

        print backpacktraveler_mikado_get_module_part($html);
    }

    add_action( 'backpacktraveler_core_action_after_destination_map', 'backpacktraveler_core_marker_template' );
}

/* MAP ITEMS FUNCTIONS - END */

/* HELPER FUNCTIONS - START */

if ( ! function_exists( 'backpacktraveler_core_generate_destination_map_params' ) ) {
    function backpacktraveler_core_generate_destination_map_params( $item_id ) {
        $map_params = array();

        //get destination image
        $image_id = get_post_thumbnail_id( $item_id );
        $image    = wp_get_attachment_image_src( $image_id, 'thumbnail' );

        //take marker pin
        $marker_pin = backpacktraveler_mikado_icon_collections()->renderIcon( 'icon_pin', 'font_elegant' );

        //get address params
        $address_array = backpacktraveler_core_get_address_params( $item_id );

        //excerpt length

        $excerpt_full = get_the_excerpt( $item_id );
        $charlength = 100;

        if ( mb_strlen( $excerpt_full ) > $charlength ) {
            $subex = mb_substr( $excerpt_full, 0, $charlength - 5 );
            $exwords = explode( ' ', $subex );
            $excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
            if ( $excut < 0 ) {
                $excerpt = mb_substr( $subex, 0, $excut );
            } else {
                $excerpt = $subex;
            }
            $excerpt .= '...';
        } else {
            $excerpt = $excerpt_full;
        }

        //Get item location
        if ( $address_array['address'] === '' && $address_array['address_lat'] === '' && $address_array['address_long'] === '' ) {
            $map_params['location'] = null;
        } else {
            $map_params['location'] = array(
                'address'   => $address_array['address'],
                'latitude'  => $address_array['address_lat'],
                'longitude' => $address_array['address_long']
            );
        }

        $cat_taxonomy = 'destination-category';
        $destination_cat_terms = get_terms($cat_taxonomy);

        $map_params['categories']    = '';
        if ( $destination_cat_terms && !is_wp_error( $destination_cat_terms ) ) :
                 foreach ( $destination_cat_terms as $term ) {
                    if(has_term( $term, 'destination-category', $item_id )) {
                        $map_params['categories'] .= '<a href="'.get_term_link($term->slug, $cat_taxonomy).'">'.$term->name .'</a>';
                    }
                 }
        endif;

        $map_params['title']         = get_the_title( $item_id );
        $map_params['excerpt']       = $excerpt;
        $map_params['itemId']        = $item_id;
        $map_params['markerPin']     = $marker_pin;
        $map_params['featuredImage'] = $image;
        $map_params['itemUrl']       = get_the_permalink( $item_id );

        return $map_params;
    }
}

if ( ! function_exists( 'backpacktraveler_core_get_address_params' ) ) {
    /**
     * Function that set up address params
     *
     * @param $id - id of current post
     *
     * @return array
     */
    function backpacktraveler_core_get_address_params( $id ) {
        $address_array  = array();
        $address_string = get_post_meta( $id, 'mkdf_destination_single_full_address_meta', true );
        $address_lat    = get_post_meta( $id, 'mkdf_destination_single_full_address_latitude_meta', true );
        $address_long   = get_post_meta( $id, 'mkdf_destination_single_full_address_longitude_meta', true );

        $address_array['address']      = $address_string !== '' ? $address_string : '';
        $address_array['address_lat']  = $address_lat !== '' ? $address_lat : '';
        $address_array['address_long'] = $address_long !== '' ? $address_long : '';

        return $address_array;
    }
}

/* HELPER FUNCTIONS - END */