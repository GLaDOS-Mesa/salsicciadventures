<?php if(backpacktraveler_mikado_options()->getOptionValue('destination_single_hide_pagination') !== 'yes') : ?>
    <?php
    $nav_same_category = backpacktraveler_mikado_options()->getOptionValue('destination_single_nav_same_category') == 'yes';
    $imgPrev = get_the_post_thumbnail(get_previous_post(),array( 53, 53));
    $imgNext = get_the_post_thumbnail(get_next_post(), array(53,53));
    ?>
    <div class="mkdf-ps-navigation">
        <?php if(get_previous_post() !== '') : ?>
            <div class="mkdf-ps-prev">
                <?php if($nav_same_category) {
                    echo wp_kses_post($imgPrev);
	                previous_post_link('%link','<span class="mkdf-ps-nav-label">'.esc_html__('Previous Destination','backpacktraveler-core').'</span>', true, '', 'destination-category');
                } else {
                    echo wp_kses_post($imgPrev);
	                previous_post_link('%link','<span class="mkdf-ps-nav-label">'.esc_html__('Previous Destination','backpacktraveler-core').'</span>');
                } ?>
            </div>
        <?php endif; ?>

        <?php if(get_next_post() !== '') : ?>
            <div class="mkdf-ps-next">
                <?php if($nav_same_category) {
                    next_post_link('%link', '<span class="mkdf-ps-nav-label">'.esc_html__('Next Destination','backpacktraveler-core').'</span>', true, '', 'destination-category');
                    echo wp_kses_post($imgNext);
                } else {
                    next_post_link('%link', '<span class="mkdf-ps-nav-label">'.esc_html__('Next Destination','backpacktraveler-core').'</span>');
                    echo wp_kses_post($imgNext);
                } ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>