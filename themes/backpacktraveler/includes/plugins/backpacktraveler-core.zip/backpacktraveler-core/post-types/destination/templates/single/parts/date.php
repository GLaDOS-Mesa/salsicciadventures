<?php if(backpacktraveler_mikado_options()->getOptionValue('destination_single_hide_date') === 'yes') : ?>
    <div class="mkdf-ps-info-item mkdf-ps-date">
        <p itemprop="dateCreated" class="mkdf-ps-info-date entry-date updated"><?php the_time(get_option('date_format')); ?></p>
        <meta itemprop="interactionCount" content="UserComments: <?php echo get_comments_number(backpacktraveler_mikado_get_page_id()); ?>"/>
    </div>
<?php endif; ?>