<?php

class BackpackTravelerCoreElementorDestinationCategoryList extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_destination_category_list';
    }

    public function get_title() {
        return esc_html__( 'Destination Category List', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-destination-category-list';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'number_of_columns',
            [
                'label'   => esc_html__( 'Number of Columns', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_number_of_columns_array( true, array( 'one' ) ),
                'default' => 'three'
            ]
        );

        $this->add_control(
            'space_between_items',
            [
                'label'   => esc_html__( 'Space Between Items', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_space_between_items_array(),
                'default' => 'normal'
            ]
        );

        $this->add_control(
            'number_of_items',
            [
                'label'   => esc_html__( 'Number of Items Per Page', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Set number of items for your destination category list. Default value is 6', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'   => esc_html__( 'Order By', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_by_array(false, array(), true),
                'default' => 'date'
            ]
        );

        $this->add_control(
            'order',
            [
                'label'   => esc_html__( 'Order', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_array(),
                'default' => 'ASC'
            ]
        );

        $this->add_control(
            'image_proportions',
            [
                'label'   => esc_html__( 'Image Proportions', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'full' => esc_html__( 'Original', 'backpacktraveler-core' ),
                    'square' => esc_html__( 'Square', 'backpacktraveler-core' ),
                    'landscape' => esc_html__( 'Landscape', 'backpacktraveler-core' ),
                    'portrait' => esc_html__( 'Portrait', 'backpacktraveler-core' ),
                    'medium' => esc_html__( 'Medium', 'backpacktraveler-core' ),
                    'large' => esc_html__( 'Large', 'backpacktraveler-core' ),
                ],
                'default' => 'full'
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'   => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_title_tag(true),
                'default' => 'h4'
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'number_of_columns'   => 'three',
            'space_between_items' => 'normal',
            'number_of_items'     => '6',
            'orderby'             => 'date',
            'order'               => 'ASC',
            'image_proportions'   => 'full',
            'title_tag'           => 'h4'
        );

        $params = shortcode_atts( $args, $params );

        $query_array              = $this->getQueryArray( $params );
        $params['query_results']  = get_terms( $query_array );
        $params['holder_classes'] = $this->getHolderClasses( $params, $args );
        $params['image_size']     = $this->getImageSize( $params );
        $params['title_tag']      = ! empty( $params['title_tag'] ) ? $params['title_tag'] : $args['title_tag'];

        echo backpacktraveler_core_get_cpt_shortcode_module_template_part( 'destination', 'destination-category-list', 'destination-category-holder', '', $params );
    }

    public function getQueryArray( $params ) {
        $query_array = array(
            'taxonomy'   => 'destination-category',
            'number'     => $params['number_of_items'],
            'orderby'    => $params['orderby'],
            'order'      => $params['order'],
            'hide_empty' => true
        );

        return $query_array;
    }

    public function getHolderClasses( $params, $args ) {
        $classes = array();

        $classes[] = ! empty( $params['number_of_columns'] ) ? 'mkdf-' . $params['number_of_columns'] . '-columns' : 'mkdf-' . $args['number_of_columns'] . '-columns';
        $classes[] = ! empty( $params['space_between_items'] ) ? 'mkdf-' . $params['space_between_items'] . '-space' : 'mkdf-' . $args['space_between_items'] . '-space';

        return implode( ' ', $classes );
    }

    public function getImageSize( $params ) {
        $thumb_size = 'full';

        if ( ! empty( $params['image_proportions'] ) ) {
            $image_size = $params['image_proportions'];

            switch ( $image_size ) {
                case 'landscape':
                    $thumb_size = 'backpacktraveler_mikado_image_landscape';
                    break;
                case 'portrait':
                    $thumb_size = 'backpacktraveler_mikado_image_portrait';
                    break;
                case 'square':
                    $thumb_size = 'backpacktraveler_mikado_image_square';
                    break;
                case 'medium':
                    $thumb_size = 'medium';
                    break;
                case 'large':
                    $thumb_size = 'large';
                    break;
                case 'full':
                    $thumb_size = 'full';
                    break;
            }
        }

        return $thumb_size;
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorDestinationCategoryList() );