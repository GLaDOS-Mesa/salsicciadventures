<?php
$content_styles = $this_object->getStandardContentStyles($params);
?>

<a itemprop="url" href="<?php echo esc_url( $this_object->getItemLink() ); ?>" target="<?php echo esc_attr( $this_object->getItemLinkTarget() ); ?>">
<?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/image', $item_style, $params); ?>
</a>

<div class="mkdf-pli-text-holder" <?php backpacktraveler_mikado_inline_style($content_styles); ?>>
	<div class="mkdf-pli-text-wrapper">
		<div class="mkdf-pli-text">
            <?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/additional-image', $item_style, $params); ?>

            <?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/title', $item_style, $params); ?>

			<?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/category', $item_style, $params); ?>

            <?php echo backpacktraveler_mikado_get_button_html(array(
                'link' => get_permalink(get_the_ID()),
                'text' => esc_html__('Explore', 'backpacktraveler-core'),
                'type' => 'outline',
            )); ?>

        </div>
	</div>
</div>