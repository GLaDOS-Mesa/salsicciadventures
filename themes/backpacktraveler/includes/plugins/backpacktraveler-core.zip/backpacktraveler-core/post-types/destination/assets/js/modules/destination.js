(function($) {
    'use strict';

    var destination = {};
    mkdf.modules.destination = destination;
	
    destination.mkdfOnWindowLoad = mkdfOnWindowLoad;
    destination.mkdfOnDocumentReady = mkdfOnDocumentReady;

    destination.mkdfBindTitles = mkdfBindTitles;
    destination.mkdfReinitMultipleGoogleMaps = mkdfReinitMultipleGoogleMaps;

    $(window).on('load',mkdfOnWindowLoad);
	
	/*
	 All functions to be called on $(window).load() should be in this function
	 */
	function mkdfOnWindowLoad() {
		mkdfDestinationSingleFollow().init();
	}

    function mkdfOnDocumentReady() {
        mkdfBindTitles();
    }
	
	var mkdfDestinationSingleFollow = function () {
		var info = $('.mkdf-follow-destination-info .mkdf-destination-single-holder .mkdf-ps-info-sticky-holder');
		
		if (info.length) {
			var infoHolder = info.parent(),
				infoHolderOffset = infoHolder.offset().top,
				infoHolderHeight = infoHolder.height(),
				mediaHolder = $('.mkdf-ps-image-holder'),
				mediaHolderHeight = mediaHolder.height(),
				header = $('.header-appear, .mkdf-fixed-wrapper'),
				headerHeight = (header.length) ? header.height() : 0,
				constant = 30; //30 to prevent mispositioned
		}
		
		var infoHolderPosition = function () {
			if (info.length && mediaHolderHeight >= infoHolderHeight) {
				if (mkdf.scroll >= infoHolderOffset - headerHeight - mkdfGlobalVars.vars.mkdfAddForAdminBar - constant) {
					var marginTop = mkdf.scroll - infoHolderOffset + mkdfGlobalVars.vars.mkdfAddForAdminBar + headerHeight + constant;
					// if scroll is initially positioned below mediaHolderHeight
					if (marginTop + infoHolderHeight > mediaHolderHeight) {
						marginTop = mediaHolderHeight - infoHolderHeight + constant;
					}
					info.stop().animate({
						marginTop: marginTop
					});
				}
			}
		};
		
		var recalculateInfoHolderPosition = function () {
			if (info.length && mediaHolderHeight >= infoHolderHeight) {
				//Calculate header height if header appears
				if (mkdf.scroll > 0 && header.length) {
					headerHeight = header.height();
				}
				
				var headerMixin = headerHeight + mkdfGlobalVars.vars.mkdfAddForAdminBar + constant;
				if (mkdf.scroll >= infoHolderOffset - headerMixin) {
					if (mkdf.scroll + infoHolderHeight + headerMixin + 2 * constant < infoHolderOffset + mediaHolderHeight) {
						info.stop().animate({
							marginTop: (mkdf.scroll - infoHolderOffset + headerMixin + 2 * constant)
						});
						//Reset header height
						headerHeight = 0;
					} else {
						info.stop().animate({
							marginTop: mediaHolderHeight - infoHolderHeight
						});
					}
				} else {
					info.stop().animate({
						marginTop: 0
					});
				}
			}
		};
		
		return {
			init: function () {
				infoHolderPosition();
				$(window).scroll(function () {
					recalculateInfoHolderPosition();
				});
			}
		};
	};

    function mkdfBindTitles() {

        var maps = $('.mkdf-ds-archive-map-holder'),
            lists = $('.mkdf-ds-archive-items');

        if (maps.length && lists.length){
            maps.each(function(){

                $(this).mouseenter(function () {

                });
                var  listItems = lists.find('.mkdf-ds-item');

                listItems.each(function(){
                    var listItem = $(this);
                    listItem.mouseenter(function(){
                        var itemId = listItem.attr('id');
                        if ($('.mkdf-map-marker-holder').length) {
                            $('.mkdf-map-marker-holder').each(function(){
                                var markerHolder = $(this),
                                    markerId = markerHolder.attr('id');
                                if (itemId == markerId) {
                                    markerHolder.addClass('active');
                                    setTimeout(function(){
                                    },300);
                                } else {
                                    markerHolder.removeClass('active');
                                }
                            });
                        }
                    });
                });

                lists.mouseleave(function(){
                    $('.mkdf-map-marker-holder').removeClass('active');
                });
            });
        }
    }

    function mkdfReinitMultipleGoogleMaps(addresses, action){

        if(action === 'append'){

            var mapObjs = mkdfMultipleMapVars.multiple.addresses;
            mapObjs = mkdfMultipleMapVars.multiple.addresses.concat(addresses);
            mkdfMultipleMapVars.multiple.addresses = mapObjs;

            mkdf.modules.maps.mkdfGoogleMaps.getDirectoryItemsAddresses({
                addresses: mapObjs
            });
        }
        else if(action === 'replace'){

            mkdfMultipleMapVars.multiple.addresses = addresses;
            mkdf.modules.maps.mkdfGoogleMaps.getDirectoryItemsAddresses({
                addresses: addresses
            });

        }
    }

})(jQuery);