<div class="mkdf-container">
    <div class="mkdf-container-inner clearfix">
        <div class="mkdf-grid-row">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="mkdf-grid-col-12">
                <div class="mkdf-ps-image-inner">
                    <?php
                    $media = backpacktraveler_core_get_destination_single_media();
                    if(is_array($media) && count($media)) : ?>
                        <?php if(count($media) > 1) { ?>
                            <div class="mkdf-ps-image-inner mkdf-owl-slider">
                        <?php } ?>
                            <?php foreach($media as $single_media) : ?>
                                <div class="mkdf-ps-image">
                                    <?php backpacktraveler_core_get_destination_single_media_html($single_media); ?>
                                </div>
                            <?php endforeach; ?>
                        <?php if(count($media) > 1) { ?>
                            </div>
                        <?php } ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mkdf-destination-single-holder mkdf-grid-col-9 <?php echo esc_attr($holder_classes); ?>">
                <?php if(post_password_required()) {
                    echo get_the_password_form();
                } else {
                    do_action('backpacktraveler_mikado_action_destination_page_before_content');

                    backpacktraveler_core_get_cpt_single_module_template_part('templates/single/layout-collections/'.$item_layout, 'destination', '', $params);

                    do_action('backpacktraveler_mikado_action_destination_page_after_content');

                    //get destination categories section
                    backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/categories', 'destination', $item_layout);
                    backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/like', 'destination', $item_layout);
                    backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/comments-info', 'destination', $item_layout);

                } ?>
                <div class="mkdf-destination-info-bottom clearfix">
                    <div class="mkdf-destination-info-bottom-left">
                        <?php backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/author', 'destination', $item_layout); ?>
                    </div>
                    <div class="mkdf-destination-info-bottom-center">
                        <?php backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/social', 'destination', $item_layout); ?>
                    </div>
                    <div class="mkdf-destination-info-bottom-right">

                        <?php backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/date', 'destination', $item_layout); ?>
                    </div>
                </div>
                <?php
                backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/navigation', 'destination', $item_layout);

                backpacktraveler_core_get_cpt_single_module_template_part( 'templates/single/parts/author-info', 'destination' );

                backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/comments', 'destination');
                ?>
            </div>
            <?php endwhile; endif; ?>
            <div class="mkdf-sidebar-holder mkdf-grid-col-3">
                <aside class="mkdf-sidebar">
                    <div class="mkdf-single-destination-sidebar">
                        <?php
                        $additional_image = get_post_meta( get_the_ID(), 'destination_second_featured_image', true ); ?>
                        <?php if($additional_image !== '') { ?>
                        <img itemprop="image" class="mkdf-destination-additional-image" src="<?php echo esc_url($additional_image); ?>" alt="<?php esc_attr_e('Destination Additional Image', 'backpacktraveler-core'); ?>" />
                        <?php } ?>
                        <span class="mkdf-ps-item-title"><?php the_title(); ?></span>
                        <?php
                        $args2 = array(
                            'post_type' => 'post',
                            'meta_query' => array(
                                'relation' => 'AND',
                                array(
                                    'key' => 'mkdf_assign_destination_blog_meta',
                                    'value' => get_the_ID(),
                                    'compare' => '='
                                ),
                                array(
                                    'relation' => 'OR',
                                    array(
                                        'key' => 'mkdf_enable_assign_destination_blog_meta',
                                        'compare' => 'NOT EXISTS'
                                    ),
                                    array(
                                        'key' => 'mkdf_enable_assign_destination_blog_meta',
                                        'value' => 'yes',
                                        'compare' => '='
                                    ),
                                )
                            ),
                            'posts_per_page' => -1,
                        );
                        $count = 0;
                        $loop = new WP_Query($args2);
                        while ( $loop->have_posts() ) : $loop->the_post();
                            $count++;
                        endwhile;
                        wp_reset_postdata(); ?>
                        <span class="mkdf-ds-posts-count"><?php print backpacktraveler_mikado_get_module_part($count).esc_html__(' related articles', 'backpacktraveler-core'); ?></span>
                        <div class="mkdf-destination-sidebar-button">
                            <?php
                            $ids = backpacktraveler_mikado_options()->getOptionValue('destination_posts_page');
                            $url = get_permalink($ids);
                            $url = add_query_arg( 'destination-id', get_the_ID(), $url );
                            ?>
                            <?php echo backpacktraveler_mikado_get_button_html(array(
                                'link' => $url,
                                'size' => 'small',
                                'text' => esc_html__('See Articles', 'backpacktraveler-core'),
                                'type' => 'outline',
                            )); ?>
                        </div>
                    </div>
                    <?php
                    //get destination custom fields section
                    backpacktraveler_core_get_cpt_single_module_template_part('templates/single/parts/custom-fields', 'destination', $item_layout);
                    ?>
                </aside>
            </div>
        </div>
    </div>
</div>