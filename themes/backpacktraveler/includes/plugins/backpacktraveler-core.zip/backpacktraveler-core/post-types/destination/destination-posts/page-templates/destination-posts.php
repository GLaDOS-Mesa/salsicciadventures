<?php
/*
Template Name: Destination Posts
*/
?>
<?php
$mkdf_sidebar_layout = backpacktraveler_mikado_sidebar_layout();
$dest_id = $_GET['destination-id'];

if ( function_exists('icl_object_id') ) {
	$lang = ICL_LANGUAGE_CODE;
	$dest_id = apply_filters( 'wpml_object_id', $dest_id, 'destination-item' , true, $lang );
}

get_header();
backpacktraveler_mikado_get_title();
get_template_part( 'slider' );
do_action('backpacktraveler_mikado_action_before_main_content');
?>

    <div class="mkdf-container">
        <?php do_action( 'backpacktraveler_mikado_action_after_container_open' ); ?>
        <div class="mkdf-container-inner">
            <?php do_action( 'backpacktraveler_mikado_action_after_container_inner_open' ); ?>
            <div class="mkdf-blog-holder mkdf-blog-masonry mkdf-blog-pagination-standard mkdf-grid-list mkdf-grid-masonry-list mkdf-three-columns mkdf-normal-space mkdf-blog-masonry-in-grid" data-blog-type="masonry" data-next-page="2" data-max-num-pages="1" data-post-number="10" data-excerpt-length="40">
            <div class="mkdf-blog-holder-inner mkdf-outer-space mkdf-masonry-list-wrapper">
            <div class="mkdf-masonry-grid-sizer"></div>
            <div class="mkdf-masonry-grid-gutter"></div>
            <?php
            $args = array(
                'post_type' => 'post',
                'meta_query' => array(
                    'relation' => 'AND',
                    array(
                        'key' => 'mkdf_assign_destination_blog_meta',
                        'value' => $dest_id,
                        'compare' => '='
                    ),
                    array(
                        'relation' => 'OR',
                        array(
                            'key' => 'mkdf_enable_assign_destination_blog_meta',
                            'compare' => 'NOT EXISTS'
                        ),
                        array(
                            'key' => 'mkdf_enable_assign_destination_blog_meta',
                            'value' => 'yes',
                            'compare' => '='
                        ),
                    ),
                ),
                'posts_per_page' => -1,
            );
            $destination_posts_query = new WP_Query($args);
            while ( $destination_posts_query->have_posts() ) : $destination_posts_query->the_post();?>
                <?php
                backpacktraveler_mikado_get_post_format_html( 'masonry' );
                ?>

            <?php
            endwhile;
            wp_reset_postdata();
            ?>
            <?php do_action( 'backpacktraveler_mikado_action_before_container_inner_close' ); ?>
            </div></div>
        </div>

        <?php do_action( 'backpacktraveler_mikado_action_before_container_close' ); ?>
    </div>

<?php get_footer(); ?>