<?php
$image_src   = get_the_post_thumbnail_url( get_the_ID() );
$image_style = ! empty( $image_src ) ? 'background-image:url(' . esc_url( $image_src ) . ')' : '';
$categories  = wp_get_post_terms(get_the_ID(), 'destination-category');
$tags        = wp_get_post_terms(get_the_ID(), 'destination-tag');
$share_on    = backpacktraveler_mikado_options()->getOptionValue('enable_social_share') == 'yes' && backpacktraveler_mikado_options()->getOptionValue('enable_social_share_on_destination-item') == 'yes';
$additional_image = get_post_meta( get_the_ID(), 'destination_second_featured_image', true );
?>
<div class="mkdf-pli-image" <?php backpacktraveler_mikado_inline_style($image_style); ?>></div>
<div class="mkdf-pli-text-holder test">
	<div class="mkdf-pli-text-wrapper">
		<div class="mkdf-pli-text">
			<div class="mkdf-pli-text-inner">
				<a class="mkdf-pli-up-arrow" href="#"><span class="arrow_expand_alt"></span></a>
				<h2 itemprop="name" class="mkdf-pli-title entry-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_attr( get_the_title() ); ?></a></h2>
				
				<div class="mkdf-pli-category">
					<?php foreach ( $categories as $cat ) { ?>
                        <a itemprop="url" href="<?php echo esc_url( get_term_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
					<?php } ?>
                </div>

                <div class="mkdf-pli-comments">
                    <?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/comments', $item_style, $params); ?>
                </div>

                <div class="mkdf-pli-likes">
                    <?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/likes', $item_style, $params); ?>
                </div>
				
				<div class="mkdf-pli-info-holder">
					<?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/excerpt', $item_style, $params); ?>
				</div>
                <div class="mkdf-pli-additional-image-holder">
                    <?php if($additional_image !== '') { ?>
                    <img itemprop="image" class="mkdf-destination-additional-image" src="<?php echo esc_url($additional_image); ?>" alt="<?php esc_attr_e('Destination Additional Image', 'backpacktraveler-core'); ?>" />
                    <?php } ?>
                </div>
			</div>
		</div>
	</div>
</div>