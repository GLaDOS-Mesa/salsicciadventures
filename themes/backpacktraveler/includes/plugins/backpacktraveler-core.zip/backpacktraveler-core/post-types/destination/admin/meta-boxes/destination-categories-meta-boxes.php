<?php

if ( ! function_exists( 'backpacktraveler_mikado_destination_category_additional_fields' ) ) {
	function backpacktraveler_mikado_destination_category_additional_fields() {
		
		$fields = backpacktraveler_mikado_add_taxonomy_fields(
			array(
				'scope' => 'destination-category',
				'name'  => 'destination_category_options'
			)
		);
		
		backpacktraveler_mikado_add_taxonomy_field(
			array(
				'name'   => 'mkdf_destination_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'backpacktraveler-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'backpacktraveler_mikado_action_custom_taxonomy_fields', 'backpacktraveler_mikado_destination_category_additional_fields' );
}