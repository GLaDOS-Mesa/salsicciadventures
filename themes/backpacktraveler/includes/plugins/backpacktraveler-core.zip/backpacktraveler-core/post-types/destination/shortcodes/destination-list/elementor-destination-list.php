<?php

class BackpackTravelerCoreElementorDestinationList extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_destination_list';
    }

    public function get_title() {
        return esc_html__( 'Destination List', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-destination-list';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'item_type',
            [
                'label'   => esc_html__( 'Click Behavior', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Open destination single page on click', 'backpacktraveler-core' ),
                    'gallery' => esc_html__( 'Open gallery in Pretty Photo on click', 'backpacktraveler-core' )
                ],
                'default' => 'gallery'
            ]
        );

        $this->add_control(
            'number_of_columns',
            [
                'label'   => esc_html__( 'Number of Columns', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is Three', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_number_of_columns_array( true ) ,
                'default' => 'four'
            ]
        );

        $this->add_control(
            'space_between_items',
            [
                'label'   => esc_html__( 'Space Between Items', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is Three', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_space_between_items_array(),
                'default' => 'normal'
            ]
        );

        $this->add_control(
            'number_of_items',
            [
                'label'   => esc_html__( 'Number of Destinations Per Page', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Set number of items for your destination list. Enter -1 to show all.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '-1'
            ]
        );

        $this->add_control(
            'image_proportions',
            [
                'label'   => esc_html__( 'Image Proportions', 'backpacktraveler-core' ),
                'description' =>  esc_html__( 'Set image proportions for your destination list.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'full' => esc_html__( 'Original', 'backpacktraveler-core' ),
                    'square' => esc_html__( 'Square', 'backpacktraveler-core' ),
                    'landscape' => esc_html__( 'Landscape', 'backpacktraveler-core' ),
                    'portrait' => esc_html__( 'Portrait', 'backpacktraveler-core' ),
                    'medium' => esc_html__( 'Medium', 'backpacktraveler-core' ),
                    'large' => esc_html__( 'Large', 'backpacktraveler-core' ),
                ],
                'default' => 'full'
            ]
        );

        $this->add_control(
            'category',
            [
                'label'   =>  esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'selected_projects',
            [
                'label'   =>  esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'tag',
            [
                'label'   =>  esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'   => esc_html__( 'Order By', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_by_array(),
                'default' => 'date'
            ]
        );

        $this->add_control(
            'order',
            [
                'label'   => esc_html__( 'Order', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_array(),
                'default' => 'ASC'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_layout',
            [
                'label' => esc_html__( 'Content Layout', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'content_top_margin',
            [
                'label'   => esc_html__( 'Content Top Margin (px or %)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'content_bottom_margin',
            [
                'label'   => esc_html__( 'Content Bottom Margin (px or %)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'enable_title',
            [
                'label'   => esc_html__( 'Enable Title', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'title_text_transform',
            [
                'label'   => esc_html__( 'Title Text Transform', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_text_transform_array( true ),
                'default' => '',
                'condition' => [
                    'enable_title' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'enable_category',
            [
                'label'   => esc_html__( 'Enable Category', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'additional_features',
            [
                'label' => esc_html__( 'Content Layout', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label'   => esc_html__( 'Pagination Type', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'no-pagination' => esc_html__( 'None', 'backpacktraveler-core' ),
                    'standard' => esc_html__( 'Standard', 'backpacktraveler-core' ),
                    'load-more' => esc_html__( 'Load More', 'backpacktraveler-core' ),
                    'infinite-scroll' => esc_html__( 'Infinite Scroll', 'backpacktraveler-core' ),
                ],
                'default' => 'no-pagination'
            ]
        );

        $this->add_control(
            'load_more_top_margin',
            [
                'label'   => esc_html__( 'Load More Top Margin (px or %)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'pagination_type' => 'load-more'
                ]
            ]
        );

        $this->add_control(
            'enable_article_animation',
            [
                'label'   => esc_html__( 'Enable Article Animation', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enabling this option you will enable appears animation for your destination list items', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' =>backpacktraveler_mikado_get_yes_no_select_array( false ),
                'default' => 'no'
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'type'                     => 'gallery',
            'item_type'                => '',
            'number_of_columns'        => 'four',
            'space_between_items'      => 'normal',
            'number_of_items'          => '-1',
            'image_proportions'        => 'full',
            'category'                 => '',
            'selected_projects'        => '',
            'tag'                      => '',
            'orderby'                  => 'date',
            'order'                    => 'ASC',
            'item_style'               => 'standard-shader',
            'content_top_margin'       => '',
            'content_bottom_margin'    => '',
            'enable_title'             => 'yes',
            'title_text_transform'     => '',
            'enable_category'          => 'yes',
            'enable_excerpt'           => 'no',
            'excerpt_length'           => '20',
            'pagination_type'          => 'no-pagination',
            'load_more_top_margin'     => '',
            'enable_article_animation' => 'no',
            'destination_slider_on'    => 'no',
            'enable_loop'              => 'yes',
            'enable_autoplay'          => 'yes',
            'slider_speed'             => '5000',
            'slider_speed_animation'   => '600',
            'enable_navigation'        => 'yes',
            'navigation_skin'          => '',
            'enable_pagination'        => 'yes',
            'pagination_skin'          => '',
            'pagination_position'      => ''
        );
        $params = shortcode_atts( $args, $params );

        /***
         * @params query_results
         * @params holder_data
         * @params holder_classes
         * @params holder_inner_classes
         */
        $additional_params = array();

        $query_array                        = $this->getQueryArray( $params );
        $query_results                      = new \WP_Query( $query_array );
        $additional_params['query_results'] = $query_results;

        $additional_params['holder_data']          = backpacktraveler_mikado_get_holder_data_for_cpt( $params, $additional_params );
        $additional_params['holder_classes']       = $this->getHolderClasses( $params, $args );
        $additional_params['holder_inner_classes'] = $this->getHolderInnerClasses( $params );

        $params['this_object'] = $this;

        echo backpacktraveler_core_get_cpt_shortcode_module_template_part( 'destination', 'destination-list', 'destination-holder', $params['type'], $params, $additional_params );
    }

    public function getQueryArray( $params ) {
        $query_array = array(
            'post_status'    => 'publish',
            'post_type'      => 'destination-item',
            'posts_per_page' => $params['number_of_items'],
            'orderby'        => $params['orderby'],
            'order'          => $params['order']
        );

        if ( ! empty( $params['category'] ) ) {
            $query_array['destination-category'] = $params['category'];
        }

        $project_ids = null;
        if ( ! empty( $params['selected_projects'] ) ) {
            $project_ids             = explode( ',', $params['selected_projects'] );
            $query_array['post__in'] = $project_ids;
        }

        if ( ! empty( $params['tag'] ) ) {
            $query_array['destination-tag'] = $params['tag'];
        }

        if ( ! empty( $params['next_page'] ) ) {
            $query_array['paged'] = $params['next_page'];
        } else {
            $query_array['paged'] = 1;
        }

        return $query_array;
    }

    public function getHolderClasses( $params, $args ) {
        $classes = array();

        $classes[] = ! empty( $params['type'] ) ? 'mkdf-pl-' . $params['type'] : 'mkdf-pl-' . $args['type'];
        $classes[] = ! empty( $params['number_of_columns'] ) ? 'mkdf-' . $params['number_of_columns'] . '-columns' : 'mkdf-' . $args['number_of_columns'] . '-columns';
        $classes[] = ! empty( $params['space_between_items'] ) ? 'mkdf-' . $params['space_between_items'] . '-space' : 'mkdf-' . $args['space_between_items'] . '-space';
        $classes[] = ! empty( $params['item_style'] ) ? 'mkdf-pl-' . $params['item_style'] : '';
        $classes[] = $params['enable_title'] === 'no' && $params['enable_category'] === 'no' ? 'mkdf-pl-no-content' : '';
        $classes[] = ! empty( $params['pagination_type'] ) ? 'mkdf-pl-pag-' . $params['pagination_type'] : '';
        $classes[] = $params['enable_article_animation'] === 'yes' ? 'mkdf-pl-has-animation' : '';
        $classes[] = ! empty( $params['navigation_skin'] ) ? 'mkdf-nav-' . $params['navigation_skin'] . '-skin' : '';
        $classes[] = ! empty( $params['pagination_skin'] ) ? 'mkdf-pag-' . $params['pagination_skin'] . '-skin' : '';
        $classes[] = ! empty( $params['pagination_position'] ) ? 'mkdf-pag-' . $params['pagination_position'] : '';

        return implode( ' ', $classes );
    }

    public function getHolderInnerClasses( $params ) {
        $classes = array();

        // separate fullscreen slider from standard slider layout for different js implementation
        if ($params['item_style'] == 'full-screen') {
            $classes[] = 'mkdf-pfs-slider';
        } else {
            $classes[] = $params['destination_slider_on'] === 'yes' ? 'mkdf-owl-slider mkdf-list-is-slider' : '';
        }

        return implode( ' ', $classes );
    }

    public function getArticleClasses( $params ) {
        $classes = array();

        $type       = $params['type'];
        $item_style = $params['item_style'];

        $classes[] = $item_style == 'full-screen' ? 'swiper-slide' : '';

        $article_classes = get_post_class( $classes );

        return implode( ' ', $article_classes );
    }

    public function getImageSize( $params ) {
        $thumb_size = 'full';

        if ( ! empty( $params['image_proportions'] ) && $params['type'] == 'gallery' ) {
            $image_size = $params['image_proportions'];

            switch ( $image_size ) {
                case 'landscape':
                    $thumb_size = 'backpacktraveler_mikado_image_landscape';
                    break;
                case 'portrait':
                    $thumb_size = 'backpacktraveler_mikado_image_portrait';
                    break;
                case 'square':
                    $thumb_size = 'backpacktraveler_mikado_image_square';
                    break;
                case 'medium':
                    $thumb_size = 'medium';
                    break;
                case 'large':
                    $thumb_size = 'large';
                    break;
                case 'full':
                    $thumb_size = 'full';
                    break;
            }
        }

        return $thumb_size;
    }

    public function getStandardContentStyles( $params ) {
        $styles = array();

        $margin_top    = isset( $params['content_top_margin'] ) ? $params['content_top_margin'] : '';
        $margin_bottom = isset( $params['content_bottom_margin'] ) ? $params['content_bottom_margin'] : '';

        if ( ! empty( $margin_top ) ) {
            if ( backpacktraveler_mikado_string_ends_with( $margin_top, '%' ) || backpacktraveler_mikado_string_ends_with( $margin_top, 'px' ) ) {
                $styles[] = 'margin-top: ' . $margin_top;
            } else {
                $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $margin_top ) . 'px';
            }
        }

        if ( ! empty( $margin_bottom ) ) {
            if ( backpacktraveler_mikado_string_ends_with( $margin_bottom, '%' ) || backpacktraveler_mikado_string_ends_with( $margin_bottom, 'px' ) ) {
                $styles[] = 'margin-bottom: ' . $margin_bottom;
            } else {
                $styles[] = 'margin-bottom: ' . backpacktraveler_mikado_filter_px( $margin_bottom ) . 'px';
            }
        }

        return implode( ';', $styles );
    }

    public function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_text_transform'] ) ) {
            $styles[] = 'text-transform: ' . $params['title_text_transform'];
        }

        return implode( ';', $styles );
    }

    public function getSwitchFeaturedImage() {
        $featured_image_meta = get_post_meta( get_the_ID(), 'mkdf_destination_featured_image_meta', true );

        $featured_image = ! empty( $featured_image_meta ) ? esc_url( $featured_image_meta ) : '';

        return $featured_image;
    }

    public function getLoadMoreStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['load_more_top_margin'] ) ) {
            $margin = $params['load_more_top_margin'];

            if ( backpacktraveler_mikado_string_ends_with( $margin, '%' ) || backpacktraveler_mikado_string_ends_with( $margin, 'px' ) ) {
                $styles[] = 'margin-top: ' . $margin;
            } else {
                $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $margin ) . 'px';
            }
        }

        return implode( ';', $styles );
    }

    public function getItemLink() {

        $destination_link = get_permalink( get_the_ID() );

        return apply_filters( 'backpacktraveler_mikado_filter_destination_external_link', $destination_link );
    }

    public function getItemLinkTarget() {
        $destination_link_target = '_self';

        return apply_filters( 'backpacktraveler_mikado_filter_destination_external_link_target', $destination_link_target );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorDestinationList() );