<?php

class BackpackTravelerCoreElementorMapWithDestinations extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_map_with_destinations';
    }

    public function get_title() {
        return esc_html__( 'Map With Destinations', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-map-with-destinations';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'map_height',
            [
                'label'   => esc_html__( 'Map Height', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is 500px', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '500'
            ]
        );

        $this->add_control(
            'number_of_items',
            [
                'label'   => esc_html__( 'Number of Items', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Set number of items for your list. Enter -1 to show all.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '-1'
            ]
        );

        $this->add_control(
            'selected_projects',
            [
                'label'   =>  esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'category',
            [
                'label'   =>  esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'tag',
            [
                'label'   =>  esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'map_height'        => '',
            'number_of_items'   => '-1',
            'selected_projects' => '',
            'category'          => '',
            'tag'               => '',
        );
        $params = shortcode_atts( $args, $params );

        $params['map_styles'] = $this->getMapStyles( $params );
        $params['have_items'] = $this->checkIsItemsExist();
        $params['maps_args']  = $this->setMapArgs( $params );

        echo backpacktraveler_core_get_cpt_shortcode_module_template_part( 'destination', 'map-with-destinations', 'holder', '', $params, array(), false );

    }

    private function setMapArgs( $params ) {
        $args = array(
            'posts_per_page' => $params['number_of_items'],
            'order'          => 'DESC',
        );

        $items_ids = null;

        if ( ! empty( $params['selected_projects'] ) ) {
            $items_ids        = explode( ',', $params['selected_projects'] );
            $args['post__in'] = $items_ids;
        }

	    if ( ! empty( $params['category'] ) ) {
		    $args['destination-category'] = $params['category'];
	    }

	    if ( ! empty( $params['tag'] ) ) {
		    $args['destination-tag'] = $params['tag'];
	    }

        // Custom meta query args
        $order_by   = 'date';
        $query_args = array( 'relation' => 'AND' );

        $args['orderby'] = $order_by;

        $args['meta_query'] = $query_args;

        if ( ! empty( $params['next_page'] ) ) {
            $args['paged'] = $params['next_page'];
        } else {
            $args['paged'] = 1;
        }

        return $args;
    }

    private function getMapStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['map_height'] ) ) {
            $styles[] = 'height: ' . backpacktraveler_mikado_filter_px( $params['map_height'] ) . 'px';
        }

        return implode( ';', $styles );
    }

    private function checkIsItemsExist() {

        $items      = array();
        $query_args = array(
            'post_status'    => 'publish',
            'post_type'      => 'destination-item',
            'posts_per_page' => '-1',
            'fields'         => 'ids'
        );

        if ( ! empty( $args ) ) {
            foreach ( $args as $key => $value ) {
                if ( ! empty( $value ) ) {
                    $query_args[ $key ] = $value;
                }
            }
        }

        $cpt_items = new \WP_Query( $query_args );

        if ( $cpt_items->have_posts() ) {

            foreach ( $cpt_items->posts as $id ):
                $items[ $id ] = get_the_title( $id );
            endforeach;
        }

        wp_reset_postdata();

        return ! empty( $items );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorMapWithDestinations() );