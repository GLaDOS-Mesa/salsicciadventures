<?php

if ( ! function_exists( 'backpacktraveler_core_map_destination_settings_meta' ) ) {
	function backpacktraveler_core_map_destination_settings_meta() {
		$meta_box = backpacktraveler_mikado_create_meta_box( array(
			'scope' => 'destination-item',
			'title' => esc_html__( 'Destination Settings', 'backpacktraveler-core' ),
			'name'  => 'destination_settings_meta_box'
		) );

        // Location meta box section - begin

        $location_box = backpacktraveler_mikado_create_meta_box(
            array(
                'scope' => 'destination-item',
                'name'  => 'destination_single_location_meta_box',
                'title' => esc_html__( 'Location Section', 'backpacktraveler-core' )
            )
        );

        backpacktraveler_mikado_add_admin_section_title(
            array(
                'name'   => 'destination_single_location_address_info',
                'title'  => esc_html__( 'Address Information', 'backpacktraveler-core' ),
                'parent' => $location_box
            )
        );

        backpacktraveler_mikado_create_meta_box_field(
            array(
                'name'   => 'mkdf_destination_single_full_address_meta',
                'type'   => 'address',
                'label'  => esc_html__( 'Full Address', 'backpacktraveler-core' ),
                'parent' => $location_box,
                'args'   => array(
                    'latitude_field'  => 'mkdf_destination_single_full_address_latitude_meta',
                    'longitude_field' => 'mkdf_destination_single_full_address_longitude_meta'
                )
            )
        );

        backpacktraveler_mikado_create_meta_box_field(
            array(
                'name'   => 'mkdf_destination_single_full_address_latitude_meta',
                'type'   => 'text',
                'label'  => esc_html__( 'Latitude', 'backpacktraveler-core' ),
                'parent' => $location_box,
                'args'   => array(
                    'col_width'    => 3,
                    'custom_class' => 'mkdf-address-elements',
                    'input-data'   => array(
                        'data-geo' => 'lat'
                    )
                )
            )
        );

        backpacktraveler_mikado_create_meta_box_field(
            array(
                'name'   => 'mkdf_destination_single_full_address_longitude_meta',
                'type'   => 'text',
                'label'  => esc_html__( 'Longitude', 'backpacktraveler-core' ),
                'parent' => $location_box,
                'args'   => array(
                    'col_width'    => 3,
                    'custom_class' => 'mkdf-address-elements',
                    'input-data'   => array(
                        'data-geo' => 'lng'
                    )
                )
            )
        );
		
		backpacktraveler_mikado_create_meta_box_field( array(
			'name'        => 'mkdf_destination_single_template_meta',
			'type'        => 'select',
			'label'       => esc_html__( 'Destination Type', 'backpacktraveler-core' ),
			'description' => esc_html__( 'Choose a default type for Single Project pages', 'backpacktraveler-core' ),
			'parent'      => $meta_box,
			'options'     => array(
				''                  => esc_html__( 'Default', 'backpacktraveler-core' ),
				'custom-in-grid'    => esc_html__( 'Destination Custom in Grid', 'backpacktraveler-core' ),
				'full-width-custom' => esc_html__( 'Destination Full Width Custom', 'backpacktraveler-core' )
			)
		) );
		
		backpacktraveler_mikado_create_meta_box_field(
			array(
				'name'          => 'mkdf_show_title_area_destination_single_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will show title area on your single destination page', 'backpacktraveler-core' ),
				'parent'        => $meta_box,
				'options'       => backpacktraveler_mikado_get_yes_no_select_array()
			)
		);
		
		backpacktraveler_mikado_create_meta_box_field(
			array(
				'name'        => 'destination_info_top_padding',
				'type'        => 'text',
				'label'       => esc_html__( 'Destination Info Top Padding', 'backpacktraveler-core' ),
				'description' => esc_html__( 'Set top padding for destination info elements holder. This option works only for Destination Images, Slider, Gallery and Masonry destination types', 'backpacktraveler-core' ),
				'parent'      => $meta_box,
				'args'        => array(
					'col_width' => 3,
					'suffix'    => 'px'
				)
			)
		);
	}
	
	add_action( 'backpacktraveler_mikado_action_meta_boxes_map', 'backpacktraveler_core_map_destination_settings_meta', 41 );
}