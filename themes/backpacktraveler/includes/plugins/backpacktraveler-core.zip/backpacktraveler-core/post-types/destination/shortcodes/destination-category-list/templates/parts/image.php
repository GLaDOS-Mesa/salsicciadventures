<?php if ( ! empty( $params['image'] ) ) { ?>
    <div class="mkdf-pcli-image">
        <?php echo wp_get_attachment_image( $params['image'], $image_size ); ?>
    </div>
<?php } ?>