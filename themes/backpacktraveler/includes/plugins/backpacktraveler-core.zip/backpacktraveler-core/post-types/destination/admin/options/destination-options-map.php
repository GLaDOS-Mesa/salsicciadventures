<?php

if ( ! function_exists( 'backpacktraveler_mikado_destination_options_map' ) ) {
	function backpacktraveler_mikado_destination_options_map() {
		
		backpacktraveler_mikado_add_admin_page(
			array(
				'slug'  => '_destination',
				'title' => esc_html__( 'Destination', 'backpacktraveler-core' ),
				'icon'  => 'fa fa-camera-retro'
			)
		);
		
		$panel_archive = backpacktraveler_mikado_add_admin_panel(
			array(
				'title' => esc_html__( 'Destination Archive', 'backpacktraveler-core' ),
				'name'  => 'panel_destination_archive',
				'page'  => '_destination'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'        => 'destination_archive_number_of_items',
				'type'        => 'text',
				'label'       => esc_html__( 'Number of Items', 'backpacktraveler-core' ),
				'description' => esc_html__( 'Set number of items for your destination list on archive pages. Default value is 12', 'backpacktraveler-core' ),
				'parent'      => $panel_archive,
				'args'        => array(
					'col_width' => 3
				)
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_archive_number_of_columns',
				'type'          => 'select',
				'label'         => esc_html__( 'Number of Columns', 'backpacktraveler-core' ),
				'default_value' => 'four',
				'description'   => esc_html__( 'Set number of columns for your destination list on archive pages. Default value is Four columns', 'backpacktraveler-core' ),
				'parent'        => $panel_archive,
				'options'       => backpacktraveler_mikado_get_number_of_columns_array( false, array( 'one', 'six' ) )
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_archive_space_between_items',
				'type'          => 'select',
				'label'         => esc_html__( 'Space Between Items', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Set space size between destination items for your destination list on archive pages. Default value is normal', 'backpacktraveler-core' ),
				'default_value' => 'normal',
				'options'       => backpacktraveler_mikado_get_space_between_items_array(),
				'parent'        => $panel_archive
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_archive_image_size',
				'type'          => 'select',
				'label'         => esc_html__( 'Image Proportions', 'backpacktraveler-core' ),
				'default_value' => 'landscape',
				'description'   => esc_html__( 'Set image proportions for your destination list on archive pages. Default value is landscape', 'backpacktraveler-core' ),
				'parent'        => $panel_archive,
				'options'       => array(
					'full'      => esc_html__( 'Original', 'backpacktraveler-core' ),
					'landscape' => esc_html__( 'Landscape', 'backpacktraveler-core' ),
					'portrait'  => esc_html__( 'Portrait', 'backpacktraveler-core' ),
					'square'    => esc_html__( 'Square', 'backpacktraveler-core' )
				)
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_archive_item_layout',
				'type'          => 'select',
				'label'         => esc_html__( 'Item Style', 'backpacktraveler-core' ),
				'default_value' => 'standard-shader',
				'description'   => esc_html__( 'Set item style for your destination list on archive pages. Default value is Standard - Shader', 'backpacktraveler-core' ),
				'parent'        => $panel_archive,
				'options'       => array(
					'standard-shader' => esc_html__( 'Standard - Shader', 'backpacktraveler-core' ),
					'gallery-overlay' => esc_html__( 'Gallery - Overlay', 'backpacktraveler-core' )
				)
			)
		);

        $panel_destionation_posts = backpacktraveler_mikado_add_admin_panel(
            array(
                'title' => esc_html__( 'Destination Posts', 'backpacktraveler-core' ),
                'name'  => 'panel_destination_posts',
                'page'  => '_destination'
            )
        );

        $all_pages = array();
        $pages_args = array(
            'post_type' => 'page',
            'posts_per_page' => '-1'
        );
        $pages = get_posts($pages_args);
        foreach ( $pages as $page ) {
            $all_pages[ $page->ID ] = $page->post_title;
        }

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_posts_page',
                'type'          => 'select',
                'label'         => esc_html__( 'Destination Posts page', 'backpacktraveler-core' ),
                'description'   => esc_html__( 'Choose a default page for Destination posts', 'backpacktraveler-core' ),
                'parent'        => $panel_destionation_posts,
                'options'       => $all_pages
            )
        );

		
		$panel = backpacktraveler_mikado_add_admin_panel(
			array(
				'title' => esc_html__( 'Destination Single', 'backpacktraveler-core' ),
				'name'  => 'panel_destination_single',
				'page'  => '_destination'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_template',
				'type'          => 'select',
				'label'         => esc_html__( 'Destination Type', 'backpacktraveler-core' ),
				'default_value' => 'custom-in-grid',
				'description'   => esc_html__( 'Choose a default type for Single Project pages', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'options'       => array(
					'custom-in-grid'            => esc_html__( 'Destination Custom in Grid', 'backpacktraveler-core' ),
					'full-width-custom' => esc_html__( 'Destination Full Width Custom', 'backpacktraveler-core' )
				)
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'type'          => 'select',
				'name'          => 'show_title_area_destination_single',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will show title area on single projects', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'options'       => array(
					''    => esc_html__( 'Default', 'backpacktraveler-core' ),
					'yes' => esc_html__( 'Yes', 'backpacktraveler-core' ),
					'no'  => esc_html__( 'No', 'backpacktraveler-core' )
				),
				'args'          => array(
					'col_width' => 3
				)
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_lightbox_images',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Lightbox for Images', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will turn on lightbox functionality for projects with images', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'yes'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_lightbox_videos',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Lightbox for Videos', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will turn on lightbox functionality for YouTube/Vimeo projects', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'no'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_enable_categories',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Categories', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will enable category meta description on single projects', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'yes'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_hide_date',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Date', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will enable date meta on single projects', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'yes'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_sticky_sidebar',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Sticky Side Text', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will make side text sticky on Single Project pages. This option works only for Full Width Images, Small Images, Small Gallery and Small Masonry destination types', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'yes'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_comments',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Show Comments', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will show comments on your page', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'yes'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_hide_pagination',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Hide Pagination', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will turn off destination pagination functionality', 'backpacktraveler-core' ),
				'parent'        => $panel,
				'default_value' => 'no'
			)
		);
		
		$container_navigate_category = backpacktraveler_mikado_add_admin_container(
			array(
				'name'            => 'navigate_same_category_container',
				'parent'          => $panel,
				'dependency' => array(
					'hide' => array(
						'destination_single_hide_pagination'  => array(
							'yes'
						)
					)
				)
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'          => 'destination_single_nav_same_category',
				'type'          => 'yesno',
				'label'         => esc_html__( 'Enable Pagination Through Same Category', 'backpacktraveler-core' ),
				'description'   => esc_html__( 'Enabling this option will make destination pagination sort through current category', 'backpacktraveler-core' ),
				'parent'        => $container_navigate_category,
				'default_value' => 'no'
			)
		);
		
		backpacktraveler_mikado_add_admin_field(
			array(
				'name'        => 'destination_single_slug',
				'type'        => 'text',
				'label'       => esc_html__( 'Destination Single Slug', 'backpacktraveler-core' ),
				'description' => esc_html__( 'Enter if you wish to use a different Single Project slug (Note: After entering slug, navigate to Settings -> Permalinks and click "Save" in order for changes to take effect)', 'backpacktraveler-core' ),
				'parent'      => $panel,
				'args'        => array(
					'col_width' => 3
				)
			)
		);

        $panel_maps = backpacktraveler_mikado_add_admin_panel(
            array(
                'name'  => 'panel_maps',
                'title' => esc_html__( 'Destination Maps', 'backpacktraveler-core' ),
                'page'  => '_destination'
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'        => 'destination_map_style',
                'type'        => 'textarea',
                'label'       => esc_html__( 'Maps Style', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Insert map style json', 'backpacktraveler-core' ),
                'parent'      => $panel_maps
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_maps_scrollable',
                'type'          => 'yesno',
                'default_value' => 'no',
                'label'         => esc_html__( 'Scrollable Maps', 'backpacktraveler-core' ),
                'parent'        => $panel_maps
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_maps_draggable',
                'type'          => 'yesno',
                'default_value' => 'yes',
                'label'         => esc_html__( 'Draggable Maps', 'backpacktraveler-core' ),
                'parent'        => $panel_maps
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_maps_street_view_control',
                'type'          => 'yesno',
                'default_value' => 'yes',
                'label'         => esc_html__( 'Maps Street View Controls', 'backpacktraveler-core' ),
                'parent'        => $panel_maps
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_maps_zoom_control',
                'type'          => 'yesno',
                'default_value' => 'yes',
                'label'         => esc_html__( 'Maps Zoom Control', 'backpacktraveler-core' ),
                'parent'        => $panel_maps
            )
        );

        backpacktraveler_mikado_add_admin_field(
            array(
                'name'          => 'destination_maps_type_control',
                'type'          => 'yesno',
                'default_value' => 'yes',
                'label'         => esc_html__( 'Maps Type Control', 'backpacktraveler-core' ),
                'parent'        => $panel_maps
            )
        );

	}
	
	add_action( 'backpacktraveler_mikado_action_options_map', 'backpacktraveler_mikado_destination_options_map', backpacktraveler_mikado_set_options_map_position( 'destination' ) );
}