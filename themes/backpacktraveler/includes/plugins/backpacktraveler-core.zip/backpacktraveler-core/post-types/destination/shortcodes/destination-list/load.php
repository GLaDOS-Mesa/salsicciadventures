<?php

require_once 'destination-list.php';
require_once 'helper-functions.php';