<?php
get_header();
backpacktraveler_mikado_get_title();
do_action( 'backpacktraveler_mikado_action_before_main_content' ); ?>
<div class="mkdf-container mkdf-default-page-template">
	<?php do_action( 'backpacktraveler_mikado_action_after_container_open' ); ?>
	<div class="mkdf-container-inner clearfix">
		<?php
			$backpacktraveler_taxonomy_id   = get_queried_object_id();
			$backpacktraveler_taxonomy_type = is_tax( 'destination-tag' ) ? 'destination-tag' : 'destination-category';
			$backpacktraveler_taxonomy      = ! empty( $backpacktraveler_taxonomy_id ) ? get_term_by( 'id', $backpacktraveler_taxonomy_id, $backpacktraveler_taxonomy_type ) : '';
			$backpacktraveler_taxonomy_slug = ! empty( $backpacktraveler_taxonomy ) ? $backpacktraveler_taxonomy->slug : '';
			$backpacktraveler_taxonomy_name = ! empty( $backpacktraveler_taxonomy ) ? $backpacktraveler_taxonomy->taxonomy : '';
			
			backpacktraveler_core_get_archive_destination_list( $backpacktraveler_taxonomy_slug, $backpacktraveler_taxonomy_name );
		?>
	</div>
	<?php do_action( 'backpacktraveler_mikado_action_before_container_close' ); ?>
</div>
<?php get_footer(); ?>
