<?php

class BackpackTravelerCoreElementorDestinationSlider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_destination_slider';
    }

    public function get_title() {
        return esc_html__( 'Destination Slider', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-destination-slider';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'number_of_items',
            [
                'label'   => esc_html__( 'Number of Destinations Per Page', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Set number of items for your destination list. Enter -1 to show all.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '-1'
            ]
        );

        $this->add_control(
            'item_type',
            [
                'label'   => esc_html__( 'Click Behavior', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Open destination single page on click', 'backpacktraveler-core' ),
                    'gallery' => esc_html__( 'Open gallery in Pretty Photo on click', 'backpacktraveler-core' )
                ],
                'default' => 'gallery'
            ]
        );

        $this->add_control(
            'number_of_columns',
            [
                'label'   => esc_html__( 'Number of Columns', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is Three', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_number_of_columns_array( true ) ,
                'default' => 'four'
            ]
        );

        $this->add_control(
            'space_between_items',
            [
                'label'   => esc_html__( 'Space Between Items', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is Three', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_space_between_items_array(),
                'default' => 'normal'
            ]
        );

        $this->add_control(
            'image_proportions',
            [
                'label'   => esc_html__( 'Image Proportions', 'backpacktraveler-core' ),
                'description' =>  esc_html__( 'Set image proportions for your destination list.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'full' => esc_html__( 'Original', 'backpacktraveler-core' ),
                    'square' => esc_html__( 'Square', 'backpacktraveler-core' ),
                    'landscape' => esc_html__( 'Landscape', 'backpacktraveler-core' ),
                    'portrait' => esc_html__( 'Portrait', 'backpacktraveler-core' ),
                    'medium' => esc_html__( 'Medium', 'backpacktraveler-core' ),
                    'large' => esc_html__( 'Large', 'backpacktraveler-core' ),
                ],
                'default' => 'full'
            ]
        );

        $this->add_control(
            'category',
            [
                'label'   =>  esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'selected_projects',
            [
                'label'   =>  esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'tag',
            [
                'label'   =>  esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'   => esc_html__( 'Order By', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_by_array(),
                'default' => 'date'
            ]
        );

        $this->add_control(
            'order',
            [
                'label'   => esc_html__( 'Order', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_array(),
                'default' => 'ASC'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_layout',
            [
                'label' => esc_html__( 'Content Layout', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'content_top_margin',
            [
                'label'   => esc_html__( 'Content Top Margin (px or %)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'content_bottom_margin',
            [
                'label'   => esc_html__( 'Content Bottom Margin (px or %)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'enable_title',
            [
                'label'   => esc_html__( 'Enable Title', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'title_text_transform',
            [
                'label'   => esc_html__( 'Title Text Transform', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_text_transform_array( true ),
                'default' => '',
                'condition' => [
                    'enable_title' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'enable_category',
            [
                'label'   => esc_html__( 'Enable Category', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'enable_count_images',
            [
                'label'   => esc_html__( 'Enable Number of Images', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes',
                'condition' => [
                    'item_type' => 'gallery'
                ]
            ]
        );

        $this->add_control(
            'enable_excerpt',
            [
                'label'   => esc_html__( 'Enable Excerpt', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false )
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label'   => esc_html__( 'Excerpt Length', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Number of characters', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_settings',
            [
                'label' => esc_html__( 'Slider Settings', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_loop',
            [
                'label'   => esc_html__( 'Enable Slider Loop', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' =>backpacktraveler_mikado_get_yes_no_select_array( false, false ),
                'default' => 'no'
            ]
        );

        $this->add_control(
            'enable_autoplay',
            [
                'label'   => esc_html__( 'Enable Slider Autoplay', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'slider_speed',
            [
                'label'   => esc_html__( 'Slide Duration', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Default value is 5000 (ms)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '5000'
            ]
        );

        $this->add_control(
            'slider_speed_animation',
            [
                'label'   => esc_html__( 'Slide Animation Duration', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '600'
            ]
        );

        $this->add_control(
            'enable_navigation',
            [
                'label'   => esc_html__( 'Enable Slider Navigation Arrows', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'navigation_skin',
            [
                'label'   => esc_html__( 'Navigation Skin', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'light' => esc_html__( 'Light', 'backpacktraveler-core' ),
                    'dark' => esc_html__( 'Dark', 'backpacktraveler-core' ),
                ],
                'default' => '',
                'condition' => [
                    'enable_navigation' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'enable_pagination',
            [
                'label'   => esc_html__( 'Enable Slider Pagination', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'pagination_skin',
            [
                'label'   => esc_html__( 'Pagination Skin', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'light' => esc_html__( 'Light', 'backpacktraveler-core' ),
                    'dark' => esc_html__( 'Dark', 'backpacktraveler-core' ),
                ],
                'default' => '',
                'condition' => [
                    'enable_pagination' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'pagination_position',
            [
                'label'   => esc_html__( 'Pagination Position', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'below-slider' => esc_html__( 'Below Slider', 'backpacktraveler-core' ),
                    'on-slider' => esc_html__( 'On Slider', 'backpacktraveler-core' )
                ],
                'default' => 'below-slider',
                'condition' => [
                    'enable_pagination' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'number_of_items'        => '9',
            'item_type'              => '',
            'number_of_columns'      => 'four',
            'space_between_items'    => 'normal',
            'image_proportions'      => 'full',
            'category'               => '',
            'selected_projects'      => '',
            'tag'                    => '',
            'orderby'                => 'date',
            'order'                  => 'ASC',
            'item_style'             => 'standard-shader',
            'content_top_margin'     => '',
            'content_bottom_margin'  => '',
            'enable_title'           => 'yes',
            'title_tag'              => 'h4',
            'title_text_transform'   => '',
            'enable_category'        => 'yes',
            'enable_count_images'    => 'yes',
            'enable_excerpt'         => 'no',
            'excerpt_length'         => '20',
            'enable_loop'            => 'no',
            'enable_autoplay'        => 'yes',
            'slider_speed'           => '5000',
            'slider_speed_animation' => '600',
            'enable_navigation'      => 'yes',
            'navigation_skin'        => '',
            'enable_pagination'      => 'yes',
            'pagination_skin'        => '',
            'pagination_position'    => 'below-slider'
        );
        $params = shortcode_atts( $args, $params );

        $params['type']                = 'gallery';
        $params['destination_slider_on'] = 'yes';

        $html = '<div class="mkdf-destination-slider-holder">';
        $html .= backpacktraveler_mikado_execute_shortcode( 'mkdf_destination_list', $params );
        $html .= '</div>';

        echo backpacktraveler_mikado_get_module_part( $html );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorDestinationSlider() );