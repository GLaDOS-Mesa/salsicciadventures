<div class="mkdf-destination-list-holder mkdf-grid-list <?php echo esc_attr($holder_classes); ?>" <?php echo wp_kses($holder_data, array('data')); ?>>
	<div class="mkdf-pl-inner mkdf-outer-space <?php echo esc_attr($holder_inner_classes); ?> clearfix">
        <?php if ($item_style == 'full-screen') : ?>
        <div class="swiper-container"><div class="swiper-wrapper">
                <?php endif; ?>
		<?php
			if($query_results->have_posts()):
				while ( $query_results->have_posts() ) : $query_results->the_post();
					echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'destination-item', $item_type, $params);
				endwhile;
			else:
				echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'parts/posts-not-found');
			endif;
		
			wp_reset_postdata();
		?>
        <?php if ($item_style == 'full-screen') : ?>
            </div></div>
        <div id="mkdf-ptf-info-block">
            <div class="mkdf-pli-text-holder">
                <div class="mkdf-pli-text-wrapper">
                    <div class="mkdf-pli-text">
                        <a class="mkdf-pli-up-arrow" href="#"><span class="arrow_expand_alt"></span></a>
                        <div class="mkdf-pli-text-inner">
                            <div class="mkdf-pli-fs-left">
                                <h2 itemprop="name" class="mkdf-pli-title entry-title">.</h2>
                                <div class="mkdf-pli-cat"></div>
                                <div class="mkdf-pli-info-holder">
                                    <div class="mkdf-pli-category-info mkdf-pli-info">
                                        <p><a itemprop="url" href="#"></a></p>
                                    </div>
                                    <div class="mkdf-pli-comments-info mkdf-pli-info">
                                        <p></p>
                                    </div>
                                    <div class="mkdf-pli-likes-info mkdf-pli-info">
                                        <p></p>
                                    </div>
                                    <p itemprop="description" class="mkdf-pli-excerpt"></p>
                                    <div class="mkdf-pli-share-info mkdf-pli-info">
                                        <div class="mkdf-social-share-holder mkdf-list">
                                            <ul>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <a href="#" class="mkdf-btn mkdf-btn-medium mkdf-btn-outline mkdf-pli-link-info"><span class="mkdf-btn-text"><?php esc_html_e('Explore','backpacktraveler-core');?></span></a>
                            </div>
                            <div class="mkdf-pli-fs-right">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
	</div>
	
	<?php echo backpacktraveler_core_get_cpt_shortcode_module_template_part('destination', 'destination-list', 'pagination/'.$pagination_type, '', $params, $additional_params); ?>
</div>