<?php if ($excerpt_length !== '0' && $excerpt_length !== '' && $enable_excerpt === 'yes') {

    global $post;
    $word_count = $excerpt_length;

    //is word count set to something different that 0?
    if ( $word_count > 0 ) {
        //if post excerpt field is filled take that as post excerpt, else that content of the post
        $post_excerpt = $post->post_excerpt !== '' ? $post->post_excerpt : strip_tags(strip_shortcodes($post->post_content));

        //remove leading dots if those exists
        $clean_excerpt = strlen($post_excerpt) && strpos($post_excerpt, '...') ? strstr($post_excerpt, '...', true) : $post_excerpt;
        //if clean excerpt has text left
        if ($clean_excerpt !== '') {
            //explode current excerpt to words
            $excerpt_word_array = explode(' ', $clean_excerpt);

            //cut down that array based on the number of the words option
            $excerpt_word_array = array_slice($excerpt_word_array, 0, $word_count);

            //and finally implode words together
            $excerpt = implode(' ', $excerpt_word_array);

            //is excerpt different than empty string?
            if ($excerpt !== '') {
                $excerpt = rtrim(wp_kses_post($excerpt));
            }
        }
    }

	?>
	<p itemprop="description" class="mkdf-pli-excerpt">
        <?php echo wp_kses_post( $excerpt ); ?></p>
<?php } ?>