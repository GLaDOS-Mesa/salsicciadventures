<?php

require_once 'register-template.php';
