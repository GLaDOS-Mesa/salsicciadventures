<?php

require_once 'register-template.php';
require_once 'destination-posts-functions.php';