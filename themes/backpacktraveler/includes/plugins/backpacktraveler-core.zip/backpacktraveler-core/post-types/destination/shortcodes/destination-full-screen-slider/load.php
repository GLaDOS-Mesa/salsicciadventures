<?php

require_once 'destination-full-screen-slider.php';
require_once 'helper-functions.php';