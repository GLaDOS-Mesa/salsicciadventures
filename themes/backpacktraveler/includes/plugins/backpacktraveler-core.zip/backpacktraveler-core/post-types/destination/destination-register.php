<?php

namespace BackpackTravelerCore\CPT\Destination;

use BackpackTravelerCore\Lib\PostTypeInterface;

/**
 * Class DestinationRegister
 * @package BackpackTravelerCore\CPT\Destination
 */
class DestinationRegister implements PostTypeInterface {
	private $base;
	private $taxBase;
	private $tagBase;
	
	public function __construct() {
		$this->base    = 'destination-item';
		$this->taxBase = 'destination-category';
		$this->tagBase = 'destination-tag';
		
		add_filter( 'archive_template', array( $this, 'registerArchiveTemplate' ) );
		add_filter( 'single_template', array( $this, 'registerSingleTemplate' ) );
	}
	
	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}
	
	/**
	 * Registers custom post type with WordPress
	 */
	public function register() {
		$this->registerPostType();
		$this->registerTax();
		$this->registerTagTax();
	}
	
	/**
	 * Registers destination archive template if one does'nt exists in theme.
	 * Hooked to archive_template filter
	 *
	 * @param $archive string current template
	 *
	 * @return string string changed template
	 */
	public function registerArchiveTemplate( $archive ) {
		global $post;
		
		if ( ! empty( $post ) && $post->post_type == $this->base ) {
			if ( ! file_exists( get_template_directory() . '/archive-' . $this->base . '.php' ) ) {
				return BACKPACKTRAVELER_CORE_CPT_PATH . '/destination/templates/archive-' . $this->base . '.php';
			}
		}
		
		return $archive;
	}
	
	/**
	 * Registers destination single template if one does'nt exists in theme.
	 * Hooked to single_template filter
	 *
	 * @param $single string current template
	 *
	 * @return string string changed template
	 */
	public function registerSingleTemplate( $single ) {
		global $post;
		
		if ( ! empty( $post ) && $post->post_type == $this->base ) {
			if ( ! file_exists( get_template_directory() . '/single-destination-item.php' ) ) {
				return BACKPACKTRAVELER_CORE_CPT_PATH . '/destination/templates/single-' . $this->base . '.php';
			}
		}
		
		return $single;
	}
	
	/**
	 * Registers custom post type with WordPress
	 */
	private function registerPostType() {
		$menuPosition = 5;
		$menuIcon     = 'dashicons-screenoptions';
		$slug         = $this->base;
		
		if ( backpacktraveler_core_theme_installed() ) {
			if ( backpacktraveler_mikado_options()->getOptionValue( 'destination_single_slug' ) ) {
				$slug = backpacktraveler_mikado_options()->getOptionValue( 'destination_single_slug' );
			}
		}
		
		register_post_type( $this->base,
			array(
				'labels'        => array(
					'name'          => esc_html__( 'BackpackTraveler Destination', 'backpacktraveler-core' ),
					'singular_name' => esc_html__( 'Destination Item', 'backpacktraveler-core' ),
					'add_item'      => esc_html__( 'New Destination Item', 'backpacktraveler-core' ),
					'add_new_item'  => esc_html__( 'Add New Destination Item', 'backpacktraveler-core' ),
					'edit_item'     => esc_html__( 'Edit Destination Item', 'backpacktraveler-core' )
				),
				'public'        => true,
				'has_archive'   => true,
				'rewrite'       => array( 'slug' => $slug ),
				'menu_position' => $menuPosition,
				'show_ui'       => true,
				'supports'      => array(
					'author',
					'title',
					'editor',
					'thumbnail',
					'excerpt',
					'page-attributes',
					'comments'
				),
				'menu_icon'     => $menuIcon
			)
		);
	}
	
	/**
	 * Registers custom taxonomy with WordPress
	 */
	private function registerTax() {
		$labels = array(
			'name'              => esc_html__( 'Destination Categories', 'backpacktraveler-core' ),
			'singular_name'     => esc_html__( 'Destination Category', 'backpacktraveler-core' ),
			'search_items'      => esc_html__( 'Search Destination Categories', 'backpacktraveler-core' ),
			'all_items'         => esc_html__( 'All Destination Categories', 'backpacktraveler-core' ),
			'parent_item'       => esc_html__( 'Parent Destination Category', 'backpacktraveler-core' ),
			'parent_item_colon' => esc_html__( 'Parent Destination Category:', 'backpacktraveler-core' ),
			'edit_item'         => esc_html__( 'Edit Destination Category', 'backpacktraveler-core' ),
			'update_item'       => esc_html__( 'Update Destination Category', 'backpacktraveler-core' ),
			'add_new_item'      => esc_html__( 'Add New Destination Category', 'backpacktraveler-core' ),
			'new_item_name'     => esc_html__( 'New Destination Category Name', 'backpacktraveler-core' ),
			'menu_name'         => esc_html__( 'Destination Categories', 'backpacktraveler-core' )
		);
		
		register_taxonomy( $this->taxBase, array( $this->base ), array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'destination-category' )
		) );
	}
	
	/**
	 * Registers custom tag taxonomy with WordPress
	 */
	private function registerTagTax() {
		$labels = array(
			'name'              => esc_html__( 'Destination Tags', 'backpacktraveler-core' ),
			'singular_name'     => esc_html__( 'Destination Tag', 'backpacktraveler-core' ),
			'search_items'      => esc_html__( 'Search Destination Tags', 'backpacktraveler-core' ),
			'all_items'         => esc_html__( 'All Destination Tags', 'backpacktraveler-core' ),
			'parent_item'       => esc_html__( 'Parent Destination Tag', 'backpacktraveler-core' ),
			'parent_item_colon' => esc_html__( 'Parent Destination Tags:', 'backpacktraveler-core' ),
			'edit_item'         => esc_html__( 'Edit Destination Tag', 'backpacktraveler-core' ),
			'update_item'       => esc_html__( 'Update Destination Tag', 'backpacktraveler-core' ),
			'add_new_item'      => esc_html__( 'Add New Destination Tag', 'backpacktraveler-core' ),
			'new_item_name'     => esc_html__( 'New Destination Tag Name', 'backpacktraveler-core' ),
			'menu_name'         => esc_html__( 'Destination Tags', 'backpacktraveler-core' )
		);
		
		register_taxonomy( $this->tagBase, array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'destination-tag' )
		) );
	}
}