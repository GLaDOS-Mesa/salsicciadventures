<?php
$additional_image = get_post_meta( get_the_ID(), 'destination_second_featured_image', true ); ?>
<?php if($additional_image !== '') { ?>
<img itemprop="image" class="mkdf-destination-additional-image" src="<?php echo esc_url($additional_image); ?>" alt="<?php esc_attr_e('Destination Additional Image', 'backpacktraveler-core'); ?>" />
<?php } ?>