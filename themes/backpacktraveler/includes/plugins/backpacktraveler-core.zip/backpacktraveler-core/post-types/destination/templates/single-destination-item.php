<?php

get_header();

backpacktraveler_mikado_get_title();

do_action('backpacktraveler_mikado_action_before_main_content');

backpacktraveler_core_get_single_destination();

get_footer();