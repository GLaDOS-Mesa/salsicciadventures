<?php

class BackpackTravelerCoreElementorDestinationFullScreenSlider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_destination_full_screen_slider';
    }

    public function get_title() {
        return esc_html__( 'Destination Full Screen Slider', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-destination-full-screen-slider';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'number_of_items',
            [
                'label'   =>  esc_html__( 'Number of Destinations Items', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Set number of items for your destination slider. Enter -1 to show all', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '-1'
            ]
        );

        $this->add_control(
            'category',
            [
                'label'   =>  esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'selected_projects',
            [
                'label'   =>  esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'tag',
            [
                'label'   =>  esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'   => esc_html__( 'Order By', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_by_array(),
                'default' => 'date'
            ]
        );

        $this->add_control(
            'order',
            [
                'label'   => esc_html__( 'Order', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_query_order_array(),
                'default' => 'ASC'
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_settings',
            [
                'label' => esc_html__( 'Slider Settings', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_mousewheel_scroll',
            [
                'label'   => esc_html__( 'Enable Slider Mousewheel Scrolling', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false ),
                'default' => 'no'
            ]
        );

        $this->add_control(
            'enable_pagination',
            [
                'label'   =>  esc_html__( 'Enable Slider Pagination', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'pagination_skin',
            [
                'label'   =>  esc_html__( 'Pagination Skin', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'light' => esc_html__( 'Light', 'backpacktraveler-core' ),
                    'dark' => esc_html__( 'Dark', 'backpacktraveler-core' ),
                ],
                'default' => '',
                'condition' => [
                    'enable_pagination' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'number_of_items'          => '-1',
            'number_of_columns'        => 'one',
            'space_between_items'      => 'no',
            'image_proportions'        => 'full',
            'category'                 => '',
            'selected_projects'        => '',
            'tag'                      => '',
            'orderby'                  => 'date',
            'order'                    => 'ASC',
            'item_style'               => 'full-screen',
            'enable_mousewheel_scroll' => 'no',
            'enable_pagination'        => 'yes',
            'enable_navigation'        => 'yes',
            'pagination_skin'          => '',
            'enable_count_images'      => 'yes',
            'pagination_type'          => 'standard',
            'pagination_position'      => 'on-slider',
            'excerpt_length'           => '300',
        );
        $params = shortcode_atts( $args, $params );

        $params['type']                = 'gallery';
        $params['destination_slider_on'] = 'yes';
        $params['vertical_sliding']    = 'yes';
        $params['enable_excerpt']      = 'yes';

        $html = '<div class="mkdf-destination-full-screen-slider-holder">';
        $html .= backpacktraveler_mikado_execute_shortcode( 'mkdf_destination_list', $params );
        $html .= '<div class="mkdf-swiper-nav">
			<span class="mkdf-prev-icon"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="41.828px" height="14.833px" viewBox="0 0 41.828 14.833" enable-background="new 0 0 41.828 14.833" xml:space="preserve">
				<g>
					<line fill="none" stroke="#000000" stroke-miterlimit="10" x1="2.083" y1="6.939" x2="41.828" y2="6.939"></line>
					<polyline fill="none" stroke="#000000" stroke-miterlimit="10" points="13.083,0.689 1.583,6.939 13.083,14.022"></polyline>
				</g>
				</svg></span><span class="mkdf-next-icon"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="41.828px" height="14.833px" viewBox="0 0 41.828 14.833" enable-background="new 0 0 41.828 14.833" xml:space="preserve">
				<g>
					<line fill="none" stroke="#000000" stroke-miterlimit="10" x1="39.745" y1="7.772" x2="0" y2="7.772"></line>
					<polyline fill="none" stroke="#000000" stroke-miterlimit="10" points="28.745,14.022 40.245,7.772 28.745,0.689"></polyline>
				</g>
				</svg></span></div>';
        $html .= '</div>';


        echo backpacktraveler_mikado_get_module_part( $html );
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorDestinationFullScreenSlider() );