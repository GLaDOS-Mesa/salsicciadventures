<?php

namespace BackpackTravelerCore\CPT\Shortcodes\Destination;

use BackpackTravelerCore\Lib;

class DestinationSlider implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'mkdf_destination_slider';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
		
		//Destination category filter
		add_filter( 'vc_autocomplete_mkdf_destination_slider_category_callback', array( &$this, 'destinationCategoryAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination category render
		add_filter( 'vc_autocomplete_mkdf_destination_slider_category_render', array( &$this, 'destinationCategoryAutocompleteRender', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination selected projects filter
		add_filter( 'vc_autocomplete_mkdf_destination_slider_selected_projects_callback', array( &$this, 'destinationIdAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination selected projects render
		add_filter( 'vc_autocomplete_mkdf_destination_slider_selected_projects_render', array( &$this, 'destinationIdAutocompleteRender', ), 10, 1 ); // Render exact destination. Must return an array (label,value)
		
		//Destination tag filter
		add_filter( 'vc_autocomplete_mkdf_destination_slider_tag_callback', array( &$this, 'destinationTagAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination tag render
		add_filter( 'vc_autocomplete_mkdf_destination_slider_tag_render', array( &$this, 'destinationTagAutocompleteRender', ), 10, 1 ); // Get suggestion(find). Must return an array
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'     => esc_html__( 'Destination Slider', 'backpacktraveler-core' ),
					'base'     => $this->base,
					'category' => esc_html__( 'by BACKPACKTRAVELER', 'backpacktraveler-core' ),
					'icon'     => 'icon-wpb-destination-slider extended-custom-icon',
					'params'   => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'number_of_items',
							'heading'     => esc_html__( 'Number of Destinations Items', 'backpacktraveler-core' ),
							'admin_label' => true,
							'description' => esc_html__( 'Set number of items for your destination slider. Enter -1 to show all', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'item_type',
							'heading'    => esc_html__( 'Click Behavior', 'backpacktraveler-core' ),
							'value'      => array(
								esc_html__( 'Open destination single page on click', 'backpacktraveler-core' )   => '',
								esc_html__( 'Open gallery in Pretty Photo on click', 'backpacktraveler-core' ) => 'gallery',
							)
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'number_of_columns',
							'heading'     => esc_html__( 'Number of Columns', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_number_of_columns_array( true ) ),
							'description' => esc_html__( 'Number of destinations that are showing at the same time in slider (on smaller screens is responsive so there will be less items shown). Default value is Four', 'backpacktraveler-core' ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'space_between_items',
							'heading'     => esc_html__( 'Space Between Items', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_space_between_items_array() ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'image_proportions',
							'heading'     => esc_html__( 'Image Proportions', 'backpacktraveler-core' ),
							'value'       => array(
								esc_html__( 'Original', 'backpacktraveler-core' )  => 'full',
								esc_html__( 'Square', 'backpacktraveler-core' )    => 'square',
								esc_html__( 'Landscape', 'backpacktraveler-core' ) => 'landscape',
								esc_html__( 'Portrait', 'backpacktraveler-core' )  => 'portrait',
								esc_html__( 'Medium', 'backpacktraveler-core' )    => 'medium',
								esc_html__( 'Large', 'backpacktraveler-core' )     => 'large'
							),
							'description' => esc_html__( 'Set image proportions for your destination slider.', 'backpacktraveler-core' ),
							'save_always' => true
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'category',
							'heading'     => esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'selected_projects',
							'heading'     => esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
							'settings'    => array(
								'multiple'      => true,
								'sortable'      => true,
								'unique_values' => true
							),
							'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'tag',
							'heading'     => esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'orderby',
							'heading'     => esc_html__( 'Order By', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_query_order_by_array() ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'order',
							'heading'     => esc_html__( 'Order', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_query_order_array() ),
							'save_always' => true
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'content_top_margin',
							'heading'    => esc_html__( 'Content Top Margin (px or %)', 'backpacktraveler-core' ),
							'dependency' => array( 'element' => 'item_style', 'value' => array( 'standard-shader', 'standard-switch-images' ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'content_bottom_margin',
							'heading'    => esc_html__( 'Content Bottom Margin (px or %)', 'backpacktraveler-core' ),
							'dependency' => array( 'element' => 'item_style', 'value' => array( 'standard-shader', 'standard-switch-images' ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_title',
							'heading'    => esc_html__( 'Enable Title', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'title_tag',
							'heading'    => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_title_tag( true ) ),
							'dependency' => array( 'element' => 'enable_title', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'title_text_transform',
							'heading'    => esc_html__( 'Title Text Transform', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_text_transform_array( true ) ),
							'dependency' => array( 'element' => 'enable_title', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_category',
							'heading'    => esc_html__( 'Enable Category', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_count_images',
							'heading'    => esc_html__( 'Enable Number of Images', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'dependency' => array( 'element' => 'item_type', 'value' => array( 'gallery' ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'enable_excerpt',
							'heading'    => esc_html__( 'Enable Excerpt', 'backpacktraveler-core' ),
							'value'      => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false ) ),
							'group'      => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'excerpt_length',
							'heading'     => esc_html__( 'Excerpt Length', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Number of characters', 'backpacktraveler-core' ),
							'dependency'  => array( 'element' => 'enable_excerpt', 'value' => array( 'yes' ) ),
							'group'       => esc_html__( 'Content Layout', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_loop',
							'heading'     => esc_html__( 'Enable Slider Loop', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, false ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' ),
							'dependency'  => array( 'element' => 'item_type', 'value' => array( '' ) )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_autoplay',
							'heading'     => esc_html__( 'Enable Slider Autoplay', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'slider_speed',
							'heading'     => esc_html__( 'Slide Duration', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Default value is 5000 (ms)', 'backpacktraveler-core' ),
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'slider_speed_animation',
							'heading'     => esc_html__( 'Slide Animation Duration', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'backpacktraveler-core' ),
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_navigation',
							'heading'     => esc_html__( 'Enable Slider Navigation Arrows', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'navigation_skin',
							'heading'    => esc_html__( 'Navigation Skin', 'backpacktraveler-core' ),
							'value'      => array(
								esc_html__( 'Default', 'backpacktraveler-core' ) => '',
								esc_html__( 'Light', 'backpacktraveler-core' )   => 'light',
								esc_html__( 'Dark', 'backpacktraveler-core' )    => 'dark'
							),
							'dependency' => array( 'element' => 'enable_navigation', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_pagination',
							'heading'     => esc_html__( 'Enable Slider Pagination', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'pagination_skin',
							'heading'    => esc_html__( 'Pagination Skin', 'backpacktraveler-core' ),
							'value'      => array(
								esc_html__( 'Default', 'backpacktraveler-core' ) => '',
								esc_html__( 'Light', 'backpacktraveler-core' )   => 'light',
								esc_html__( 'Dark', 'backpacktraveler-core' )    => 'dark'
							),
							'dependency' => array( 'element' => 'enable_pagination', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'pagination_position',
							'heading'     => esc_html__( 'Pagination Position', 'backpacktraveler-core' ),
							'value'       => array(
								esc_html__( 'Below Slider', 'backpacktraveler-core' ) => 'below-slider',
								esc_html__( 'On Slider', 'backpacktraveler-core' )    => 'on-slider'
							),
							'save_always' => true,
							'dependency'  => array( 'element' => 'enable_pagination', 'value' => array( 'yes' ) ),
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						)
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'number_of_items'        => '9',
			'item_type'              => '',
			'number_of_columns'      => 'four',
			'space_between_items'    => 'normal',
			'image_proportions'      => 'full',
			'category'               => '',
			'selected_projects'      => '',
			'tag'                    => '',
			'orderby'                => 'date',
			'order'                  => 'ASC',
			'item_style'             => 'standard-shader',
			'content_top_margin'     => '',
			'content_bottom_margin'  => '',
			'enable_title'           => 'yes',
			'title_tag'              => 'h4',
			'title_text_transform'   => '',
			'enable_category'        => 'yes',
			'enable_count_images'    => 'yes',
			'enable_excerpt'         => 'no',
			'excerpt_length'         => '20',
			'enable_loop'            => 'no',
			'enable_autoplay'        => 'yes',
			'slider_speed'           => '5000',
			'slider_speed_animation' => '600',
			'enable_navigation'      => 'yes',
			'navigation_skin'        => '',
			'enable_pagination'      => 'yes',
			'pagination_skin'        => '',
			'pagination_position'    => 'below-slider'
		);
		$params = shortcode_atts( $args, $atts );
		
		$params['type']                = 'gallery';
		$params['destination_slider_on'] = 'yes';
		
		$html = '<div class="mkdf-destination-slider-holder">';
			$html .= backpacktraveler_mikado_execute_shortcode( 'mkdf_destination_list', $params );
		$html .= '</div>';
		
		return $html;
	}
	
	/**
	 * Filter destination categories
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationCategoryAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS destination_category_title
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'destination-category' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = ( ( strlen( $value['destination_category_title'] ) > 0 ) ? esc_html__( 'Category', 'backpacktraveler-core' ) . ': ' . $value['destination_category_title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination category by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationCategoryAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination category
			$destination_category = get_term_by( 'slug', $query, 'destination-category' );
			if ( is_object( $destination_category ) ) {
				
				$destination_category_slug  = $destination_category->slug;
				$destination_category_title = $destination_category->name;
				
				$destination_category_title_display = '';
				if ( ! empty( $destination_category_title ) ) {
					$destination_category_title_display = esc_html__( 'Category', 'backpacktraveler-core' ) . ': ' . $destination_category_title;
				}
				
				$data          = array();
				$data['value'] = $destination_category_slug;
				$data['label'] = $destination_category_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
	
	/**
	 * Filter destinations by ID or Title
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationIdAutocompleteSuggester( $query ) {
		global $wpdb;
		$destination_id    = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts} 
					WHERE post_type = 'destination-item' AND ( ID = '%d' OR post_title LIKE '%%%s%%' )", $destination_id > 0 ? $destination_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'backpacktraveler-core' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'backpacktraveler-core' ) . ': ' . $value['title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationIdAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination
			$destination = get_post( (int) $query );
			if ( ! is_wp_error( $destination ) ) {
				
				$destination_id    = $destination->ID;
				$destination_title = $destination->post_title;
				
				$destination_title_display = '';
				if ( ! empty( $destination_title ) ) {
					$destination_title_display = ' - ' . esc_html__( 'Title', 'backpacktraveler-core' ) . ': ' . $destination_title;
				}
				
				$destination_id_display = esc_html__( 'Id', 'backpacktraveler-core' ) . ': ' . $destination_id;
				
				$data          = array();
				$data['value'] = $destination_id;
				$data['label'] = $destination_id_display . $destination_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
	
	/**
	 * Filter destination tags
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationTagAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS destination_tag_title
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'destination-tag' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = ( ( strlen( $value['destination_tag_title'] ) > 0 ) ? esc_html__( 'Tag', 'backpacktraveler-core' ) . ': ' . $value['destination_tag_title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination tag by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationTagAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination category
			$destination_tag = get_term_by( 'slug', $query, 'destination-tag' );
			if ( is_object( $destination_tag ) ) {
				
				$destination_tag_slug  = $destination_tag->slug;
				$destination_tag_title = $destination_tag->name;
				
				$destination_tag_title_display = '';
				if ( ! empty( $destination_tag_title ) ) {
					$destination_tag_title_display = esc_html__( 'Tag', 'backpacktraveler-core' ) . ': ' . $destination_tag_title;
				}
				
				$data          = array();
				$data['value'] = $destination_tag_slug;
				$data['label'] = $destination_tag_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
}