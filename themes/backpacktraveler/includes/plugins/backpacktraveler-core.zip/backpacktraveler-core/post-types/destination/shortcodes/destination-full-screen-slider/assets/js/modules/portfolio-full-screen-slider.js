(function($) {
    'use strict';

    var destinationFullScreenSlider = {};
    mkdf.modules.mkdfInitDestinationFullScreenSlider = mkdfInitDestinationFullScreenSlider;
    mkdf.modules.mkdfInitElementorDestinationFullScreenSlider = mkdfInitElementorDestinationFullScreenSlider;

    destinationFullScreenSlider.mkdfOnDocumentReady = mkdfOnDocumentReady;

    $(document).ready(mkdfOnDocumentReady);
    $(window).on('load',mkdfOnWindowLoad);

    /* 
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
	    mkdfInitDestinationFullScreenSlider();
    }

    function mkdfOnWindowLoad() {
		mkdfInitElementorDestinationFullScreenSlider();
    }


    /**
     * Initializes destination full screen slider logic
     */
    function mkdfInitDestinationFullScreenSlider(){
        var holders = $('.mkdf-destination-full-screen-slider-holder');

        if(holders.length){
	        holders.each(function(){
                var holder = $(this),
                	infoBlock = $('#mkdf-ptf-info-block'),
                	infoHolder = infoBlock.find('.mkdf-pli-info-holder'),
                	titleArea = infoBlock.find('.mkdf-pli-title'),
                    linkArea = infoBlock.find('.mkdf-pli-link-info'),
                    imageArea = infoBlock.find('.mkdf-pli-fs-right'),
                    commentsArea = infoBlock.find('.mkdf-pli-comments'),
                    likesArea = infoBlock.find('.mkdf-pli-likes'),
                    catArea = infoBlock.find('.mkdf-pli-cat'),
                	textInner = infoBlock.find('.mkdf-pli-text-inner'),
                	excerptInfoArea = infoBlock.find('.mkdf-pli-excerpt'),
                	categoryInfoArea = infoBlock.find('.mkdf-pli-category-info > p'),
                	commentsInfoArea = infoBlock.find('.mkdf-pli-comments-info > p'),
                	likesInfoArea = infoBlock.find('.mkdf-pli-likes-info > p'),
                	shareListInfoArea = infoBlock.find('.mkdf-social-share-holder > ul'),
                	infoOpener = infoBlock.find('.mkdf-pli-up-arrow'),
	                swiperInstance = holder.find('.swiper-container');


            		var swiperSlider = new Swiper (swiperInstance, {
            			loop: true,
            			slidesPerView: 1,
                        mousewheel: {
                            invert: false,
                        },
            			speed: 1000,
            			autoplay: {
            			    delay: 2800,
						},
						navigation: {
							nextEl: '.mkdf-next-icon',
							prevEl: '.mkdf-prev-icon',
						  },
                        pagination: {
                            el: '.swiper-pagination',
                            clickable: true,
                            renderBullet: function (index, className) {
                                return '<span class="' + className + '"></span>';
                            },
                        },
            			init: false
		    		});

            	var setInfo = function() {
            		var activeSlide = swiperInstance.find('.swiper-slide-active'),
            			titleHtml = activeSlide.find('.mkdf-pli-title').html(),
            			imageHtml = activeSlide.find('.mkdf-pli-additional-image-holder').html(),
                        linkHref = activeSlide.find('.mkdf-pli-title a').attr('href'),
            			commentsVal = activeSlide.find('.mkdf-pli-comments').text(),
            			likesVal = activeSlide.find('.mkdf-pli-likes').text(),
            			excerptVal = activeSlide.find('.mkdf-pli-excerpt').html(),
            			categoryHtml = activeSlide.find('.mkdf-pli-category').html(),
            			shareListHtml = activeSlide.find('.mkdf-social-share-holder > ul').html();

            		titleArea.html(titleHtml);
            		imageArea.html(imageHtml);
            		linkArea.attr('href', linkHref);
            		catArea.html(categoryHtml);
            		commentsArea.text(commentsVal);
            		likesArea.text(likesVal);
            		excerptInfoArea.html(excerptVal);
            		categoryInfoArea.html(categoryHtml);
            		commentsInfoArea.text(commentsVal);
            		likesInfoArea.text(likesVal);
            		shareListInfoArea.html(shareListHtml);
            	}

            	var infoToggle = function() {
            		infoOpener.on('click', function(){
            			mkdf.body.toggleClass('mkdf-pfss-item-is-active');
        				infoBlock.toggleClass('mkdf-active');
        				infoOpener.toggleClass('mkdf-active');
        				commentsArea.toggleClass('mkdf-hide');
        				catArea.toggleClass('mkdf-hide');
        				infoHolder.toggleClass('mkdf-show');

        				if (mkdf.body.hasClass('mkdf-pfss-item-is-active')) {
        					swiperSlider.autoplay.stop();
        				} else {
        					swiperSlider.autoplay.start();
        					swiperSlider.slideNext();
        				}
            		});
            	}

		        var fullscreenCalcs = function() {
		        	var topOffset = holder.offset().top,
                    	passepartoutHeight = mkdf.body.hasClass('mkdf-paspartu-enabled') ? parseInt( $('.mkdf-wrapper').css('padding-top'), 10 ) : 0;

			        holder.css('height', mkdf.windowHeight - topOffset - passepartoutHeight);
		        }


            	swiperSlider.on('init', function(){
            		holder.addClass('mkdf-initialized');
			    });

            	swiperSlider.on('slideChangeTransitionStart', function(){
                    var sliderSpeed = swiperSlider.params['speed'];
                    setTimeout(function() {
                        textInner.removeClass("show").addClass("hide");
                    }, sliderSpeed/10);
                    setTimeout(function() {
                        setInfo();
                        textInner.addClass("show").removeClass("hide");
                    }, sliderSpeed/2);
			    });

		        holder.waitForImages(function(){
		        	fullscreenCalcs();
                	swiperSlider.init();
		        	infoToggle();
		        });

		        $(window).resize(function(){
		        	fullscreenCalcs();
		        });
            });
        }
    }

	function mkdfInitElementorDestinationFullScreenSlider(){
		$(window).on('elementor/frontend/init', function () {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/mkdf_destination_full_screen_slider.default', function() {
				mkdfInitDestinationFullScreenSlider();
			} );
		});
	}

})(jQuery);