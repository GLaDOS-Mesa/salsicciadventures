<?php

namespace BackpackTravelerCore\CPT\Shortcodes\Destination;

use BackpackTravelerCore\Lib;

class DestinationFullScreenSlider implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'mkdf_destination_full_screen_slider';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
		
		//Destination category filter
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_category_callback', array( &$this, 'destinationCategoryAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination category render
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_category_render', array( &$this, 'destinationCategoryAutocompleteRender', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination selected projects filter
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_selected_projects_callback', array( &$this, 'destinationIdAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination selected projects render
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_selected_projects_render', array( &$this, 'destinationIdAutocompleteRender', ), 10, 1 ); // Render exact destination. Must return an array (label,value)
		
		//Destination tag filter
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_tag_callback', array( &$this, 'destinationTagAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array
		
		//Destination tag render
		add_filter( 'vc_autocomplete_mkdf_destination_full_screen_slider_tag_render', array( &$this, 'destinationTagAutocompleteRender', ), 10, 1 ); // Get suggestion(find). Must return an array
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'     => esc_html__( 'Destination Full Screen Slider', 'backpacktraveler-core' ),
					'base'     => $this->base,
					'category' => esc_html__( 'by BACKPACKTRAVELER', 'backpacktraveler-core' ),
					'icon'     => 'icon-wpb-destination-full-screen-slider extended-custom-icon',
					'params'   => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'number_of_items',
							'heading'     => esc_html__( 'Number of Destinations Items', 'backpacktraveler-core' ),
							'admin_label' => true,
							'description' => esc_html__( 'Set number of items for your destination slider. Enter -1 to show all', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'category',
							'heading'     => esc_html__( 'One-Category Destination List', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Enter one category slug (leave empty for showing all categories)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'selected_projects',
							'heading'     => esc_html__( 'Show Only Projects with Listed IDs', 'backpacktraveler-core' ),
							'settings'    => array(
								'multiple'      => true,
								'sortable'      => true,
								'unique_values' => true
							),
							'description' => esc_html__( 'Delimit ID numbers by comma (leave empty for all)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'tag',
							'heading'     => esc_html__( 'One-Tag Destination List', 'backpacktraveler-core' ),
							'description' => esc_html__( 'Enter one tag slug (leave empty for showing all tags)', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'orderby',
							'heading'     => esc_html__( 'Order By', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_query_order_by_array() ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'order',
							'heading'     => esc_html__( 'Order', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_query_order_array() ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_mousewheel_scroll',
							'heading'     => esc_html__( 'Enable Slider Mousewheel Scrolling', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_pagination',
							'heading'     => esc_html__( 'Enable Slider Pagination', 'backpacktraveler-core' ),
							'value'       => array_flip( backpacktraveler_mikado_get_yes_no_select_array( false, true ) ),
							'save_always' => true,
							'group'       => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'pagination_skin',
							'heading'    => esc_html__( 'Pagination Skin', 'backpacktraveler-core' ),
							'value'      => array(
								esc_html__( 'Default', 'backpacktraveler-core' ) => '',
								esc_html__( 'Light', 'backpacktraveler-core' )   => 'light',
								esc_html__( 'Dark', 'backpacktraveler-core' )    => 'dark'
							),
							'dependency' => array( 'element' => 'enable_pagination', 'value' => array( 'yes' ) ),
							'group'      => esc_html__( 'Slider Settings', 'backpacktraveler-core' )
						)
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'number_of_items'          => '-1',
			'number_of_columns'        => 'one',
			'space_between_items'      => 'no',
			'image_proportions'        => 'full',
			'category'                 => '',
			'selected_projects'        => '',
			'tag'                      => '',
			'orderby'                  => 'date',
			'order'                    => 'ASC',
			'item_style'               => 'full-screen',
			'enable_mousewheel_scroll' => 'no',
			'enable_pagination'        => 'yes',
			'enable_navigation'        => 'yes',
			'pagination_skin'          => '',
			'enable_count_images'      => 'yes',
			'pagination_type'          => 'standard',
			'pagination_position'      => 'on-slider',
			'excerpt_length'           => '300',
		);
		$params = shortcode_atts( $args, $atts );
		
		$params['type']                = 'gallery';
		$params['destination_slider_on'] = 'yes';
		$params['vertical_sliding']    = 'yes';
		$params['enable_excerpt']      = 'yes';

		$html = '<div class="mkdf-destination-full-screen-slider-holder">';
			$html .= backpacktraveler_mikado_execute_shortcode( 'mkdf_destination_list', $params );
			$html .= '<div class="mkdf-swiper-nav">
			<span class="mkdf-prev-icon"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="41.828px" height="14.833px" viewBox="0 0 41.828 14.833" enable-background="new 0 0 41.828 14.833" xml:space="preserve">
				<g>
					<line fill="none" stroke="#000000" stroke-miterlimit="10" x1="2.083" y1="6.939" x2="41.828" y2="6.939"></line>
					<polyline fill="none" stroke="#000000" stroke-miterlimit="10" points="13.083,0.689 1.583,6.939 13.083,14.022"></polyline>
				</g>
				</svg></span><span class="mkdf-next-icon"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="41.828px" height="14.833px" viewBox="0 0 41.828 14.833" enable-background="new 0 0 41.828 14.833" xml:space="preserve">
				<g>
					<line fill="none" stroke="#000000" stroke-miterlimit="10" x1="39.745" y1="7.772" x2="0" y2="7.772"></line>
					<polyline fill="none" stroke="#000000" stroke-miterlimit="10" points="28.745,14.022 40.245,7.772 28.745,0.689"></polyline>
				</g>
				</svg></span></div>';
		$html .= '</div>';
		
		
		return $html;
	}
	
	/**
	 * Filter destination categories
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationCategoryAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS destination_category_title
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'destination-category' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = ( ( strlen( $value['destination_category_title'] ) > 0 ) ? esc_html__( 'Category', 'backpacktraveler-core' ) . ': ' . $value['destination_category_title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination category by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationCategoryAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination category
			$destination_category = get_term_by( 'slug', $query, 'destination-category' );
			if ( is_object( $destination_category ) ) {
				
				$destination_category_slug  = $destination_category->slug;
				$destination_category_title = $destination_category->name;
				
				$destination_category_title_display = '';
				if ( ! empty( $destination_category_title ) ) {
					$destination_category_title_display = esc_html__( 'Category', 'backpacktraveler-core' ) . ': ' . $destination_category_title;
				}
				
				$data          = array();
				$data['value'] = $destination_category_slug;
				$data['label'] = $destination_category_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
	
	/**
	 * Filter destinations by ID or Title
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationIdAutocompleteSuggester( $query ) {
		global $wpdb;
		$destination_id    = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts} 
					WHERE post_type = 'destination-item' AND ( ID = '%d' OR post_title LIKE '%%%s%%' )", $destination_id > 0 ? $destination_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'backpacktraveler-core' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'backpacktraveler-core' ) . ': ' . $value['title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationIdAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination
			$destination = get_post( (int) $query );
			if ( ! is_wp_error( $destination ) ) {
				
				$destination_id    = $destination->ID;
				$destination_title = $destination->post_title;
				
				$destination_title_display = '';
				if ( ! empty( $destination_title ) ) {
					$destination_title_display = ' - ' . esc_html__( 'Title', 'backpacktraveler-core' ) . ': ' . $destination_title;
				}
				
				$destination_id_display = esc_html__( 'Id', 'backpacktraveler-core' ) . ': ' . $destination_id;
				
				$data          = array();
				$data['value'] = $destination_id;
				$data['label'] = $destination_id_display . $destination_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
	
	/**
	 * Filter destination tags
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function destinationTagAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS destination_tag_title
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'destination-tag' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );
		
		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['slug'];
				$data['label'] = ( ( strlen( $value['destination_tag_title'] ) > 0 ) ? esc_html__( 'Tag', 'backpacktraveler-core' ) . ': ' . $value['destination_tag_title'] : '' );
				$results[]     = $data;
			}
		}
		
		return $results;
	}
	
	/**
	 * Find destination tag by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function destinationTagAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get destination category
			$destination_tag = get_term_by( 'slug', $query, 'destination-tag' );
			if ( is_object( $destination_tag ) ) {
				
				$destination_tag_slug  = $destination_tag->slug;
				$destination_tag_title = $destination_tag->name;
				
				$destination_tag_title_display = '';
				if ( ! empty( $destination_tag_title ) ) {
					$destination_tag_title_display = esc_html__( 'Tag', 'backpacktraveler-core' ) . ': ' . $destination_tag_title;
				}
				
				$data          = array();
				$data['value'] = $destination_tag_slug;
				$data['label'] = $destination_tag_title_display;
				
				return ! empty( $data ) ? $data : false;
			}
			
			return false;
		}
		
		return false;
	}
}