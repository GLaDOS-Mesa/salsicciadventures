<?php ?>
<h1 class="mkdf-destination-single-title"><?php the_title(); ?></h1>
<?php
the_content();