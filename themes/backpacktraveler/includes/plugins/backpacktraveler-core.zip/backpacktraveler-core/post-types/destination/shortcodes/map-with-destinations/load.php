<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

include_once 'helper-functions.php';
include_once 'map-with-destinations.php';
