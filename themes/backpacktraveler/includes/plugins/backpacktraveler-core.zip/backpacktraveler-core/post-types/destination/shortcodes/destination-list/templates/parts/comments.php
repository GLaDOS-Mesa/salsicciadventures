<?php if(comments_open()) { ?>
    <div class="mkdf-destination-info-comments-holder">
        <a itemprop="url" class="mkdf-destination-info-comments" href="<?php comments_link(); ?>">
            <?php comments_number('0 Comments' , '1 Comment', '% Comments' ); ?>
        </a>
    </div>
<?php } ?>