<?php

if ( ! function_exists( 'backpacktraveler_core_map_destination_meta' ) ) {
	function backpacktraveler_core_map_destination_meta() {
		global $backpacktraveler_mikado_global_Framework;
		
		$backpacktraveler_pages = array();
		$pages      = get_pages();
		foreach ( $pages as $page ) {
			$backpacktraveler_pages[ $page->ID ] = $page->post_title;
		}

        //Destination Images

        $backpacktraveler_destination_images = new BackpackTravelerMikadoClassMetaBox( 'destination-item', esc_html__( 'Destination Images (multiple upload)', 'backpacktraveler-core' ), '', '', 'destination_images' );
        $backpacktraveler_mikado_global_Framework->mkdMetaBoxes->addMetaBox( 'destination_images', $backpacktraveler_destination_images );

        $backpacktraveler_destination_image_gallery = new BackpackTravelerMikadoClassMultipleImages( 'mkdf-destination-image-gallery', esc_html__( 'Destination Images', 'backpacktraveler-core' ), esc_html__( 'Choose your destination images', 'backpacktraveler-core' ) );
        $backpacktraveler_destination_images->addChild( 'mkdf-destination-image-gallery', $backpacktraveler_destination_image_gallery );

        //Destination Single Upload Images/Videos

        $backpacktraveler_destination_images_videos = backpacktraveler_mikado_create_meta_box(
            array(
                'scope' => array( 'destination-item' ),
                'title' => esc_html__( 'Destination Images/Videos (single upload)', 'backpacktraveler-core' ),
                'name'  => 'mkdf_destination_images_videos'
            )
        );
        backpacktraveler_mikado_add_repeater_field(
            array(
                'name'        => 'mkdf_destination_single_upload',
                'parent'      => $backpacktraveler_destination_images_videos,
                'button_text' => esc_html__( 'Add Image/Video', 'backpacktraveler-core' ),
                'fields'      => array(
                    array(
                        'type'        => 'select',
                        'name'        => 'file_type',
                        'label'       => esc_html__( 'File Type', 'backpacktraveler-core' ),
                        'options' => array(
                            'image' => esc_html__('Image','backpacktraveler-core'),
                            'video' => esc_html__('Video','backpacktraveler-core'),
                        )
                    ),
                    array(
                        'type'        => 'image',
                        'name'        => 'single_image',
                        'label'       => esc_html__( 'Image', 'backpacktraveler-core' ),
                        'dependency' => array(
                            'show' => array(
                                'file_type'  => 'image'
                            )
                        )
                    ),
                    array(
                        'type'        => 'select',
                        'name'        => 'video_type',
                        'label'       => esc_html__( 'Video Type', 'backpacktraveler-core' ),
                        'options'	  => array(
                            'youtube' => esc_html__('YouTube', 'backpacktraveler-core'),
                            'vimeo' => esc_html__('Vimeo', 'backpacktraveler-core'),
                            'self' => esc_html__('Self Hosted', 'backpacktraveler-core'),
                        ),
                        'dependency' => array(
                            'show' => array(
                                'file_type'  => 'video'
                            )
                        )
                    ),
                    array(
                        'type'        => 'text',
                        'name'        => 'video_id',
                        'label'       => esc_html__( 'Video ID', 'backpacktraveler-core' ),
                        'dependency' => array(
                            'show' => array(
                                'file_type' => 'video',
                                'video_type'  => array('youtube','vimeo')
                            )
                        )
                    ),
                    array(
                        'type'        => 'text',
                        'name'        => 'video_mp4',
                        'label'       => esc_html__( 'Video mp4', 'backpacktraveler-core' ),
                        'dependency' => array(
                            'show' => array(
                                'file_type' => 'video',
                                'video_type'  => 'self'
                            )
                        )
                    ),
                    array(
                        'type'        => 'image',
                        'name'        => 'video_cover_image',
                        'label'       => esc_html__( 'Video Cover Image', 'backpacktraveler-core' ),
                        'dependency' => array(
                            'show' => array(
                                'file_type' => 'video',
                                'video_type'  => 'self'
                            )
                        )
                    )
                )
            )
        );

        //Destination Second Featured Image

        $mkdfSecondDestinationFeaturedImage =  backpacktraveler_mikado_create_meta_box(array(
            'scope' => array('destination-item'),
            'title' => esc_html__('Destination Additional image','backpacktraveler-core'),
            'name' => 'second-featured-image',

        ));

        backpacktraveler_mikado_create_meta_box_field(
            array(
                'name'        	=> 'destination_second_featured_image',
                'type'        	=> 'image',
                'label'       	=> '',
                'description' 	=> esc_html__('Add additional image that will be displayed on single destinations sidebar and in destination lists','backpacktraveler-core'),
                'parent'      	=> $mkdfSecondDestinationFeaturedImage,
            )
        );

        //Portfolio Additional Sidebar Items

        $backpacktraveler_additional_sidebar_items = backpacktraveler_mikado_create_meta_box(
            array(
                'scope' => array( 'destination-item' ),
                'title' => esc_html__( 'Additional Destination Sidebar Items', 'backpacktraveler-core' ),
                'name'  => 'destination_properties'
            )
        );

        backpacktraveler_mikado_add_repeater_field(
            array(
                'name'        => 'mkdf_destination_properties',
                'parent'      => $backpacktraveler_additional_sidebar_items,
                'button_text' => esc_html__( 'Add New Item', 'backpacktraveler-core' ),
                'fields'      => array(
                    array(
                        'type'        => 'image',
                        'name'        => 'item_image',
                        'label'       => esc_html__( 'Item Image', 'backpacktraveler-core' ),
                    ),
                    array(
                        'type'        => 'text',
                        'name'        => 'item_text',
                        'label'       => esc_html__( 'Item Text', 'backpacktraveler-core' )
                    ),
                    array(
                        'type'        => 'text',
                        'name'        => 'item_url',
                        'label'       => esc_html__( 'Enter Full URL for Item Text Link', 'backpacktraveler-core' )
                    ),
                    array(
                        'type'        => 'text',
                        'name'        => 'item_url_class',
                        'label'       => esc_html__( 'Enter Custom Class if needed for Item Text Link', 'backpacktraveler-core' )
                    )
                )
            )
        );
	}
	
	add_action( 'backpacktraveler_mikado_action_meta_boxes_map', 'backpacktraveler_core_map_destination_meta', 40 );
}