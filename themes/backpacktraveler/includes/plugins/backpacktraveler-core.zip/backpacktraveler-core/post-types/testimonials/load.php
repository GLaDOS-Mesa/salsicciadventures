<?php

include_once BACKPACKTRAVELER_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once BACKPACKTRAVELER_CORE_CPT_PATH . '/testimonials/helper-functions.php';