<div <?php backpacktraveler_mikado_class_attribute($holder_classes); ?>>
	<div class="mkdf-bl-content">
        <div class="mkdf-bl-content-left">
                <span class="mkdf-bl-bullet" <?php backpacktraveler_mikado_inline_style($bullet_styles); ?>></span>
        </div>
        <div class="mkdf-bl-content-right">
            <?php if(!empty($title)) { ?>
                <span class="mkdf-iwt-title" <?php backpacktraveler_mikado_inline_style($title_styles); ?>>
                    <?php echo esc_html($title); ?>
                </span>
            <?php } ?>
        </div>
	</div>
</div>