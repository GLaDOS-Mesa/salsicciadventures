<?php
namespace BackpackTravelerCore\CPT\Shortcodes\BulletedList;

use BackpackTravelerCore\Lib;

class BulletedList implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'mkdf_bulleted_list';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Bulleted List', 'backpacktraveler-core' ),
					'base'                      => $this->base,
					'icon'                      => 'icon-wpb-bulleted-list extended-custom-icon',
					'category'                  => esc_html__( 'by BACKPACKTRAVELER', 'backpacktraveler-core' ),
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
							array(
								'type'        => 'textfield',
								'param_name'  => 'custom_class',
								'heading'     => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
								'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
							),
                            array(
                                'type'        => 'dropdown',
                                'param_name'  => 'bullet_type',
                                'heading'     => esc_html__( 'Bullet Type', 'backpacktraveler-core' ),
                                'value'       => array(
                                    esc_html__( 'Square', 'backpacktraveler-core' )  => 'square',
                                    esc_html__( 'Circle', 'backpacktraveler-core' ) => 'circle',
                                ),
                                'save_always' => true
                            ),
							array(
								'type'       => 'colorpicker',
								'param_name' => 'bullet_color',
								'heading'    => esc_html__( 'Bullet Color', 'backpacktraveler-core' ),
							),
							array(
								'type'       => 'textfield',
								'param_name' => 'title',
								'heading'    => esc_html__( 'Title', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'colorpicker',
								'param_name' => 'title_color',
								'heading'    => esc_html__( 'Title Color', 'backpacktraveler-core' ),
								'dependency' => array( 'element' => 'title', 'not_empty' => true ),
							),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$default_atts = array(
			'custom_class'                => '',
			'bullet_type'                      => '',
			'bullet_color'                  => '',
			'title'                       => '',
			'title_color'                 => '',
		);

		$params       = shortcode_atts( $default_atts, $atts );

		$params['holder_classes']  = $this->getHolderClasses( $params );
		$params['bullet_styles']    = $this->getBulletStyles( $params );
		$params['title_styles']    = $this->getTitleStyles( $params );

		return backpacktraveler_core_get_shortcode_module_template_part( 'templates/bulleted-list', 'bulleted-list', '', $params );
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array( 'mkdf-bulleted-list', 'clearfix' );

		$holderClasses[] = 'mkdf-bl-bullets-'.$params['bullet_type'];
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

		return $holderClasses;
	}

    private function getBulletStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['bullet_color'] ) ) {
            $styles[] = 'background-color: ' . $params['bullet_color'];
        }

        return implode( ';', $styles );
    }

	
	private function getTitleStyles( $params ) {
		$styles = array();
		
		if ( ! empty( $params['title_color'] ) ) {
			$styles[] = 'color: ' . $params['title_color'];
		}
		
		return implode( ';', $styles );
	}
}