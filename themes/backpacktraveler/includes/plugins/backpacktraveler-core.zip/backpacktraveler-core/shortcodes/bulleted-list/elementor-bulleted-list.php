<?php

class BackpackTravelerCoreElementorBulletedList extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_bulleted_list';
    }

    public function get_title() {
        return esc_html__( 'Bulleted List', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-bulleted-list';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'bullet_type',
            [
                'label'       => esc_html__( 'Bullet Type', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'square' => esc_html__( 'Square', 'backpacktraveler-core' ),
                    'circle' => esc_html__( 'Circle', 'backpacktraveler-core' ),
                ],
                'default' => 'square'
            ]
        );

        $this->add_control(
            'bullet_color',
            [
                'label'       => esc_html__( 'Bullet Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $default_atts = array(
            'custom_class'                => '',
            'bullet_type'                      => '',
            'bullet_color'                  => '',
            'title'                       => '',
            'title_color'                 => '',
        );

        $params       = shortcode_atts( $default_atts, $params );

        $params['holder_classes']  = $this->getHolderClasses( $params );
        $params['bullet_styles']    = $this->getBulletStyles( $params );
        $params['title_styles']    = $this->getTitleStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/bulleted-list', 'bulleted-list', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array( 'mkdf-bulleted-list', 'clearfix' );

        $holderClasses[] = 'mkdf-bl-bullets-'.$params['bullet_type'];

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

        return $holderClasses;
    }

    private function getBulletStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['bullet_color'] ) ) {
            $styles[] = 'background-color: ' . $params['bullet_color'];
        }

        return implode( ';', $styles );
    }


    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorBulletedList() );
