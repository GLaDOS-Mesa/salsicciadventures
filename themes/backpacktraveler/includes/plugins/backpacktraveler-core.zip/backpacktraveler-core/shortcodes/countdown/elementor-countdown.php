<?php

class BackpackTravelerCoreElementorCountdown extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_countdown';
    }

    public function get_title() {
        return esc_html__( 'Countdown', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-countdown';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'skin',
            [
                'label'   => esc_html__( 'Skin', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    ''                 => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'mkdf-light-skin' => esc_html__( 'Light', 'backpacktraveler-core' )
                ],
            ]
        );

        $this->add_control(
            'year',
            [
                'label'   => esc_html__( 'Year', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '2021' => esc_html__( '2021', 'backpacktraveler-core' ),
                    '2022' => esc_html__( '2022', 'backpacktraveler-core' ),
					'2023' => esc_html__( '2023', 'backpacktraveler-core' ),
					'2024' => esc_html__( '2024', 'backpacktraveler-core' ),
					'2025' => esc_html__( '2025', 'backpacktraveler-core' ),
					'2026' => esc_html__( '2026', 'backpacktraveler-core' ),
					'2027' => esc_html__( '2027', 'backpacktraveler-core' ),
					'2028' => esc_html__( '2028', 'backpacktraveler-core' ),
					'2029' => esc_html__( '2029', 'backpacktraveler-core' ),
					'2030' => esc_html__( '2030', 'backpacktraveler-core' ),
                ],
            ]
        );

        $this->add_control(
            'month',
            [
                'label'   => esc_html__( 'Month', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__( 'January', 'backpacktraveler-core' ),
                    '2'  => esc_html__( 'February', 'backpacktraveler-core' ),
                    '3'  => esc_html__( 'March', 'backpacktraveler-core' ),
                    '4'  => esc_html__( 'April', 'backpacktraveler-core' ),
                    '5'  => esc_html__( 'May', 'backpacktraveler-core' ),
                    '6'  => esc_html__( 'June', 'backpacktraveler-core' ),
                    '7'  => esc_html__( 'July', 'backpacktraveler-core' ),
                    '8'  => esc_html__( 'August', 'backpacktraveler-core' ),
                    '9'  => esc_html__( 'September', 'backpacktraveler-core' ),
                    '10' => esc_html__( 'October', 'backpacktraveler-core' ),
                    '11' => esc_html__( 'November', 'backpacktraveler-core' ),
                    '12' => esc_html__( 'December', 'backpacktraveler-core' ),
                ],
            ]
        );

        $this->add_control(
            'day',
            [
                'label'   => esc_html__( 'Day', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__( '1', 'backpacktraveler-core' ),
                    '2'  => esc_html__( '2', 'backpacktraveler-core' ),
                    '3'  => esc_html__( '3', 'backpacktraveler-core' ),
                    '4'  => esc_html__( '4', 'backpacktraveler-core' ),
                    '5'  => esc_html__( '5', 'backpacktraveler-core' ),
                    '6'  => esc_html__( '6', 'backpacktraveler-core' ),
                    '7'  => esc_html__( '7', 'backpacktraveler-core' ),
                    '8'  => esc_html__( '8', 'backpacktraveler-core' ),
                    '9'  => esc_html__( '9', 'backpacktraveler-core' ),
                    '10' => esc_html__( '10', 'backpacktraveler-core' ),
                    '11' => esc_html__( '11', 'backpacktraveler-core' ),
                    '12' => esc_html__( '12', 'backpacktraveler-core' ),
                    '13' => esc_html__( '13', 'backpacktraveler-core' ),
                    '14' => esc_html__( '14', 'backpacktraveler-core' ),
                    '15' => esc_html__( '15', 'backpacktraveler-core' ),
                    '16' => esc_html__( '16', 'backpacktraveler-core' ),
                    '17' => esc_html__( '17', 'backpacktraveler-core' ),
                    '18' => esc_html__( '18', 'backpacktraveler-core' ),
                    '19' => esc_html__( '19', 'backpacktraveler-core' ),
                    '20' => esc_html__( '20', 'backpacktraveler-core' ),
                    '21' => esc_html__( '21', 'backpacktraveler-core' ),
                    '22' => esc_html__( '22', 'backpacktraveler-core' ),
                    '23' => esc_html__( '23', 'backpacktraveler-core' ),
                    '24' => esc_html__( '24', 'backpacktraveler-core' ),
                    '25' => esc_html__( '25', 'backpacktraveler-core' ),
                    '26' => esc_html__( '26', 'backpacktraveler-core' ),
                    '27' => esc_html__( '27', 'backpacktraveler-core' ),
                    '28' => esc_html__( '28', 'backpacktraveler-core' ),
                    '29' => esc_html__( '29', 'backpacktraveler-core' ),
                    '30' => esc_html__( '30', 'backpacktraveler-core' ),
                    '31' => esc_html__( '31', 'backpacktraveler-core' ),
                ],
            ]
        );

        $this->add_control(
            'hour',
            [
                'label'   => esc_html__( 'Hour', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__( '1', 'backpacktraveler-core' ),
                    '2'  => esc_html__( '2', 'backpacktraveler-core' ),
                    '3'  => esc_html__( '3', 'backpacktraveler-core' ),
                    '4'  => esc_html__( '4', 'backpacktraveler-core' ),
                    '5'  => esc_html__( '5', 'backpacktraveler-core' ),
                    '6'  => esc_html__( '6', 'backpacktraveler-core' ),
                    '7'  => esc_html__( '7', 'backpacktraveler-core' ),
                    '8'  => esc_html__( '8', 'backpacktraveler-core' ),
                    '9'  => esc_html__( '9', 'backpacktraveler-core' ),
                    '10' => esc_html__( '10', 'backpacktraveler-core' ),
                    '11' => esc_html__( '11', 'backpacktraveler-core' ),
                    '12' => esc_html__( '12', 'backpacktraveler-core' ),
                    '13' => esc_html__( '13', 'backpacktraveler-core' ),
                    '14' => esc_html__( '14', 'backpacktraveler-core' ),
                    '15' => esc_html__( '15', 'backpacktraveler-core' ),
                    '16' => esc_html__( '16', 'backpacktraveler-core' ),
                    '17' => esc_html__( '17', 'backpacktraveler-core' ),
                    '18' => esc_html__( '18', 'backpacktraveler-core' ),
                    '19' => esc_html__( '19', 'backpacktraveler-core' ),
                    '20' => esc_html__( '20', 'backpacktraveler-core' ),
                    '21' => esc_html__( '21', 'backpacktraveler-core' ),
                    '22' => esc_html__( '22', 'backpacktraveler-core' ),
                    '23' => esc_html__( '23', 'backpacktraveler-core' ),
                    '24' => esc_html__( '24', 'backpacktraveler-core' )
                ],
            ]
        );

        $this->add_control(
            'minute',
            [
                'label'   => esc_html__( 'Minute', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1'  => esc_html__( '1', 'backpacktraveler-core' ),
                    '2'  => esc_html__( '2', 'backpacktraveler-core' ),
                    '3'  => esc_html__( '3', 'backpacktraveler-core' ),
                    '4'  => esc_html__( '4', 'backpacktraveler-core' ),
                    '5'  => esc_html__( '5', 'backpacktraveler-core' ),
                    '6'  => esc_html__( '6', 'backpacktraveler-core' ),
                    '7'  => esc_html__( '7', 'backpacktraveler-core' ),
                    '8'  => esc_html__( '8', 'backpacktraveler-core' ),
                    '9'  => esc_html__( '9', 'backpacktraveler-core' ),
                    '10' => esc_html__( '10', 'backpacktraveler-core' ),
                    '11' => esc_html__( '11', 'backpacktraveler-core' ),
                    '12' => esc_html__( '12', 'backpacktraveler-core' ),
                    '13' => esc_html__( '13', 'backpacktraveler-core' ),
                    '14' => esc_html__( '14', 'backpacktraveler-core' ),
                    '15' => esc_html__( '15', 'backpacktraveler-core' ),
                    '16' => esc_html__( '16', 'backpacktraveler-core' ),
                    '17' => esc_html__( '17', 'backpacktraveler-core' ),
                    '18' => esc_html__( '18', 'backpacktraveler-core' ),
                    '19' => esc_html__( '19', 'backpacktraveler-core' ),
                    '20' => esc_html__( '20', 'backpacktraveler-core' ),
                    '21' => esc_html__( '21', 'backpacktraveler-core' ),
                    '22' => esc_html__( '22', 'backpacktraveler-core' ),
                    '23' => esc_html__( '23', 'backpacktraveler-core' ),
                    '24' => esc_html__( '24', 'backpacktraveler-core' ),
                    '25' => esc_html__( '25', 'backpacktraveler-core' ),
                    '26' => esc_html__( '26', 'backpacktraveler-core' ),
                    '27' => esc_html__( '27', 'backpacktraveler-core' ),
                    '28' => esc_html__( '28', 'backpacktraveler-core' ),
                    '29' => esc_html__( '29', 'backpacktraveler-core' ),
                    '30' => esc_html__( '30', 'backpacktraveler-core' ),
                    '31' => esc_html__( '31', 'backpacktraveler-core' ),
                    '32' => esc_html__( '32', 'backpacktraveler-core' ),
                    '33' => esc_html__( '33', 'backpacktraveler-core' ),
                    '34' => esc_html__( '34', 'backpacktraveler-core' ),
                    '35' => esc_html__( '35', 'backpacktraveler-core' ),
                    '36' => esc_html__( '36', 'backpacktraveler-core' ),
                    '37' => esc_html__( '37', 'backpacktraveler-core' ),
                    '38' => esc_html__( '38', 'backpacktraveler-core' ),
                    '39' => esc_html__( '39', 'backpacktraveler-core' ),
                    '40' => esc_html__( '40', 'backpacktraveler-core' ),
                    '41' => esc_html__( '41', 'backpacktraveler-core' ),
                    '42' => esc_html__( '42', 'backpacktraveler-core' ),
                    '43' => esc_html__( '43', 'backpacktraveler-core' ),
                    '44' => esc_html__( '44', 'backpacktraveler-core' ),
                    '45' => esc_html__( '45', 'backpacktraveler-core' ),
                    '46' => esc_html__( '46', 'backpacktraveler-core' ),
                    '47' => esc_html__( '47', 'backpacktraveler-core' ),
                    '48' => esc_html__( '48', 'backpacktraveler-core' ),
                    '49' => esc_html__( '49', 'backpacktraveler-core' ),
                    '50' => esc_html__( '50', 'backpacktraveler-core' ),
                    '51' => esc_html__( '51', 'backpacktraveler-core' ),
                    '52' => esc_html__( '52', 'backpacktraveler-core' ),
                    '53' => esc_html__( '53', 'backpacktraveler-core' ),
                    '54' => esc_html__( '54', 'backpacktraveler-core' ),
                    '55' => esc_html__( '55', 'backpacktraveler-core' ),
                    '56' => esc_html__( '56', 'backpacktraveler-core' ),
                    '57' => esc_html__( '57', 'backpacktraveler-core' ),
                    '58' => esc_html__( '58', 'backpacktraveler-core' ),
                    '59' => esc_html__( '59', 'backpacktraveler-core' ),
                    '60' => esc_html__( '60', 'backpacktraveler-core' ),
                ]
            ]
        );

        $this->add_control(
            'month_label',
            [
                'label' => esc_html__( 'Month Label', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Month', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'day_label',
            [
                'label' => esc_html__( 'Day Label', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Day', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'hour_label',
            [
                'label' => esc_html__( 'Hour Label', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Hour', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'minute_label',
            [
                'label' => esc_html__( 'Minute Label', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Minute', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'second_label',
            [
                'label' => esc_html__( 'Second Label', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Seconds', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'digit_font_size',
            [
                'label' => esc_html__( 'Digit Font Size (px)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'label_font_size',
            [
                'label' => esc_html__( 'Label Font Size (px)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'custom_class'    => '',
            'skin'            => '',
            'year'            => '',
            'month'           => '',
            'day'             => '',
            'hour'            => '',
            'minute'          => '',
            'month_label'     => 'Months',
            'day_label'       => 'Days',
            'hour_label'      => 'Hours',
            'minute_label'    => 'Minutes',
            'second_label'    => 'Seconds',
            'digit_font_size' => '',
            'label_font_size' => ''
        );

        $params['id']             = mt_rand( 1000, 9999 );
        $params['holder_classes'] = $this->getHolderClasses( $params );
        $params['holder_data']    = $this->getHolderData( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/countdown', 'countdown', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = ! empty( $params['skin'] ) ? $params['skin'] : '';

        return implode( ' ', $holderClasses );
    }

    private function getHolderData( $params ) {
        $holderData = array();

        $holderData['data-year']         = ! empty( $params['year'] ) ? $params['year'] : '';
        $holderData['data-month']        = ! empty( $params['month'] ) ? $params['month'] : '';
        $holderData['data-day']          = ! empty( $params['day'] ) ? $params['day'] : '';
        $holderData['data-hour']         = $params['hour'] !== '' ? $params['hour'] : '';
        $holderData['data-minute']       = $params['minute'] !== '' ? $params['minute'] : '';
        $holderData['data-month-label']  = ! empty( $params['month_label'] ) ? $params['month_label'] : esc_html__( 'Months', 'backpacktraveler-core' );
        $holderData['data-day-label']    = ! empty( $params['day_label'] ) ? $params['day_label'] : esc_html__( 'Days', 'backpacktraveler-core' );
        $holderData['data-hour-label']   = ! empty( $params['hour_label'] ) ? $params['hour_label'] : esc_html__( 'Hours', 'backpacktraveler-core' );
        $holderData['data-minute-label'] = ! empty( $params['minute_label'] ) ? $params['minute_label'] : esc_html__( 'Minutes', 'backpacktraveler-core' );
        $holderData['data-second-label'] = ! empty( $params['second_label'] ) ? $params['second_label'] : esc_html__( 'Seconds', 'backpacktraveler-core' );
        $holderData['data-digit-size']   = ! empty( $params['digit_font_size'] ) ? $params['digit_font_size'] : '';
        $holderData['data-label-size']   = ! empty( $params['label_font_size'] ) ? $params['label_font_size'] : '';

        return $holderData;
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorCountdown() );