<?php

class BackpackTravelerCoreElementorFullScreenImageSlider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_full_screen_image_slider';
    }

    public function get_title() {
        return esc_html__( 'Full Screen Image Slider', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-full-screen-image-slider';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'slider_speed',
            [
                'label'       => esc_html__( 'Slide Duration', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Default value is 5000 (ms)', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'slider_speed_animation',
            [
                'label'       => esc_html__( 'Slide Animation Duration', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'slider_navigation',
            [
                'label'       => esc_html__( 'Enable Slider Navigation Arrows', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default'     => 'yes'
            ]
        );

        $this->add_control(
            'slider_pagination',
            [
                'label'       => esc_html__( 'Enable Slider Pagination', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default'     => 'yes'
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $repeater->add_control(
            'background_image',
            [
                'label'       => esc_html__( 'Background Image', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_top',
            [
                'label'       => esc_html__( 'Content Image Top', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_left',
            [
                'label'       => esc_html__( 'Content Image Left', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_right',
            [
                'label'       => esc_html__( 'Content Image Right', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label'       => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $repeater->add_control(
            'title_tag',
            [
                'label'       => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_title_tag( true ),
                'condition'   => [
                    'title!' => ''
                ],
                'default' => 'h1'
            ]
        );

        $repeater->add_control(
            'title_color',
            [
                'label'       => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'condition'   => [
                    'title!' => ''
                ]
            ]
        );

        $repeater->add_control(
            'subtitle',
            [
                'label'       => esc_html__( 'Subitle', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $repeater->add_control(
            'subtitle_tag',
            [
                'label'       => esc_html__( 'Subtitle Tag', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_title_tag( true ),
                'condition'   => [
                    'subtitle!' => ''
                ],
                'default' => 'h1'
            ]
        );

        $repeater->add_control(
            'subtitle_color',
            [
                'label'       => esc_html__( 'Subtitle Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'condition'   => [
                    'subtitle!' => ''
                ]
            ]
        );

        $this->add_control(
            'fss_items',
            [
                'label'       => esc_html__( 'Full Screen Slider Items', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Full Screen Slider Item' ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'custom_class'            => '',
            'slider_speed'            => '6000',
            'slider_speed_animation'  => '1000',
            'slider_navigation'       => 'yes',
            'slider_pagination'       => 'yes'
        );

        $params['holder_classes'] = $this->getHolderClasses( $params );
        $params['slider_data']    = $this->getSliderData( $params, $args );
        extract($params);

        ?>

        <div class="mkdf-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
            <div class="mkdf-fsis-slider mkdf-owl-slider" <?php echo backpacktraveler_mikado_get_inline_attrs($slider_data); ?>>
                <?php foreach ( $fss_items as $fss_item ) {
                    $args = array(
                        'custom_class'     => '',
                        'background_image' => '',
                        'image_top'        => '',
                        'image_left'       => '',
                        'image_right'      => '',
                        'title'            => '',
                        'title_tag'        => 'h1',
                        'title_color'      => '',
                        'subtitle'         => '',
                        'subtitle_tag'     => 'h5',
                        'subtitle_color'   => ''
                    );
                    $fss_item = shortcode_atts( $args, $fss_item );
                    
                    if( ! empty( $fss_item['background_image'] ) ){
                        $fss_item['background_image'] = $fss_item['background_image']['id'];
                    }

                    if( ! empty( $fss_item['image_top'] ) ){
                        $fss_item['image_top'] = $fss_item['image_top']['id'];
                    }

                    if( ! empty( $fss_item['image_left'] ) ){
                        $fss_item['image_left'] = $fss_item['image_left']['id'];
                    }

                    if( ! empty( $fss_item['image_right'] ) ){
                        $fss_item['image_right'] = $fss_item['image_right']['id'];
                    }

                    $fss_item['holder_classes'] = $this->getItemHolderClasses( $fss_item );
                    $fss_item['image_styles']   = $this->getImageStyles( $fss_item );
                    $fss_item['title_tag']      = ! empty( $fss_item['title_tag'] ) ? $fss_item['title_tag'] : $args['title_tag'];
                    $fss_item['title_styles']   = $this->getTitleStyles( $fss_item );
                    $fss_item['subtitle_tag']      = ! empty( $fss_item['subtitle_tag'] ) ? $fss_item['subtitle_tag'] : $args['subtitle_tag'];
                    $fss_item['subtitle_styles']   = $this->getSubitleStyles( $fss_item );

                    echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/full-screen-image-slider-item', 'full-screen-image-slider', '', $fss_item );
                } ?>
            </div>
            <div class="mkdf-fsis-thumb-nav mkdf-fsis-prev-nav"></div>
            <div class="mkdf-fsis-thumb-nav mkdf-fsis-next-nav"></div>
            <div class="mkdf-fsis-slider-mask"></div>
        </div>

        <?php
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

        return implode( ' ', $holderClasses );
    }

    private function getSliderData( $params, $args ) {
        $slider_data = array();

        $slider_data['data-number-of-items']             = '1';
        $slider_data['data-enable-loop']                 = 'yes';
        $slider_data['data-enable-autoplay']             = 'yes';
        $slider_data['data-enable-autoplay-hover-pause'] = 'yes';
        $slider_data['data-slider-padding']              = 'no';
        $slider_data['data-slider-speed']                = ! empty( $params['slider_speed'] ) ? $params['slider_speed'] : $args['slider_speed'];
        $slider_data['data-slider-speed-animation']      = ! empty( $params['slider_speed_animation'] ) ? $params['slider_speed_animation'] : $args['slider_speed_animation'];
        $slider_data['data-enable-navigation']           = ! empty( $params['slider_navigation'] ) ? $params['slider_navigation'] : $args['slider_navigation'];
        $slider_data['data-enable-pagination']           = ! empty( $params['slider_pagination'] ) ? $params['slider_pagination'] : $args['slider_pagination'];

        return $slider_data;
    }

    private function getItemHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

        return implode( ' ', $holderClasses );
    }

    private function getImageStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['background_image'] ) ) {
            $styles[] = 'background-image: url(' . wp_get_attachment_url( $params['background_image'] ) . ')';
        }

        return implode( ';', $styles );
    }

    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        return implode( ';', $styles );
    }

    private function getSubitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['subtitle_color'] ) ) {
            $styles[] = 'color: ' . $params['subtitle_color'];
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorFullScreenImageSlider() );