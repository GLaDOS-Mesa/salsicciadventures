<?php

class BackpackTravelerCoreElementorSwappingImageGallery extends \Elementor\Widget_Base{
    public function get_name() {
        return 'mkdf_swapping_image_gallery';
    }

    public function get_title() {
        return esc_html__( 'Swapping Image Gallery', 'bridge-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-swapping-image-gallery';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'bridge-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'title_highlight_words',
            [
                'label' => esc_html__( 'Highlight Words', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter the positions of the words you would like to display in a most dominant color of your theme. Separate the positions with commas (e.g. if you would like the first, second, and third word to have a desired color, you would enter "1,2,3")', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'title_break_words',
            [
                'label' => esc_html__( 'Position of Line Break', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Enter the position of the word after which you would like to create a line break (e.g. if you would like the line break after the 3rd word, you would enter "3")', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__( 'Description', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'gallery_image',
            [
                'label' => esc_html__( 'Main Image', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Select image from media library', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'gallery_image_link',
            [
                'label' => esc_html__( 'Main Image Link', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__( 'Thumbnail', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Select image from media library', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $this->add_control(
            'image_items',
            [
                'label'       => esc_html__( 'Image Items', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Image Item' ),
            ]
        );

        $this->end_controls_section();
    }

    protected function render(){
        $params = $this->get_settings_for_display();

        $params['slider_data']	= $this->getSliderData( $params );
        $params['title']        = $this->getModifiedTitle( $params );

        if( is_array( $params['image_items'] ) && count( $params['image_items'] ) ){
            foreach( $params['image_items'] as $key => $image_item ){
                $params['image_items'][$key]['gallery_image'] = $params['image_items'][$key]['gallery_image']['id'];
                $params['image_items'][$key]['thumbnail'] = $params['image_items'][$key]['thumbnail']['id'];
            }
        }

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/swapping-image-gallery', 'swapping-image-gallery', '', $params );
    }

    private function getModifiedTitle( $params ) {
        $title             = $params['title'];
        $title_highlight_words  = str_replace( ' ', '', $params['title_highlight_words'] );
        $title_break_words = str_replace( ' ', '', $params['title_break_words'] );

        if ( ! empty( $title ) ) {
            $highlight_words  = explode( ',', $title_highlight_words );
            $split_title = explode( ' ', $title );

            if ( ! empty( $title_highlight_words ) ) {
                foreach ( $highlight_words as $value ) {
					$value = intval($value);
                    if ( ! empty( $split_title[ $value - 1 ] ) ) {
                        $split_title[ $value - 1 ] = '<span class="mkdf-st-title-highlight">' . $split_title[ $value - 1 ] . '</span>';
                    }
                }
            }

            if ( ! empty( $title_break_words ) ) {
				$title_break_words = intval($title_break_words);
                if ( ! empty( $split_title[ $title_break_words - 1 ] ) ) {
                    $split_title[ $title_break_words - 1 ] = $split_title[ $title_break_words - 1 ] . '<br />';
                }
            }

            $title = implode( ' ', $split_title );
        }

        return $title;
    }

    private function getSliderData( $params ) {
        $slider_data = array();

        $slider_data['data-slider-animate-in'] 	= 'fadeIn';

        return $slider_data;
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorSwappingImageGallery() );