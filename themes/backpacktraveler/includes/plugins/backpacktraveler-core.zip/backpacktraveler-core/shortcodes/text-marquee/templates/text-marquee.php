<div class="mkdf-text-marquee <?php echo esc_attr( $holder_classes ); ?>" <?php echo backpacktraveler_mikado_inline_style( $text_styles ); ?> <?php echo backpacktraveler_mikado_get_inline_attrs( $text_data ); ?>>
	<span class="mkdf-marquee-element mkdf-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="mkdf-marquee-element mkdf-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  