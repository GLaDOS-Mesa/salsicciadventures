<?php

class BackpackTravelerCoreElementorHorizontalTimeline extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_horizontal_timeline';
    }

    public function get_title() {
        return esc_html__( 'Horizontal Timeline', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-horizontal-timeline';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title',
            [
                'label'       => esc_html__( 'Timeline Event Title', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'subtitle',
            [
                'label'       => esc_html__( 'Timeline Event Subtitle', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'custom_link',
            [
                'label'       => esc_html__( 'Timeline Event Link', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'content_image',
            [
                'label'       => esc_html__( 'Timeline Event Image', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'horizontal_timeline_items',
            [
                'label'       => esc_html__( 'Horizontal Timeline Items', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Horizontal Timeline Item' ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display(); ?>

        <div class="mkdf-horizontal-timeline-wrapper">
            <div class="mkdf-horizontal-timeline">
                <?php
                    foreach ( $params['horizontal_timeline_items'] as $items ) {
                        if( ! empty( $items['content_image'] ) ){
                            $items['content_image'] = $items['content_image']['id'];
                        }

                        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/horizontal-timeline-item', 'horizontal-timeline', '', $items );
                    }
                ?>
            </div>
        </div>

        <?php
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorHorizontalTimeline() );