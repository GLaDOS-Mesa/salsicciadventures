<?php

namespace BackpackTravelerCore\CPT\Shortcodes\HorizontalTimeline;

use BackpackTravelerCore\Lib;

class HorizontalTimelineItem implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'mkdf_horizontal_timeline_item';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'            => esc_html__( 'Horizontal Timeline Item', 'backpacktraveler-core' ),
					'base'            => $this->base,
					'category'        => esc_html__( 'by BACKPACKTRAVELER', 'backpacktraveler-core' ),
                    'as_child'        => array( 'only' => 'mkdf_horizontal_timeline' ),
					'icon'            => 'icon-wpb-horizontal-timeline extended-custom-icon',
                    'as_parent'               => array( 'except' => 'vc_row' ),
                    'show_settings_on_create' => true,
                    'params'                  => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'title',
							'heading'     => esc_html__( 'Timeline Event Title', 'backpacktraveler-core' ),
						),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'subtitle',
                            'heading'     => esc_html__( 'Timeline Event Subtitle', 'backpacktraveler-core' ),
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'custom_link',
							'heading'    => esc_html__( 'Timeline Event Link', 'backpacktraveler-core' ),
						),
						array(
							'type'       => 'attach_image',
							'param_name' => 'content_image',
							'heading'    => esc_html__( 'Timeline Event Image', 'backpacktraveler-core' )
						)
					)
				)
			);
		}
	}

	public function render( $atts, $content = null ) {
		$args = array(
			'title'         => '',
			'subtitle'      => '',
			'custom_link'   => '#',
			'content_image' => ''
		);
		$params       = shortcode_atts( $args, $atts );
		
		$params['holder_classes'] = $this->getHolderClasses( $params );
		$params['content']        = $content;
		
		$html = backpacktraveler_core_get_shortcode_module_template_part( 'templates/horizontal-timeline-item', 'horizontal-timeline', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['content_image'] ) ? 'mkdf-timeline-has-image' : 'mkdf-timeline-no-image';
		
		return implode( ' ', $holderClasses );
	}
}