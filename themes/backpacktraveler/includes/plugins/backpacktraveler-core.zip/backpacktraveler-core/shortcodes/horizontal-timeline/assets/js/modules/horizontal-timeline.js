(function ($) {
	'use strict';
	
	var timeline = {};
	mkdf.modules.timeline = timeline;
	
	timeline.mkdfInitHorizontalTimeline = mkdfInitHorizontalTimeline;
	timeline.mkdfInitElementorHorizontalTimeline = mkdfInitElementorHorizontalTimeline;

	
	timeline.mkdfOnDocumentReady = mkdfOnDocumentReady;
	
	$(document).ready(mkdfOnDocumentReady);
	$(window).on('load',mkdfOnWindowLoad);

	/*
	 ** All functions to be called on $(window).load() should be in this function
	 */
	function mkdfOnDocumentReady() {
		mkdfInitHorizontalTimeline();
	}

	function mkdfOnWindowLoad() {
		mkdfInitElementorHorizontalTimeline();
	}
	
	function mkdfInitHorizontalTimeline() {
		var timelines = $('.mkdf-horizontal-timeline');

		timelines.each(function () {
			var timeline = $(this),
				children = $(this).find('.mkdf-ht-content-item'),
				childrenLength  = $(this).find('.mkdf-ht-content-item').length,
				itemDelayCounter = 0,
				timelineWidth = childrenLength * 423,
				thisDraggableWrapper = timeline.parent(),
				draggableOffset = thisDraggableWrapper.offset(),
				box = {
					x1: draggableOffset.left + (thisDraggableWrapper.outerWidth() - timelineWidth),
					y1: draggableOffset.top + (thisDraggableWrapper.outerHeight() - timeline.outerHeight()),
					x2: draggableOffset.left,
					y2: draggableOffset.top
				};

			timeline.draggable({
				containment: [box.x1 + 120, box.y1, box.x2, box.y2 ],
				axis: "x"
			});

			timeline.appear(function() {
				$(this).css({'width': timelineWidth, 'transition': childrenLength*1.3 + 's', 'pointer-events': 'none'});
				children.each(function() {
					itemDelayCounter+=0.6;
					$(this).css({'opacity': '1', 'transition': '.5s ' + itemDelayCounter + 's', 'transform': 'translateX(-66px) translateY(0)'});
				});
				
				setTimeout(function() {
					timeline.css({'transition': '', 'pointer-events': 'auto'});
					children.each(function() {
						$(this).css({'transition': ''});
					});
				}, 3500);
			}, {accX: 0, accY: 50});
		});
	}

	function mkdfInitElementorHorizontalTimeline(){
		$(window).on('elementor/frontend/init', function () {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/mkdf_horizontal_timeline.default', function() {
				mkdfInitHorizontalTimeline();
			} );
		});
	}
	
})(jQuery);