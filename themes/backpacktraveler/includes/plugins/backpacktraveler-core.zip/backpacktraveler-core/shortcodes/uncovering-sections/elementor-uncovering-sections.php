<?php

class BackpackTravelerCoreElementorUncoveringSections extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_uncovering_sections';
    }

    public function get_title() {
        return esc_html__( 'Uncovering Sections', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-uncovering-sections';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'custom_class',
            [
                'label' => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $repeater->add_control(
            'background_color',
            [
                'label' => esc_html__( 'Background Color', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::COLOR,
            ]
        );

        $repeater->add_control(
            'background_image',
            [
                'label' => esc_html__('Background Image', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'background_position',
            [
                'label' => esc_html__( 'Background Image Position', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Please insert position in format horizontal vertical position, example - center center', 'backpacktraveler-core' ),
            ]
        );

        $repeater->add_control(
            'background_size',
            [
                'label' => esc_html__( 'Background Image Size', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'cover' => esc_html__( 'Cover', 'backpacktraveler-core' ),
                    'contain' => esc_html__( 'Contain', 'backpacktraveler-core' ),
                    'inherit' => esc_html__( 'Inherit', 'backpacktraveler-core' ),
                ],
                'default' => 'cover'
            ]
        );

        $repeater->add_control(
            'padding',
            [
                'label' => esc_html__( 'Content Padding', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Please insert padding in format top right bottom left. You can use px or %', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT
            ]
        );

        $repeater->add_control(
            'vertical_alignment',
            [
                'label' => esc_html__( 'Content Vertical Alignment', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'top' => esc_html__( 'Top', 'backpacktraveler-core' ),
                    'middle' => esc_html__( 'Middle', 'backpacktraveler-core' ),
                    'bottom' => esc_html__( 'Bottom', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'horizontal_alignment',
            [
                'label' => esc_html__( 'Content Horizontal Alignment', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'left' => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'center' => esc_html__( 'Center', 'backpacktraveler-core' ),
                    'right' => esc_html__( 'Right', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Set custom link around item', 'backpacktraveler-core' )
            ]
        );

        $repeater->add_control(
            'link_target',
            [
                'label' => esc_html__( 'Custom Link Target', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_link_target_array(),
                'default' => '_blank',
                'condition' => [
                    'link!' => ''
                ]
            ]
        );

        $repeater->add_control(
            'header_skin',
            [
                'label' => esc_html__( 'Header and Navigation Skin', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Choose a predefined header style for header elements and for full screen sections navigation/pagination', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'light' => esc_html__( 'Light', 'backpacktraveler-core' ),
                    'dark' => esc_html__( 'Dark', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'image_laptop',
            [
                'label' => esc_html__('Background Image for Laptops', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_tablet',
            [
                'label' => esc_html__('Background Image for Tablets - Landscape', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_tablet_portrait',
            [
                'label' => esc_html__('Background Image for Tablets - Portrait', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_mobile',
            [
                'label' => esc_html__('Background Image for Mobiles', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        backpacktraveler_core_generate_elementor_templates_control( $repeater );

        $this->add_control(
            'uss_items',
            [
                'label'       => esc_html__( 'Uncovering Screen Section Items', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Uncovering Screen Section Item' ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        extract( $params );
        ?>

        <div class="mkdf-uncovering-sections">
            <ul class="mkdf-us-wrapper curtains" data-image-holder-name=".mkdf-uss-image-holder" data-fade-element-name=".mkdf-fss-shadow">
                <?php foreach ($uss_items as $uss_item) {
                    $rand_class = 'mkdf-fss-custom-' . mt_rand(100000, 1000000);

                    if( ! empty( $uss_item['background_image'] ) ){
                        $uss_item['background_image'] = $uss_item['background_image']['id'];
                    }

                    if( ! empty( $uss_item['image_laptop'] ) ){
                        $uss_item['image_laptop'] = $uss_item['image_laptop']['id'];
                    }

                    if( ! empty( $uss_item['image_tablet'] ) ){
                        $uss_item['image_tablet'] = $uss_item['image_tablet']['id'];
                    }

                    if( ! empty( $uss_item['image_tablet_portrait'] ) ){
                        $uss_item['image_tablet_portrait'] = $uss_item['image_tablet_portrait']['id'];
                    }

                    if( ! empty( $uss_item['image_mobile'] ) ){
                        $uss_item['image_mobile'] = $uss_item['image_mobile']['id'];
                    }

                    $uss_item['holder_unique_class'] = $rand_class;
                    $uss_item['holder_classes'] = $this->getItemHolderClasses($uss_item);
                    $uss_item['holder_data'] = $this->getItemHolderData($uss_item);
                    $uss_item['holder_styles'] = $this->getItemHolderStyles($uss_item);
                    $uss_item['item_inner_styles'] = $this->getItemInnerStyles($uss_item);
                    $uss_item['link_target'] = !empty($uss_item['link_target']) ? $uss_item['link_target'] : '_self';

                    $uss_item['content'] = Elementor\Plugin::instance()->frontend->get_builder_content_for_display($uss_item['template_id']);

                    echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/full-screen-sections-item', 'full-screen-sections', '', $uss_item );

                } ?>
            </ul>
            <div class="mkdf-fss-shadow"></div>
        </div>
        <?php
    }

    private function getItemHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = ! empty( $params['holder_unique_class'] ) ? $params['holder_unique_class'] : '';
        $holderClasses[] = ! empty( $params['vertical_alignment'] ) ? 'mkdf-uss-item-va-' . $params['vertical_alignment'] : '';
        $holderClasses[] = ! empty( $params['horizontal_alignment'] ) ? 'mkdf-uss-item-ha-' . $params['horizontal_alignment'] : '';
        $holderClasses[] = ! empty( $params['link'] ) ? 'mkdf-uss-item-has-link' : '';
        $holderClasses[] = ! empty( $params['header_skin'] ) ? 'mkdf-uss-item-has-style' : '';

        return implode( ' ', $holderClasses );
    }

    private function getItemHolderData( $params ) {
        $data                    = array();
        $data['data-item-class'] = $params['holder_unique_class'];

        if ( ! empty( $params['header_skin'] ) ) {
            $data['data-header-style'] = $params['header_skin'];
        }

        return $data;
    }

    private function getItemImageData( $params ) {
        $data                    = array();

        if ( ! empty( $params['image_laptop'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_laptop'], 'full' );
            $data['data-laptop-image'] = $image[0];
        }

        if ( ! empty( $params['image_tablet'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_tablet'], 'full' );
            $data['data-tablet-image'] = $image[0];
        }

        if ( ! empty( $params['image_tablet_portrait'] ) ) {
            $image                              = wp_get_attachment_image_src( $params['image_tablet_portrait'], 'full' );
            $data['data-tablet-portrait-image'] = $image[0];
        }

        if ( ! empty( $params['image_mobile'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_mobile'], 'full' );
            $data['data-mobile-image'] = $image[0];
        }

        return $data;
    }

    private function getItemHolderStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['background_color'] ) ) {
            $styles[] = 'background-color: ' . $params['background_color'];
        }

        if ( ! empty( $params['background_image'] ) ) {
            $styles[] = 'background-image: url(' . wp_get_attachment_url( $params['background_image'] ) . ')';

            if ( ! empty( $params['background_position'] ) ) {
                $styles[] = 'background-position:' . $params['background_position'];
            }

            if ( ! empty( $params['background_size'] ) ) {
                $styles[] = 'background-size:' . $params['background_size'];
            }
        }

        return implode( ';', $styles );
    }

    private function getItemInnerStyles( $params ) {
        $styles = array();

        if ( $params['padding'] !== '' ) {
            $styles[] = 'padding: ' . $params['padding'];
        }

        return implode( ';', $styles );
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorFullScreenSections() );