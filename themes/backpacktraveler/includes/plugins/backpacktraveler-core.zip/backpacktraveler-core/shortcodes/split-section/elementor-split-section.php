<?php

class BackpackTravelerCoreElementorSplitSection extends \Elementor\Widget_Base{
    public function get_name() {
        return 'mkdf_split_section';
    }

    public function get_title() {
        return esc_html__( 'Split Section', 'bridge-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-split-section';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'bridge-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Image', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'image_position',
            [
                'label' => esc_html__( 'Image Position', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'right' => esc_html__( 'Right', 'backpacktraveler-core' ),
                ],
                'default' => 'left'
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => esc_html__( 'Content Background Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_title_tag( true ),
                'default' => 'h2',
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'text_tag',
            [
                'label' => esc_html__( 'Text Tag', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_title_tag( true, array( 'p' => 'p' ) ),
                'default' => 'h5',
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => esc_html__( 'Text Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'text!' => ''
                ]
            ]
        );

        $this->add_control(
            'text_top_margin',
            [
                'label' => esc_html__( 'Text Top Margin (px or %)', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => esc_html__( 'Button Text', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'breakpoint',
            [
                'label' => esc_html__( 'Responsive Breakpoint', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Never', 'backpacktraveler-core' ),
                    '1366' => esc_html__( 'Below 1366px', 'backpacktraveler-core' ),
                    '1024' => esc_html__( 'Below 1024px', 'backpacktraveler-core' ),
                    '768' => esc_html__( 'Below 768px', 'backpacktraveler-core' ),
                    '680' => esc_html__( 'Below 680px', 'backpacktraveler-core' ),
                    '480' => esc_html__( 'Below 480px', 'backpacktraveler-core' ),
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__( 'Button Styles', 'bridge-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_type',
            [
                'label' => esc_html__( 'Button Type', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'solid' => esc_html__( 'Solid', 'backpacktraveler-core' ),
                    'outline' => esc_html__( 'Outline', 'backpacktraveler-core' ),
                    'simple' => esc_html__( 'Text', 'backpacktraveler-core' ),
                ],
                'default' => 'outline',
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_size',
            [
                'label' => esc_html__( 'Button Size', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'small' => esc_html__( 'Small', 'backpacktraveler-core' ),
                    'medium' => esc_html__( 'Medium', 'backpacktraveler-core' ),
                    'large' => esc_html__( 'Large', 'backpacktraveler-core' ),
                    'huge' => esc_html__( 'Huge', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => esc_html__( 'Button Link', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_target',
            [
                'label' => esc_html__( 'Button Link Target', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_link_target_array(),
                'default' => '_self',
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => esc_html__( 'Button Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => esc_html__( 'Button Hover Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => esc_html__( 'Button Background Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => esc_html__( 'Button Hover Background Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label' => esc_html__( 'Button Border Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => esc_html__( 'Button Hover Border Color', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->add_control(
            'button_top_margin',
            [
                'label' => esc_html__( 'Button Top Margin (px or %)', 'backpacktraveler-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'button_text!' => ''
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function render(){
        $params = $this->get_settings_for_display();

        $default_atts = array(
            'image'                         => '',
            'image_position'                => 'left',
            'content_background'            => '',
            'title'                         => '',
            'title_tag'                     => 'h2',
            'title_color'                   => '',
            'text'                          => '',
            'text_tag'                      => 'h5',
            'text_color'                    => '',
            'text_top_margin'               => '',
            'button_text'                   => '',
            'button_type'                   => 'outline',
            'button_size'                   => 'normal',
            'button_link'                   => '',
            'button_target'                 => '_self',
            'button_color'                  => '',
            'button_hover_color'            => '',
            'button_background_color'       => '',
            'button_hover_background_color' => '',
            'button_border_color'           => '',
            'button_hover_border_color'     => '',
            'button_top_margin'             => '',
            'breakpoint'                    => ''
        );

        $params       = shortcode_atts( $default_atts, $params );

        if( ! empty( $params['image'] ) ){
            $params['image'] = $params['image']['id'];
        }

        $params['holder_classes'] = $this->getHolderClasses( $params );
        $params['content_style']  = $this->getContentStyles( $params );
        $params['image_styles']   = $this->getImageBackgroundStyles( $params );
        $params['title_tag']      = ! empty( $params['title_tag'] ) ? $params['title_tag'] : $default_atts['title_tag'];
        $params['title_styles']   = $this->getTitleStyles( $params );
        $params['text_tag']       = ! empty( $params['text_tag'] ) ? $params['text_tag'] : $default_atts['text_tag'];
        $params['text_styles']    = $this->getTextStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/split-section', 'split-section', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = 'mkdf-ss-image-' . $params['image_position'];
        $holderClasses[] = ! empty( $params['breakpoint'] ) ? 'mkdf-ss-break-' . $params['breakpoint'] : '';

        return implode( ' ', $holderClasses );
    }

    private function getImageBackgroundStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['image'] ) ) {
            $image_src = wp_get_attachment_image_src( $params['image'], 'full' );

            if ( is_array( $image_src ) ) {
                $image_src = $image_src[0];
            }

            $styles[] = 'background-image: url(' . $image_src . ')';
        }

        return implode( ';', $styles );
    }

    private function getContentStyles($params) {
        $styles   = array();

        if(!empty($params['content_background'])) {
            $styles[] = 'background-color:'. $params['content_background'];
        }

        return implode( ';', $styles );
    }

    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        return implode( ';', $styles );
    }

    private function getTextStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['text_color'] ) ) {
            $styles[] = 'color: ' . $params['text_color'];
        }

        if ( $params['text_top_margin'] !== '' ) {
            if ( backpacktraveler_mikado_string_ends_with( $params['text_top_margin'], '%' ) || backpacktraveler_mikado_string_ends_with( $params['text_top_margin'], 'px' ) ) {
                $styles[] = 'margin-top: ' . $params['width'];
            } else {
                $styles[] = 'margin-top: ' . $params['text_top_margin'] . 'px';
            }
        }

        return implode( ';', $styles );
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorSplitSection() );