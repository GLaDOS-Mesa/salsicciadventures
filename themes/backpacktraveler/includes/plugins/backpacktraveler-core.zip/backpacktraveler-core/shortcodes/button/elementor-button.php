<?php

class BackpackTravelerCoreElementorButton extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_button';
    }

    public function get_title() {
        return esc_html__( 'Button', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-button';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'type',
            [
                'label'   => esc_html__( 'Type', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'solid'   => esc_html__( 'Solid', 'backpacktraveler-core' ),
                    'outline' => esc_html__( 'Outline', 'backpacktraveler-core' ),
                    'simple'  => esc_html__( 'Simple', 'backpacktraveler-core' ),
                    'circle'  => esc_html__( 'Circle', 'backpacktraveler-core' )
                ],
            ]
        );

        $this->add_control(
            'break_button_text',
            [
                'label'   => esc_html__( 'Break Words in Button Text', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'condition' => [
                    'type' => array( 'circle' )
                ]
            ]
        );

        $this->add_control(
            'size',
            [
                'label'     => esc_html__( 'Size', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => [
                    ''       => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'small'  => esc_html__( 'Small', 'backpacktraveler-core' ),
                    'medium' => esc_html__( 'Medium', 'backpacktraveler-core' ),
                    'large'  => esc_html__( 'Large', 'backpacktraveler-core' ),
                    'huge'   => esc_html__( 'Huge', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'solid', 'outline' )
                ],
            ]
        );

        $this->add_control(
            'text',
            [
                'label'       => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'target',
            [
                'label'   => esc_html__( 'Link Target', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_link_target_array(),
            ]
        );

        backpacktraveler_mikado_icon_collections()->getElementorParamsArray( $this, '', '' );

        $this->end_controls_section();

        $this->start_controls_section(
            'design_options',
            [
                'label' => esc_html__( 'Design Options', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'color',
            [
                'label' => esc_html__( 'Color', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::COLOR,
            ]
        );

        $this->add_control(
            'hover_color',
            [
                'label'     => esc_html__( 'Hover Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label'     => esc_html__( 'Background Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'type' => array( 'solid' )
                ],
            ]
        );

        $this->add_control(
            'hover_background_color',
            [
                'label'     => esc_html__( 'Hover Background Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'type' => array( 'solid', 'outline' )
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label'     => esc_html__( 'Border Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'type' => array( 'solid', 'outline' )
                ],
            ]
        );

        $this->add_control(
            'hover_border_color',
            [
                'label'     => esc_html__( 'Hover Border Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'type' => array( 'solid', 'outline' )
                ],
            ]
        );

        $this->add_control(
            'margin',
            [
                'label'       => esc_html__( 'Margin', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Insert margin in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'padding',
            [
                'label'       => esc_html__( 'Button Padding', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'condition'   => [
                    'type' => array( 'solid', 'outline' )
                ],
                'description' => esc_html__( 'Insert padding in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'backpacktraveler-core' ),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'additional_options',
            [
                'label' => esc_html__( 'Additional Options', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'font_size',
            [
                'label' => esc_html__( 'Font Size (px)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'font_weight',
            [
                'label'   => esc_html__( 'Font Weight', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_font_weight_array( true ),
            ]
        );

        $this->add_control(
            'text_transform',
            [
                'label'   => esc_html__( 'Text Transform', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_text_transform_array( true ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $default_atts = array(
            'size'                   => '',
            'type'                   => 'solid',
            'break_button_text'      => 'yes',
            'text'                   => '',
            'link'                   => '',
            'target'                 => '_self',
            'color'                  => '',
            'hover_color'            => '',
            'background_color'       => '',
            'hover_background_color' => '',
            'border_color'           => '',
            'hover_border_color'     => '',
            'font_size'              => '',
            'font_weight'            => '',
            'text_transform'         => '',
            'margin'                 => '',
            'padding'                => '',
            'custom_class'           => '',
            'html_type'              => 'anchor',
            'input_name'             => '',
            'custom_attrs'           => array()
        );

        if ( ! isset ( $params['html_type'] ) ) {
            $params['html_type'] = $default_atts['html_type'];
        }

        if ( $params['html_type'] !== 'input' ) {
            $iconPackName   = backpacktraveler_mikado_icon_collections()->getIconCollectionParamNameByKey( $params['icon_pack'] );
            $params['icon'] = $iconPackName ? $params[ $iconPackName ] : '';
        }

        if ( $params['type'] === 'circle' ) {
            $params['html_type'] = 'circle';
        }

        $iconPackName = backpacktraveler_mikado_icon_collections()->getIconCollectionParamNameByKey( $params['icon_pack'] );

        $params['icon']                         = !isset($params[ $iconPackName ]);
        $params['size'] = ! empty( $params['size'] ) ? $params['size'] : 'medium';
        $params['type'] = ! empty( $params['type'] ) ? $params['type'] : 'solid';

        $params['link']   = ! empty( $params['link'] ) ? $params['link'] : '#';
        $params['target'] = ! empty( $params['target'] ) ? $params['target'] : $default_atts['target'];

        $params['button_classes']      = $this->getButtonClasses( $params );
        $params['button_custom_attrs'] = ! empty( $params['custom_attrs'] ) ? $params['custom_attrs'] : array();
        $params['button_styles']       = $this->getButtonStyles( $params );
        $params['button_data']         = $this->getButtonDataAttr( $params );
        $params['button_text_classes'] = $this->getButtonTextClasses( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/' . $params['html_type'], 'button', '', $params );
    }

    public function getButtonTextClasses( $params ) {
        $classes = array();

        if ( $params['break_button_text'] === 'yes' ) {
            $classes[] = 'mkdf-btn-circle-break-lines';
        }

        return implode( ';', $classes );
    }

    private function getButtonStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['color'] ) ) {
            $styles[] = 'color: ' . $params['color'];
        }

        if ( ! empty( $params['background_color'] ) && $params['type'] !== 'outline' ) {
            $styles[] = 'background-color: ' . $params['background_color'];
        }

        if ( ! empty( $params['border_color'] ) ) {
            $styles[] = 'border-color: ' . $params['border_color'];
        }

        if ( ! empty( $params['font_size'] ) ) {
            $styles[] = 'font-size: ' . backpacktraveler_mikado_filter_px( $params['font_size'] ) . 'px';
        }

        if ( ! empty( $params['font_weight'] ) && $params['font_weight'] !== '' ) {
            $styles[] = 'font-weight: ' . $params['font_weight'];
        }

        if ( ! empty( $params['text_transform'] ) ) {
            $styles[] = 'text-transform: ' . $params['text_transform'];
        }

        if ( $params['margin'] !== '' ) {
            $styles[] = 'margin: ' . $params['margin'];
        }

        if ( $params['padding'] !== '' ) {
            $styles[] = 'padding: ' . $params['padding'];
        }

        return $styles;
    }

    private function getButtonDataAttr( $params ) {
        $data = array();

        $data['data-move'] = 'strict';

        if ( ! empty( $params['hover_color'] ) ) {
            $data['data-hover-color'] = $params['hover_color'];
        }

        if ( ! empty( $params['hover_background_color'] ) ) {
            $data['data-hover-bg-color'] = $params['hover_background_color'];
        }

        if ( ! empty( $params['hover_border_color'] ) ) {
            $data['data-hover-border-color'] = $params['hover_border_color'];
        }

        if ( ! empty( $params['text'] ) ) {
            $data['data-text'] = $params['text'];
        }

        return $data;
    }

    private function getButtonClasses( $params ) {
        $buttonClasses = array(
            'mkdf-btn',
            'mkdf-btn-' . $params['size'],
            'mkdf-btn-' . $params['type']
        );

        if ( ! empty( $params['hover_background_color'] ) ) {
            $buttonClasses[] = 'mkdf-btn-custom-hover-bg';
        }

        if ( ! empty( $params['hover_border_color'] ) ) {
            $buttonClasses[] = 'mkdf-btn-custom-border-hover';
        }

        if ( ! empty( $params['hover_color'] ) ) {
            $buttonClasses[] = 'mkdf-btn-custom-hover-color';
        }

        if ( ! empty( $params['icon'] ) ) {
            $buttonClasses[] = 'mkdf-btn-icon';
        }

        if ( ! empty( $params['custom_class'] ) ) {
            $buttonClasses[] = esc_attr( $params['custom_class'] );
        }

        return $buttonClasses;
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorButton() );
