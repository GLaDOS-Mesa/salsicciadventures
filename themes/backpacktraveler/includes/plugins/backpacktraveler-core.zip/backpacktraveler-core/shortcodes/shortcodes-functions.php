<?php

if ( ! function_exists( 'backpacktraveler_core_include_shortcodes_file' ) ) {
	/**
	 * Loades all shortcodes by going through all folders that are placed directly in shortcodes folder
	 */
	function backpacktraveler_core_include_shortcodes_file() {
		if ( backpacktraveler_core_theme_installed() ) {
			foreach ( glob( BACKPACKTRAVELER_CORE_SHORTCODES_PATH . '/*/load.php' ) as $shortcode ) {
				if ( backpacktraveler_mikado_is_customizer_item_enabled( $shortcode, 'backpacktraveler_performance_disable_shortcode_' ) ) {
					include_once $shortcode;
				}
			}
		}
		
		do_action( 'backpacktraveler_core_action_include_shortcodes_file' );
	}
	
	add_action( 'init', 'backpacktraveler_core_include_shortcodes_file', 6 ); // permission 6 is set to be before vc_before_init hook that has permission 9
}

if ( ! function_exists( 'backpacktraveler_core_load_shortcodes' ) ) {
	function backpacktraveler_core_load_shortcodes() {
		include_once BACKPACKTRAVELER_CORE_ABS_PATH . '/lib/shortcode-loader.php';
		
		BackpackTravelerCore\Lib\ShortcodeLoader::getInstance()->load();
	}
	
	add_action( 'init', 'backpacktraveler_core_load_shortcodes', 7 ); // permission 7 is set to be before vc_before_init hook that has permission 9 and after backpacktraveler_core_include_shortcodes_file hook
}

if ( ! function_exists( 'backpacktraveler_core_add_admin_shortcodes_styles' ) ) {
	/**
	 * Function that includes shortcodes core styles for admin
	 */
	function backpacktraveler_core_add_admin_shortcodes_styles() {
		
		//include shortcode styles for Visual Composer
		wp_enqueue_style( 'backpacktraveler-core-vc-shortcodes', BACKPACKTRAVELER_CORE_ASSETS_URL_PATH . '/css/admin/backpacktraveler-vc-shortcodes.css' );
	}
	
	add_action( 'backpacktraveler_mikado_action_admin_scripts_init', 'backpacktraveler_core_add_admin_shortcodes_styles' );
}

if ( ! function_exists( 'backpacktraveler_core_add_admin_shortcodes_custom_styles' ) ) {
	/**
	 * Function that print custom vc shortcodes style
	 */
	function backpacktraveler_core_add_admin_shortcodes_custom_styles() {
		$style                  = apply_filters( 'backpacktraveler_core_filter_add_vc_shortcodes_custom_style', $style = '' );
		$shortcodes_icon_styles = array();
		$shortcode_icon_size    = 32;
		$shortcode_position     = 0;
		
		$shortcodes_icon_class_array = apply_filters( 'backpacktraveler_core_filter_add_vc_shortcodes_custom_icon_class', $shortcodes_icon_class_array = array() );
        $shortcodes_icon_exclude_from_vc = apply_filters( 'backpacktraveler_core_filter_exclude_vc_shortcodes_custom_icon_class', $shortcodes_icon_exclude_class_array = array() );

        $shortcodes_icon_class_array = array_diff($shortcodes_icon_class_array, $shortcodes_icon_exclude_from_vc);
		sort( $shortcodes_icon_class_array );
		
		if ( ! empty( $shortcodes_icon_class_array ) ) {
			foreach ( $shortcodes_icon_class_array as $shortcode_icon_class ) {
				$mark = $shortcode_position != 0 ? '-' : '';
				
				$shortcodes_icon_styles[] = '.vc_element-icon.extended-custom-icon' . esc_attr( $shortcode_icon_class ) . ' {
					background-position: ' . $mark . esc_attr( $shortcode_position * $shortcode_icon_size ) . 'px 0;
				}';
				
				$shortcode_position ++;
			}
		}
		
		if ( ! empty( $shortcodes_icon_styles ) ) {
			$style .= implode( ' ', $shortcodes_icon_styles );
		}
		
		if ( ! empty( $style ) ) {
			wp_add_inline_style( 'backpacktraveler-core-vc-shortcodes', $style );
		}
	}
	
	add_action( 'backpacktraveler_mikado_action_admin_scripts_init', 'backpacktraveler_core_add_admin_shortcodes_custom_styles' );
}

if( ! function_exists( 'backpacktraveler_core_load_elementor_shortcodes' ) ){
    function backpacktraveler_core_load_elementor_shortcodes(){
        if( backpacktraveler_core_is_elementor_installed() && backpacktraveler_core_is_theme_registered() ) {
            foreach (glob(BACKPACKTRAVELER_CORE_ABS_PATH . '/shortcodes/*/elementor-*.php') as $shortcode_load) {
                include_once $shortcode_load;
            }

            foreach (glob(BACKPACKTRAVELER_CORE_ABS_PATH . '/post-types/*/shortcodes/*/elementor-*.php') as $shortcode_load) {
                include_once $shortcode_load;
            }
        }
    }

    add_action('elementor/widgets/widgets_registered', 'backpacktraveler_core_load_elementor_shortcodes');
}

if( ! function_exists('backpacktraveler_core_add_elementor_widget_categories') ) {
    function backpacktraveler_core_add_elementor_widget_categories($elements_manager) {

        $elements_manager->add_category(
            'backpacktraveler',
            [
                'title' => esc_html__('BACKPACKTRAVELER', 'backpacktraveler-core'),
                'icon' => 'fa fa-plug',
            ]
        );

    }

    add_action('elementor/elements/categories_registered', 'backpacktraveler_core_add_elementor_widget_categories');
};

if ( ! function_exists( 'backpacktraveler_core_return_elementor_templates' ) ) {
    /**
     * Function that returns all Elementor saved templates
     */
    function backpacktraveler_core_return_elementor_templates() {
        return Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
    }
}

if ( ! function_exists( 'backpacktraveler_core_generate_elementor_templates_control' ) ) {
    /**
     * Function that adds Template Elementor Control
     */
    function backpacktraveler_core_generate_elementor_templates_control( $object ) {
        $templates = backpacktraveler_core_return_elementor_templates();

        if ( ! empty( $templates ) ) {
            $options = [
                '0' => '— ' . esc_html__( 'Select', 'backpacktraveler-core' ) . ' —',
            ];

            $types = [];

            foreach ( $templates as $template ) {
                $options[ $template['template_id'] ] = $template['title'] . ' (' . $template['type'] . ')';
                $types[ $template['template_id'] ]   = $template['type'];
            }

            $object->add_control(
                'template_id',
                [
                    'label'       => esc_html__( 'Choose Template', 'backpacktraveler-core' ),
                    'type'        => \Elementor\Controls_Manager::SELECT,
                    'default'     => '0',
                    'options'     => $options,
                    'types'       => $types,
                    'label_block' => 'true'
                ]
            );
        };
    }
}

//function that renders "Anchor" option for section
if( ! function_exists('backpacktraveler_core_render_section_anchor_option') ) {
    function backpacktraveler_core_render_section_anchor_option( $element )   {
        if( 'section' !== $element->get_name() ) {
            return;
        }

        $params = $element->get_settings_for_display();

        if( ! empty( $params['anchor_id'] ) ){
            $element->add_render_attribute( '_wrapper', 'data-mkdf-anchor', $params['anchor_id'] );
        }
    }

    add_action( 'elementor/frontend/section/before_render', 'backpacktraveler_core_render_section_anchor_option');
}

//function that maps "Parallax" option for section
if ( ! function_exists( 'backpacktraveler_core_map_section_parallax_option' ) ) {
    function backpacktraveler_core_map_section_parallax_option( $section, $args ) {
        $section->start_controls_section(
            'section_mikado_parallax',
            [
                'label' => esc_html__( 'Backpack Traveler Parallax', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        $section->add_control(
            'mikado_enable_parallax',
            [
                'label'        => esc_html__( 'Enable Parallax', 'backpacktraveler-core' ),
                'type'         => Elementor\Controls_Manager::SELECT,
                'default'      => 'no',
                'options'      => [
                    'no'     => esc_html__( 'No', 'backpacktraveler-core' ),
                    'holder' => esc_html__( 'Yes', 'backpacktraveler-core' ),
                ],
                'prefix_class' => 'mkdf-parallax-row-'
            ]
        );

        $section->add_control(
            'mikado_parallax_image',
            [
                'label'              => esc_html__( 'Parallax Image', 'backpacktraveler-core' ),
                'type'               => Elementor\Controls_Manager::MEDIA,
                'condition'          => [
                    'mikado_enable_parallax' => 'holder'
                ],
                'frontend_available' => true,
            ]
        );

        $section->add_control(
            'mikado_parallax_speed',
            [
                'label'     => esc_html__( 'Parallax Speed', 'backpacktraveler-core' ),
                'type'      => Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'mikado_enable_parallax' => 'holder'
                ],
                'default'   => '0'
            ]
        );

        $section->add_control(
            'mikado_parallax_height',
            [
                'label'     => esc_html__( 'Parallax Section Height (px)', 'backpacktraveler-core' ),
                'type'      => Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'mikado_enable_parallax' => 'holder'
                ]
            ]
        );

        $section->end_controls_section();
    }

    add_action( 'elementor/element/section/_section_responsive/after_section_end', 'backpacktraveler_core_map_section_parallax_option', 10, 2 );
}

//frontend function for "Parallax"
if ( ! function_exists( 'backpacktraveler_core_render_section_parallax_option' ) ) {
    function backpacktraveler_core_render_section_parallax_option( $element ) {
        if ( 'section' !== $element->get_name() ) {
            return;
        }

        $params = $element->get_settings_for_display();

        if ( ! empty( $params['mikado_parallax_image']['id'] ) ) {
            $parallax_image_src = $params['mikado_parallax_image']['url'];
            $parallax_speed     = ! empty( $params['mikado_parallax_speed'] ) ? $params['mikado_parallax_speed'] : '1';
            $parallax_height    = ! empty( $params['mikado_parallax_height'] ) ? $params['mikado_parallax_height'] : 0;

            $element->add_render_attribute( '_wrapper', 'class', 'mkdf-parallax-row-holder' );
            $element->add_render_attribute( '_wrapper', 'data-parallax-bg-speed', $parallax_speed );
            $element->add_render_attribute( '_wrapper', 'data-parallax-bg-image', $parallax_image_src );
            $element->add_render_attribute( '_wrapper', 'data-parallax-bg-height', $parallax_height );
        }
    }

    add_action( 'elementor/frontend/section/before_render', 'backpacktraveler_core_render_section_parallax_option' );
}

//function that renders helper hidden input for parallax data attribute section
if ( ! function_exists( 'backpacktraveler_core_generate_parallax_helper' ) ) {
    function backpacktraveler_core_generate_parallax_helper( $template, $widget ) {
        if ( 'section' === $widget->get_name() ) {
            $template_preceding = "
            <# if( settings.mikado_enable_parallax == 'holder' ){
		        let parallaxSpeed = settings.mikado_parallax_speed !== '' ? settings.mikado_parallax_speed : '0';
	            let parallaxImage = settings.mikado_parallax_image.url !== '' ? settings.mikado_parallax_image.url : '0';
	            let parallaxHeight = settings.mikado_parallax_height !== '' ? settings.mikado_parallax_height : '0';
	        #>
		        <input type='hidden' class='mkdf-parallax-helper-holder' data-parallax-bg-speed='{{ parallaxSpeed }}' data-parallax-bg-image='{{ parallaxImage }}' data-parallax-bg-height='{{ parallaxHeight }}'/>
		    <# } #>";
            $template           = $template_preceding . " " . $template;
        }

        return $template;
    }

    add_action( 'elementor/section/print_template', 'backpacktraveler_core_generate_parallax_helper', 10, 2 );
}

//function that maps "Content Alignment" option for section
if ( ! function_exists( 'backpacktraveler_core_map_section_content_alignment_option' ) ) {
    function backpacktraveler_core_map_section_content_alignment_option( $section, $args ) {
        $section->start_controls_section(
            'mikado_section_content_alignment',
            [
                'label' => esc_html__( 'Backpack Traveler Content Alignment', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        $section->add_control(
            'mikado_content_alignment',
            [
                'label'        => esc_html__( 'Content Alignment', 'backpacktraveler-core' ),
                'type'         => Elementor\Controls_Manager::SELECT,
                'default'      => 'left',
                'options'      => [
                    'left'   => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'center' => esc_html__( 'Center', 'backpacktraveler-core' ),
                    'right'  => esc_html__( 'Right', 'backpacktraveler-core' )
                ],
                'prefix_class' => 'mkdf-content-aligment-'
            ]
        );

        $section->end_controls_section();
    }

    add_action( 'elementor/element/section/_section_responsive/after_section_end', 'backpacktraveler_core_map_section_content_alignment_option', 10, 2 );
}

//function that maps "Grid" option for section
if ( ! function_exists( 'backpacktraveler_core_map_section_grid_option' ) ) {
    function backpacktraveler_core_map_section_grid_option( $section, $args ) {
        $section->start_controls_section(
            'mikado_section_grid_row',
            [
                'label' => esc_html__( 'Backpack Traveler Grid', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        $section->add_control(
            'mikado_enable_grid_row',
            [
                'label'        => esc_html__( 'Make this row "In Grid"', 'backpacktraveler-core' ),
                'type'         => Elementor\Controls_Manager::SELECT,
                'default'      => 'no',
                'options'      => [
                    'no'      => esc_html__( 'No', 'backpacktraveler-core' ),
                    'section' => esc_html__( 'Yes', 'backpacktraveler-core' ),
                ],
                'prefix_class' => 'mkdf-row-grid-'
            ]
        );

        $section->end_controls_section();
    }

    add_action( 'elementor/element/section/_section_responsive/after_section_end', 'backpacktraveler_core_map_section_grid_option', 10, 2 );
}

//function that maps "Anchor" option for section
if( ! function_exists('backpacktraveler_core_map_section_anchor_option') ){
    function backpacktraveler_core_map_section_anchor_option( $section, $args ){
        $section->start_controls_section(
            'section_qode_anchor',
            [
                'label' => esc_html__( 'Backpack Traveler Anchor', 'backpacktraveler-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        $section->add_control(
            'anchor_id',
            [
                'label'        => esc_html__( 'Backpack Traveler Anchor ID', 'backpacktraveler-core' ),
                'type'         => Elementor\Controls_Manager::TEXT,
            ]
        );

        $section->end_controls_section();
    }

    add_action('elementor/element/section/_section_responsive/after_section_end', 'backpacktraveler_core_map_section_anchor_option', 10, 2);
}

//function that renders "Anchor" option for section
if( ! function_exists('backpacktraveler_core_render_section_anchor_option') ) {
    function backpacktraveler_core_render_section_anchor_option( $element )   {
        if( 'section' !== $element->get_name() ) {
            return;
        }

        $params = $element->get_settings_for_display();

        if( ! empty( $params['anchor_id'] ) ){
            $element->add_render_attribute( '_wrapper', 'data-mkdf-anchor', $params['anchor_id'] );
        }
    }

    add_action( 'elementor/frontend/section/before_render', 'backpacktraveler_core_render_section_anchor_option');
}

if( ! function_exists( 'backpacktraveler_core_remove_widgets_for_elementor') ) {
    function backpacktraveler_core_remove_widgets_for_elementor( $black_list ) {
        //retrieve all widgets created by theme
        $widgets = apply_filters( 'backpacktraveler_core_filter_register_widgets', $widgets = array('BackpackTravelerInstagramWidget', 'BackpackTravelerTwitterWidget') );

        $black_list = array_merge($black_list, $widgets);

        return $black_list;
    }

    add_filter('elementor/widgets/black_list', 'backpacktraveler_core_remove_widgets_for_elementor');
}

if( ! function_exists('backpacktraveler_core_elementor_icons_style') ){
    function backpacktraveler_core_elementor_icons_style(){

        wp_enqueue_style( 'backpacktraveler-core-elementor', BACKPACKTRAVELER_CORE_ASSETS_URL_PATH . '/css/admin/backpacktraveler-elementor.css');

    }

    add_action( 'elementor/editor/before_enqueue_scripts', 'backpacktraveler_core_elementor_icons_style' );
}


if ( ! function_exists( 'backpacktraveler_core_get_elementor_shortcodes_path' ) ) {
    function backpacktraveler_core_get_elementor_shortcodes_path() {
        $shortcodes       = array();
        $shortcodes_paths = array(
            BACKPACKTRAVELER_CORE_SHORTCODES_PATH . '/*' => BACKPACKTRAVELER_CORE_URL_PATH,
            BACKPACKTRAVELER_CORE_CPT_PATH . '/**/shortcodes/*' => BACKPACKTRAVELER_CORE_URL_PATH,
            MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/**/shortcodes/*' => MIKADO_FRAMEWORK_ROOT . '/'
        );

        foreach ( $shortcodes_paths as $dir_path => $url_path ) {
            foreach ( glob( $dir_path, GLOB_ONLYDIR ) as $shortcode_dir_path ) {
                $shortcode_name     = basename( $shortcode_dir_path );
                $shortcode_url_path = $url_path . substr( $shortcode_dir_path, strpos( $shortcode_dir_path, basename( $url_path ) ) + strlen( basename( $url_path ) ) + 1 );

                $shortcodes[ $shortcode_name ] = array(
                    'dir_path' => $shortcode_dir_path,
                    'url_path' => $shortcode_url_path
                );
            }
        }

        return $shortcodes;
    }
}
if ( ! function_exists( 'backpacktraveler_core_add_elementor_shortcodes_custom_styles' ) ) {
    function backpacktraveler_core_add_elementor_shortcodes_custom_styles() {
        $style                  = '';
        $shortcodes_icon_styles = array();

        $shortcodes_icon_class_array = apply_filters( 'backpacktraveler_core_filter_add_vc_shortcodes_custom_icon_class', $shortcodes_icon_class_array = array() );
        sort( $shortcodes_icon_class_array );

        $shortcodes_path = backpacktraveler_core_get_elementor_shortcodes_path();
        if ( ! empty( $shortcodes_icon_class_array ) ) {
            foreach ( $shortcodes_icon_class_array as $shortcode_icon_class ) {
                $shortcode_name = str_replace( '.icon-wpb-', '', esc_attr( $shortcode_icon_class ) );

                if ( key_exists( $shortcode_name, $shortcodes_path ) && file_exists( $shortcodes_path[ $shortcode_name ]['dir_path'] . '/assets/img/dashboard_icon.png' ) ) {
                    $shortcodes_icon_styles[] = '.backpacktraveler-elementor-custom-icon.backpacktraveler-elementor-' . $shortcode_name . ' {
                        background-image: url( "' . $shortcodes_path[ $shortcode_name ]['url_path'] . '/assets/img/dashboard_icon.png" );
                    }';
                }
            }
        }

        if ( ! empty( $shortcodes_icon_styles ) ) {
            $style = implode( ' ', $shortcodes_icon_styles );
        }
        if ( ! empty( $style ) ) {
            wp_add_inline_style( 'backpacktraveler-core-elementor', $style );
        }
    }

    add_action( 'elementor/editor/before_enqueue_scripts', 'backpacktraveler_core_add_elementor_shortcodes_custom_styles', 15 );
}
