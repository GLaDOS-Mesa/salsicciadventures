<?php

if ( backpacktraveler_core_is_elementor_installed() ) {

	if ( ! function_exists( 'backpacktraveler_mikado_get_elementor_instance' ) ) {
		/**
		 * Function that return page builder module instance
		 */
		function backpacktraveler_mikado_get_elementor_instance() {
			return \Elementor\Plugin::instance();
		}
	}

	if ( ! function_exists( 'backpacktraveler_mikado_register_new_elementor_widget' ) ) {
		/**
		 * Function that register a new widget type.
		 *
		 * @param \Elementor\Widget_Base $widget_instance Elementor Widget.
		 */
		function backpacktraveler_mikado_register_new_elementor_widget( $widget_instance ) {
			if ( version_compare( ELEMENTOR_VERSION, '3.5.0', '>' ) ) {
				return backpacktraveler_mikado_get_elementor_instance()->widgets_manager->register( $widget_instance );
			} else {
				return backpacktraveler_mikado_get_elementor_instance()->widgets_manager->register_widget_type( $widget_instance );
			}
		}
	}
}