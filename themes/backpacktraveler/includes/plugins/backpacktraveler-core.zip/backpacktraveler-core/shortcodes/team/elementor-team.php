<?php

class BackpackTravelerCoreElementorTeam extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_team';
    }

    public function get_title() {
        return esc_html__( 'Team', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-team';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'type',
            [
                'label'   => esc_html__( 'Type', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'info-below-image' => esc_html__( 'Info Below Image', 'backpacktraveler-core' ),
                    'info-on-image'    => esc_html__( 'Info On Image Hover', 'backpacktraveler-core' ),
                ],
                'default' => 'info-below-image'
            ]
        );

        $this->add_control(
            'team_image',
            [
                'label' => esc_html__( 'Image', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'team_name',
            [
                'label' => esc_html__( 'Name', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'team_name_tag',
            [
                'label'   => esc_html__( 'Name Tag', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_title_tag( true ),
                'default' => 'h6'
            ]
        );

        $this->add_control(
            'team_name_color',
            [
                'label'     => esc_html__( 'Name Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'team_name!' => ''
                ],
            ]
        );

        $this->add_control(
            'team_position',
            [
                'label' => esc_html__( 'Position', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'team_position_color',
            [
                'label'     => esc_html__( 'Position Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'team_position!' => ''
                ],
            ]
        );

        $this->add_control(
            'team_text',
            [
                'label' => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'team_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'team_text!' => ''
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        backpacktraveler_mikado_icon_collections()->getElementorParamsArray( $repeater, '', '' );

        $repeater->add_control(
            'team_social_icon_link',
            [
                'label' => esc_html__( 'Social Icon Link', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'team_social_icon_target',
            [
                'label'   => esc_html__( 'Social Icon Target', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_link_target_array()
            ]
        );

        $this->add_control(
            'social_icon',
            [
                'label'       => esc_html__( 'Social Icons', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Social Icon' ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args = array(
            'type'                  => 'info-below-image',
            'team_image'            => '',
            'team_name'             => '',
            'team_name_tag'         => 'h6',
            'team_name_color'       => '',
            'team_position'         => '',
            'team_position_color'   => '',
            'team_text'             => '',
            'team_text_color'       => '',
            'team_social_icon_pack' => ''
        );

        if ( ! empty( $params['team_image'] ) ) {
            $params['team_image'] = $params['team_image']['id'];
        }

        $params['type']                 = ! empty( $params['type'] ) ? $params['type'] : $args['type'];
        $params['holder_classes']       = $this->getHolderClasses( $params );
        $params['team_name_tag']        = ! empty( $params['team_name_tag'] ) ? $params['team_name_tag'] : $args['team_name_tag'];
        $params['team_social_icons']    = $this->getTeamSocialIcons( $params );
        $params['team_name_styles']     = $this->getTeamNameStyles( $params );
        $params['team_position_styles'] = $this->getTeamPositionStyles( $params );
        $params['team_text_styles']     = $this->getTeamTextStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/' . $params['type'], 'team', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['type'] ) ? 'mkdf-team-' . $params['type'] : '';

        return implode( ' ', $holderClasses );
    }

    private function getTeamSocialIcons( $params ) {

        $team_social_icons = array();

        if ( $params['social_icon'] !== '' ) {

            foreach ( $params['social_icon'] as $icon ) {

                $iconPackName = backpacktraveler_mikado_icon_collections()->getIconCollectionParamNameByKey( $icon['icon_pack'] );

                $team_icon_params                  = array();
                $team_icon_params['icon_pack']     = $icon['icon_pack'];
                $team_icon_params[ $iconPackName ] = $icon[ $iconPackName ];
                $team_icon_params['link']          = $icon['team_social_icon_link'];
                $team_icon_params['target']        = $icon['team_social_icon_target'];

                $team_social_icons[] = backpacktraveler_mikado_execute_shortcode( 'mkdf_icon', $team_icon_params );
            }
        }

        return $team_social_icons;
    }

    private function getTeamNameStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['team_name_color'] ) ) {
            $styles[] = 'color: ' . $params['team_name_color'];
        }

        return implode( ';', $styles );
    }

    private function getTeamPositionStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['team_position_color'] ) ) {
            $styles[] = 'color: ' . $params['team_position_color'];
        }

        return implode( ';', $styles );
    }

    private function getTeamTextStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['team_text_color'] ) ) {
            $styles[] = 'color: ' . $params['team_text_color'];
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorTeam() );