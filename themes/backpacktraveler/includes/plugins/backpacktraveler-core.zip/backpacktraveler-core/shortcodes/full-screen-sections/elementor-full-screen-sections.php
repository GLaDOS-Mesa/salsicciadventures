<?php

class BackpackTravelerCoreElementorFullScreenSections extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_full_screen_sections';
    }

    public function get_title() {
        return esc_html__( 'Full Screen Sections', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-full-screen-sections';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_continuous_vertical',
            [
                'label'       => esc_html__( 'Enable Continuous Scrolling', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Defines whether scrolling down in the last section or should scroll down to the first one and if scrolling up in the first section should scroll up to the last one', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_yes_no_select_array( false ),
                'deafult'     => 'no'
            ]
        );

        $this->add_control(
            'enable_navigation',
            [
                'label'       => esc_html__( 'Enable Navigation Arrows', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default'     => 'yes'
            ]
        );

        $this->add_control(
            'enable_pagination',
            [
                'label'       => esc_html__( 'Enable Pagination Dots', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => backpacktraveler_mikado_get_yes_no_select_array( false, true ),
                'default'     => 'yes'
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'custom_class',
            [
                'label' => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $repeater->add_control(
            'background_color',
            [
                'label' => esc_html__( 'Background Color', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::COLOR,
            ]
        );

        $repeater->add_control(
            'background_image',
            [
                'label' => esc_html__('Background Image', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'background_position',
            [
                'label' => esc_html__( 'Background Image Position', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Please insert position in format horizontal vertical position, example - center center', 'backpacktraveler-core' ),
            ]
        );

        $repeater->add_control(
            'background_size',
            [
                'label' => esc_html__( 'Background Image Size', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'cover' => esc_html__( 'Cover', 'backpacktraveler-core' ),
                    'contain' => esc_html__( 'Contain', 'backpacktraveler-core' ),
                    'inherit' => esc_html__( 'Inherit', 'backpacktraveler-core' ),
                ],
                'default' => 'cover'
            ]
        );

        $repeater->add_control(
            'padding',
            [
                'label' => esc_html__( 'Content Padding', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Please insert padding in format top right bottom left. You can use px or %', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT
            ]
        );

        $repeater->add_control(
            'vertical_alignment',
            [
                'label' => esc_html__( 'Content Vertical Alignment', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'top' => esc_html__( 'Top', 'backpacktraveler-core' ),
                    'middle' => esc_html__( 'Middle', 'backpacktraveler-core' ),
                    'bottom' => esc_html__( 'Bottom', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'horizontal_alignment',
            [
                'label' => esc_html__( 'Content Horizontal Alignment', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'left' => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'center' => esc_html__( 'Center', 'backpacktraveler-core' ),
                    'right' => esc_html__( 'Right', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Set custom link around item', 'backpacktraveler-core' )
            ]
        );

        $repeater->add_control(
            'link_target',
            [
                'label' => esc_html__( 'Custom Link Target', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_link_target_array(),
                'default' => '_blank',
                'condition' => [
                    'link!' => ''
                ]
            ]
        );

        $repeater->add_control(
            'header_skin',
            [
                'label' => esc_html__( 'Header and Navigation Skin', 'backpacktraveler-core' ),
                'description' => esc_html__( 'Choose a predefined header style for header elements and for full screen sections navigation/pagination', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'light' => esc_html__( 'Light', 'backpacktraveler-core' ),
                    'dark' => esc_html__( 'Dark', 'backpacktraveler-core' ),
                ],
                'default' => ''
            ]
        );

        $repeater->add_control(
            'image_laptop',
            [
                'label' => esc_html__('Background Image for Laptops', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_tablet',
            [
                'label' => esc_html__('Background Image for Tablets - Landscape', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_tablet_portrait',
            [
                'label' => esc_html__('Background Image for Tablets - Portrait', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        $repeater->add_control(
            'image_mobile',
            [
                'label' => esc_html__('Background Image for Mobiles', 'backpacktraveler-core'),
                'type'  => \Elementor\Controls_Manager::MEDIA
            ]
        );

        backpacktraveler_core_generate_elementor_templates_control( $repeater );

        $this->add_control(
            'fss_items',
            [
                'label'       => esc_html__( 'Full Screen Section Items', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => esc_html__( 'Full Screen Section Item' ),
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $params['holder_classes'] = $this->getHolderClasses( $params );
        $params['holder_data']    = $this->getHolderData( $params );
        extract( $params );
        ?>

        <div class="mkdf-full-screen-sections <?php echo esc_attr( $holder_classes ); ?>" <?php echo backpacktraveler_mikado_get_inline_attrs( $holder_data ); ?>>
            <div class="mkdf-fss-wrapper">
                <?php  foreach( $fss_items as $fss_item ){
                    $rand_class = 'mkdf-fss-custom-' . mt_rand(100000,1000000);

                    if( ! empty( $fss_item['background_image'] ) ){
                        $fss_item['background_image'] = $fss_item['background_image']['id'];
                    }

                    if( ! empty( $fss_item['image_laptop'] ) ){
                        $fss_item['image_laptop'] = $fss_item['image_laptop']['id'];
                    }

                    if( ! empty( $fss_item['image_tablet'] ) ){
                        $fss_item['image_tablet'] = $fss_item['image_tablet']['id'];
                    }

                    if( ! empty( $fss_item['image_tablet_portrait'] ) ){
                        $fss_item['image_tablet_portrait'] = $fss_item['image_tablet_portrait']['id'];
                    }

                    if( ! empty( $fss_item['image_mobile'] ) ){
                        $fss_item['image_mobile'] = $fss_item['image_mobile']['id'];
                    }

                    $fss_item['holder_unique_class'] = $rand_class;
                    $fss_item['holder_classes']      = $this->getItemHolderClasses( $fss_item );
                    $fss_item['holder_data']         = $this->getItemHolderData( $fss_item );
                    $fss_item['holder_styles']       = $this->getItemHolderStyles( $fss_item );
                    $fss_item['item_inner_styles']   = $this->getItemInnerStyles( $fss_item );
                    $fss_item['link_target']         = !empty($fss_item['link_target']) ? $fss_item['link_target'] : '_self';

                    $fss_item['content'] = Elementor\Plugin::instance()->frontend->get_builder_content_for_display($fss_item['template_id']);

                    echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/full-screen-sections-item', 'full-screen-sections', '', $fss_item );

                } ?>
            </div>
            <?php if ( $enable_navigation === 'yes' ) { ?>
                <div class="mkdf-fss-nav-holder">
                    <a id="mkdf-fss-nav-up" href="#"><span class='icon-arrows-up'></span></a>
                    <a id="mkdf-fss-nav-down" href="#"><span class='icon-arrows-down'></span></a>
                </div>
            <?php } ?>
        </div>
        <?php
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = $params['enable_navigation'] === 'yes' ? 'mkdf-fss-has-nav' : '';

        return implode( ' ', $holderClasses );
    }

    private function getHolderData( $params ) {
        $data = array();

        if ( ! empty( $params['enable_continuous_vertical'] ) ) {
            $data['data-enable-continuous-vertical'] = $params['enable_continuous_vertical'];
        }

        if ( ! empty( $params['enable_navigation'] ) ) {
            $data['data-enable-navigation'] = $params['enable_navigation'];
        }

        if ( ! empty( $params['enable_pagination'] ) ) {
            $data['data-enable-pagination'] = $params['enable_pagination'];
        }

        return $data;
    }

    private function getItemHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = ! empty( $params['holder_unique_class'] ) ? $params['holder_unique_class'] : '';
        $holderClasses[] = ! empty( $params['vertical_alignment'] ) ? 'mkdf-fss-item-va-' . $params['vertical_alignment'] : '';
        $holderClasses[] = ! empty( $params['horizontal_alignment'] ) ? 'mkdf-fss-item-ha-' . $params['horizontal_alignment'] : '';
        $holderClasses[] = ! empty( $params['link'] ) ? 'mkdf-fss-item-has-link' : '';
        $holderClasses[] = ! empty( $params['header_skin'] ) ? 'mkdf-fss-item-has-style' : '';

        return implode( ' ', $holderClasses );
    }

    private function getItemHolderData( $params ) {
        $data                    = array();
        $data['data-item-class'] = $params['holder_unique_class'];

        if ( ! empty( $params['header_skin'] ) ) {
            $data['data-header-style'] = $params['header_skin'];
        }

        if ( ! empty( $params['image_laptop'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_laptop'], 'full' );
            $data['data-laptop-image'] = $image[0];
        }

        if ( ! empty( $params['image_tablet'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_tablet'], 'full' );
            $data['data-tablet-image'] = $image[0];
        }

        if ( ! empty( $params['image_tablet_portrait'] ) ) {
            $image                              = wp_get_attachment_image_src( $params['image_tablet_portrait'], 'full' );
            $data['data-tablet-portrait-image'] = $image[0];
        }

        if ( ! empty( $params['image_mobile'] ) ) {
            $image                     = wp_get_attachment_image_src( $params['image_mobile'], 'full' );
            $data['data-mobile-image'] = $image[0];
        }

        return $data;
    }

    private function getItemHolderStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['background_color'] ) ) {
            $styles[] = 'background-color: ' . $params['background_color'];
        }

        if ( ! empty( $params['background_image'] ) ) {
            $styles[] = 'background-image: url(' . wp_get_attachment_url( $params['background_image'] ) . ')';

            if ( ! empty( $params['background_position'] ) ) {
                $styles[] = 'background-position:' . $params['background_position'];
            }

            if ( ! empty( $params['background_size'] ) ) {
                $styles[] = 'background-size:' . $params['background_size'];
            }
        }

        return implode( ';', $styles );
    }

    private function getItemInnerStyles( $params ) {
        $styles = array();

        if ( $params['padding'] !== '' ) {
            $styles[] = 'padding: ' . $params['padding'];
        }

        return implode( ';', $styles );
    }
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new BackpackTravelerCoreElementorFullScreenSections() );