<?php

class BackpackTravelerCoreElementorImageWithText extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_image_with_text';
    }

    public function get_title() {
        return esc_html__( 'Image With Text', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-image-with-text';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'image',
            [
                'label'       => esc_html__( 'Image', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::MEDIA,
                'description' => esc_html__( 'Select image from media library', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label'       => esc_html__( 'Image Size', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size', 'backpacktraveler-core' ),
                'default'     => 'full'
            ]

        );

        $this->add_control(
            'enable_image_shadow',
            [
                'label'   => esc_html__( 'Enable Image Shadow', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_yes_no_select_array( false ),
                'default' => 'no'
            ]
        );

        $this->add_control(
            'image_behavior',
            [
                'label'   => esc_html__( 'Image Behavior', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    ''                  => esc_html__( 'None', 'backpacktraveler-core' ),
                    'lightbox'          => esc_html__( 'Open Lightbox', 'backpacktraveler-core' ),
                    'custom-link'       => esc_html__( 'Open Custom Link', 'backpacktraveler-core' ),
                    'zoom'              => esc_html__( 'Zoom', 'backpacktraveler-core' ),
                    'grayscale'         => esc_html__( 'Grayscale', 'backpacktraveler-core' ),
                ],
            ]
        );

        $this->add_control(
            'custom_link',
            [
                'label'     => esc_html__( 'Custom Link', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'image_behavior' => array( 'custom-link' )
                ],
            ]
        );

        $this->add_control(
            'custom_link_target',
            [
                'label'     => esc_html__( 'Custom Link Target', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_link_target_array(),
                'condition' => [
                    'image_behavior' => array( 'custom-link' )
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'     => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_title_tag( true ),
                'condition' => [
                    'title!' => ''
                ],
                'default'   => 'h4'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'title!' => ''
                ],
            ]
        );

        $this->add_control(
            'title_top_margin',
            [
                'label'     => esc_html__( 'Title Top Margin (px)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'title!' => ''
                ],
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => esc_html__( 'Text Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_top_margin',
            [
                'label'     => esc_html__( 'Text Top Margin (px)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'bottom_buttons',
            [
                'label'     => esc_html__( 'Enable bottom double custom link functionality', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_yes_no_select_array( false, false ),
                'default'   => 'no',
                'label_block' => true
            ]
        );

        $this->add_control(
            'bottom_button_one_link',
            [
                'label'     => esc_html__( 'First Bottom Link', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'bottom_buttons' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'bottom_button_one_label',
            [
                'label'     => esc_html__( 'First Bottom Link Label', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'bottom_buttons' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'bottom_button_two_link',
            [
                'label'     => esc_html__( 'Second Bottom Link', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'bottom_buttons' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'bottom_button_two_label',
            [
                'label'     => esc_html__( 'Second Bottom Link Label', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'bottom_buttons' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'custom_class'        => '',
            'image'               => '',
            'image_size'          => 'full',
            'enable_image_shadow' => 'no',
            'image_behavior'      => '',
            'custom_link'         => '',
            'custom_link_target'  => '_self',
            'title'               => '',
            'title_tag'           => 'h4',
            'title_color'         => '',
            'title_top_margin'    => '',
            'text'                => '',
            'text_color'          => '',
            'text_top_margin'     => '',
            'bottom_buttons'      => 'no',
            'bottom_button_one_link' => '',
            'bottom_button_one_label' => '',
            'bottom_button_two_link' => '',
            'bottom_button_two_label' => '',
        );

        $params = shortcode_atts( $args, $params );

        if ( ! empty( $params['image'] ) ) {
            $params['image'] = $params['image']['id'];
        }

        $params['holder_classes']     = $this->getHolderClasses( $params );
        $params['image']              = $this->getImage( $params );
        $params['image_size']         = $this->getImageSize( $params['image_size'] );
        $params['image_behavior']     = ! empty( $params['image_behavior'] ) ? $params['image_behavior'] : $args['image_behavior'];
        $params['custom_link_target'] = ! empty( $params['custom_link_target'] ) ? $params['custom_link_target'] : $args['custom_link_target'];
        $params['title_tag']          = ! empty( $params['title_tag'] ) ? $params['title_tag'] : $args['title_tag'];
        $params['title_styles']       = $this->getTitleStyles( $params );
        $params['text_styles']        = $this->getTextStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/image-with-text', 'image-with-text', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = $params['enable_image_shadow'] === 'yes' ? 'mkdf-has-shadow' : '';
        $holderClasses[] = ! empty( $params['image_behavior'] ) ? 'mkdf-image-behavior-' . $params['image_behavior'] : '';
        $holderClasses[] = $params['bottom_buttons'] === 'yes' ? 'mkdf-has-bottom-buttons' : '';

        return implode( ' ', $holderClasses );
    }

    private function getImage( $params ) {
        $image = array();

        if ( ! empty( $params['image'] ) ) {
            $id = $params['image'];

            $image['image_id'] = $id;
            $image_original    = wp_get_attachment_image_src( $id, 'full' );
            $image['url']      = $image_original[0];
            $image['alt']      = get_post_meta( $id, '_wp_attachment_image_alt', true );
        }

        return $image;
    }

    private function getImageSize( $image_size ) {
        $image_size = trim( $image_size );
        //Find digits
        preg_match_all( '/\d+/', $image_size, $matches );
        if ( in_array( $image_size, array( 'thumbnail', 'thumb', 'medium', 'large', 'full' ) ) ) {
            return $image_size;
        } elseif ( ! empty( $matches[0] ) ) {
            return array(
                $matches[0][0],
                $matches[0][1]
            );
        } else {
            return 'thumbnail';
        }
    }

    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        if ( $params['title_top_margin'] !== '' ) {
            $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $params['title_top_margin'] ) . 'px';
        }

        return implode( ';', $styles );
    }

    private function getTextStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['text_color'] ) ) {
            $styles[] = 'color: ' . $params['text_color'];
        }

        if ( $params['text_top_margin'] !== '' ) {
            $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $params['text_top_margin'] ) . 'px';
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorImageWithText() );