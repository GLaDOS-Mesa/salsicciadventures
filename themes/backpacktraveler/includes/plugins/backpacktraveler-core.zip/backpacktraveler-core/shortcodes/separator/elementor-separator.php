<?php

class BackpackTravelerCoreElementorSeparator extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_separator';
    }

    public function get_title() {
        return esc_html__( 'Separator', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-separator';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'type',
            [
                'label'   => esc_html__( 'Type', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'normal'     => esc_html__( 'Normal', 'backpacktraveler-core' ),
                    'with-text' => esc_html__('With Text', 'backpacktraveler-core'),
                    'full-width' => esc_html__( 'Full Width', 'backpacktraveler-core' )
                ],
            ]
        );

        $this->add_control(
            'text',
            [
                'label'   => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'type' => 'with-text'
                ],
            ]
        );

        $this->add_control(
            'position',
            [
                'label'     => esc_html__( 'Position', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => [
                    'center' => esc_html__( 'Center', 'backpacktraveler-core' ),
                    'left'   => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'right'  => esc_html__( 'Right', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'normal' )
                ],
                'default'   => 'center'
            ]
        );

        $this->add_control(
            'color',
            [
                'label' => esc_html__( 'Color', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::COLOR,
            ]
        );

        $this->add_control(
            'border_style',
            [
                'label'   => esc_html__( 'Style', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    ''       => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'dashed' => esc_html__( 'Dashed', 'backpacktraveler-core' ),
                    'solid'  => esc_html__( 'Solid', 'backpacktraveler-core' ),
                    'dotted' => esc_html__( 'Dotted', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'normal', 'full-width' )
                ]
            ]
        );

        $this->add_control(
            'width',
            [
                'label'     => esc_html__( 'Width (px or %)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'type' => array( 'normal' )
                ],
            ]
        );

        $this->add_control(
            'thickness',
            [
                'label' => esc_html__( 'Thickness (px)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'type' => array( 'normal', 'full-width' )
                ],
            ]
        );

        $this->add_control(
            'top_margin',
            [
                'label' => esc_html__( 'Top Margin (px or %)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'type' => array( 'normal', 'full-width' )
                ],
            ]
        );

        $this->add_control(
            'bottom_margin',
            [
                'label' => esc_html__( 'Bottom Margin (px or %)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'type' => array( 'normal', 'full-width' )
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'text'          => '',
            'custom_class'  => '',
            'type'          => '',
            'position'      => 'center',
            'color'         => '',
            'border_style'  => '',
            'width'         => '',
            'thickness'     => '',
            'top_margin'    => '',
            'bottom_margin' => ''
        );

        $params = shortcode_atts($args, $params);

        $params['holder_classes'] = $this->getHolderClasses( $params );
        $params['holder_styles']  = $this->getHolderStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/separator-template', 'separator', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = ! empty( $params['position'] ) ? 'mkdf-separator-' . $params['position'] : '';
        $holderClasses[] = ! empty( $params['type'] ) ? 'mkdf-separator-' . $params['type'] : '';

        return implode( ' ', $holderClasses );
    }

    private function getHolderStyles( $params ) {
        $styles = array();

        if ( $params['color'] !== '' ) {
            $styles[] = 'border-color: ' . $params['color'];
        }

        if ( $params['border_style'] !== '' ) {
            $styles[] = 'border-style: ' . $params['border_style'];
        }

        if ( $params['width'] !== '' ) {
            if ( backpacktraveler_mikado_string_ends_with( $params['width'], '%' ) || backpacktraveler_mikado_string_ends_with( $params['width'], 'px' ) ) {
                $styles[] = 'width: ' . $params['width'];
            } else {
                $styles[] = 'width: ' . backpacktraveler_mikado_filter_px( $params['width'] ) . 'px';
            }
        }

        if ( $params['thickness'] !== '' ) {
            $styles[] = 'border-bottom-width: ' . backpacktraveler_mikado_filter_px( $params['thickness'] ) . 'px';
        }

        if ( $params['top_margin'] !== '' ) {
            if ( backpacktraveler_mikado_string_ends_with( $params['top_margin'], '%' ) || backpacktraveler_mikado_string_ends_with( $params['top_margin'], 'px' ) ) {
                $styles[] = 'margin-top: ' . $params['top_margin'];
            } else {
                $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $params['top_margin'] ) . 'px';
            }
        }

        if ( $params['bottom_margin'] !== '' ) {
            if ( backpacktraveler_mikado_string_ends_with( $params['bottom_margin'], '%' ) || backpacktraveler_mikado_string_ends_with( $params['bottom_margin'], 'px' ) ) {
                $styles[] = 'margin-bottom: ' . $params['bottom_margin'];
            } else {
                $styles[] = 'margin-bottom: ' . backpacktraveler_mikado_filter_px( $params['bottom_margin'] ) . 'px';
            }
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorSeparator() );