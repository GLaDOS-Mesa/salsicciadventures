<?php
if($type === 'with-text') { ?>
    <div class="mkdf-separator-holder clearfix mkdf-separator-with-text">
        <div class="mkdf-separator" <?php echo backpacktraveler_mikado_get_inline_style($holder_styles); ?>></div>
        <span class="mkdf-separatow-line-left"><span <?php echo backpacktraveler_mikado_get_inline_style($holder_styles); ?>></span></span>
        <h6><?php echo esc_html($text); ?></h6>
        <span class="mkdf-separatow-line-left"><span <?php echo backpacktraveler_mikado_get_inline_style($holder_styles); ?>></span></span>
    </div>
<?php } else { ?>
    <div class="mkdf-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
        <div class="mkdf-separator" <?php echo backpacktraveler_mikado_get_inline_style($holder_styles); ?>></div>
    </div>
<?php } ?>
