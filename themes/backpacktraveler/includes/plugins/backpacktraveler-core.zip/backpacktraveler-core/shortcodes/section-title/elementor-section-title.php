<?php

class BackpackTravelerCoreElementorSectionTitle extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_section_title';
    }

    public function get_title() {
        return esc_html__( 'Section Title', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-section-title';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'type',
            [
                'label'   => esc_html__( 'Type', 'backpacktraveler-core' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'standard'    => esc_html__( 'Standard', 'backpacktraveler-core' ),
                    'two-columns' => esc_html__( 'Two Columns', 'backpacktraveler-core' ),
                ],
                'default'  => 'standard'
            ]
        );

        $this->add_control(
            'title_position',
            [
                'label'     => esc_html__( 'Title - Text Position', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => [
                    'title-left'  => esc_html__( 'Title Left - Text Right', 'backpacktraveler-core' ),
                    'title-right' => esc_html__( 'Title Right - Text Left', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'two-columns' )
                ],
                'default'   => 'title-left'
            ]
        );

        $this->add_control(
            'columns_space',
            [
                'label'     => esc_html__( 'Space Between Columns', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => [
                    'normal' => esc_html__( 'Normal', 'backpacktraveler-core' ),
                    'small'  => esc_html__( 'Small', 'backpacktraveler-core' ),
                    'tiny'   => esc_html__( 'Tiny', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'two-columns' )
                ],
                'default'   => 'normal'
            ]
        );

        $this->add_control(
            'position',
            [
                'label'     => esc_html__( 'Horizontal Position', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => [
                    ''       => esc_html__( 'Default', 'backpacktraveler-core' ),
                    'left'   => esc_html__( 'Left', 'backpacktraveler-core' ),
                    'center' => esc_html__( 'Center', 'backpacktraveler-core' ),
                    'right'  => esc_html__( 'Right', 'backpacktraveler-core' ),
                ],
                'condition' => [
                    'type' => array( 'standard' )
                ],
            ]
        );

        $this->add_control(
            'holder_padding',
            [
                'label' => esc_html__( 'Holder Side Padding (px or %)', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'  => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_options',
            [
                'label' => esc_html__( 'Title Options', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'title!' => ''
                ],
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'     => esc_html__( 'Title Tag', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_title_tag( true ),
                'condition' => [
                    'title!' => ''
                ],
                'default'   => 'h2'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'title!' => ''
                ],
            ]
        );

        $this->add_control(
            'title_bold_words',
            [
                'label'       => esc_html__( 'Words with Bold Font Weight', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'condition'   => [
                    'title!' => ''
                ],
                'description' => esc_html__( 'Enter the positions of the words you would like to display in a "bold" font weight. Separate the positions with commas (e.g. if you would like the first, second, and third word to have a light font weight, you would enter "1,2,3")', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'title_light_words',
            [
                'label'       => esc_html__( 'Words with Light Font Weight', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'condition'   => [
                    'title!' => ''
                ],
                'description' => esc_html__( 'Enter the positions of the words you would like to display in a "light" font weight. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a light font weight, you would enter "1,3,4")', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'title_highlight_words',
            [
                'label'       => esc_html__( 'Highlight Words', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'condition'   => [
                    'title!' => ''
                ],
                'description' => esc_html__( 'Enter the positions of the words you would like to display in a most dominant color of your theme. Separate the positions with commas (e.g. if you would like the first, second, and third word to have a desired color, you would enter "1,2,3")', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'title_break_words',
            [
                'label'       => esc_html__( 'Position of Line Break', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'condition'   => [
                    'title!' => ''
                ],
                'description' => esc_html__( 'Enter the position of the word after which you would like to create a line break (e.g. if you would like the line break after the 3rd word, you would enter "3")', 'backpacktraveler-core' ),
            ]
        );

        $this->add_control(
            'disable_break_words',
            [
                'label'     => esc_html__( 'Disable Line Break for Smaller Screens', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_yes_no_select_array( false ),
                'condition' => [
                    'title!' => ''
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'text_options',
            [
                'label' => esc_html__( 'Text Options', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_tag',
            [
                'label'     => esc_html__( 'Text Tag', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_title_tag( true, array( 'p' => 'p' ) ),
                'condition' => [
                    'text!' => ''
                ],
                'default'   => 'p'
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => esc_html__( 'Text Color', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_font_size',
            [
                'label'     => esc_html__( 'Text Font Size (px)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_line_height',
            [
                'label'     => esc_html__( 'Text Line Height (px)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_font_weight',
            [
                'label'     => esc_html__( 'Text Font Weight', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => backpacktraveler_mikado_get_font_weight_array( true ),
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->add_control(
            'text_margin',
            [
                'label'     => esc_html__( 'Text Top Margin (px)', 'backpacktraveler-core' ),
                'type'      => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'text!' => ''
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'custom_class'        => '',
            'type'                => 'standard',
            'title_position'      => 'title-left',
            'columns_space'       => 'normal',
            'position'            => 'center',
            'holder_padding'      => '',
            'title'               => '',
            'title_tag'           => 'h2',
            'title_color'         => '',
            'title_bold_words'    => '',
            'title_light_words'   => '',
            'title_break_words'   => '',
            'disable_break_words' => '',
            'text'                => '',
            'text_tag'            => 'p',
            'text_color'          => '',
            'text_font_size'      => '18',
            'text_line_height'    => '',
            'text_font_weight'    => '',
            'text_margin'         => '',
            'title_highlight_words' => '',
        );
        $params = shortcode_atts( $args, $params );

        $params['holder_classes'] = $this->getHolderClasses( $params, $args );
        $params['holder_styles']  = $this->getHolderStyles( $params );
        $params['title']          = $this->getModifiedTitle( $params );
        $params['title_tag']      = ! empty( $params['title_tag'] ) ? $params['title_tag'] : $args['title_tag'];
        $params['title_styles']   = $this->getTitleStyles( $params );
        $params['text_tag']       = ! empty( $params['text_tag'] ) ? $params['text_tag'] : $args['text_tag'];
        $params['text_styles']    = $this->getTextStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/section-title', 'section-title', '', $params );
    }

    private function getHolderClasses( $params, $args ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
        $holderClasses[] = ! empty( $params['type'] ) ? 'mkdf-st-' . $params['type'] : 'mkdf-st-' . $args['type'];
        $holderClasses[] = ! empty( $params['title_position'] ) ? 'mkdf-st-' . $params['title_position'] : 'mkdf-st-' . $args['title_position'];
        $holderClasses[] = ! empty( $params['columns_space'] ) ? 'mkdf-st-' . $params['columns_space'] . '-space' : 'mkdf-st-' . $args['columns_space'] . '-space';
        $holderClasses[] = $params['disable_break_words'] === 'yes' ? 'mkdf-st-disable-title-break' : '';

        return implode( ' ', $holderClasses );
    }

    private function getHolderStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['holder_padding'] ) ) {
            $styles[] = 'padding: 0 ' . $params['holder_padding'];
        }

        if ( ! empty( $params['position'] ) ) {
            $styles[] = 'text-align: ' . $params['position'];
        }

        return implode( ';', $styles );
    }

    private function getModifiedTitle( $params ) {
        $title             = $params['title'];
        $title_highlight_words  = str_replace( ' ', '', $params['title_highlight_words'] );
        $title_bold_words  = str_replace( ' ', '', $params['title_bold_words'] );
        $title_light_words = str_replace( ' ', '', $params['title_light_words'] );
        $title_break_words = str_replace( ' ', '', $params['title_break_words'] );

        if ( ! empty( $title ) ) {
            $bold_words  = explode( ',', $title_bold_words );
            $highlight_words  = explode( ',', $title_highlight_words );
            $light_words = explode( ',', $title_light_words );
            $split_title = explode( ' ', $title );

            if ( ! empty( $title_highlight_words ) ) {
                foreach ( $highlight_words as $value ) {
					$value = intval($value);
                    if ( ! empty( $split_title[ $value - 1 ] ) ) {
                        $split_title[ $value - 1 ] = '<span class="mkdf-st-title-highlight">' . $split_title[ $value - 1 ] . '</span>';
                    }
                }
            }

            if ( ! empty( $title_bold_words ) ) {
                foreach ( $bold_words as $value ) {
					$value = intval($value);
                    if ( ! empty( $split_title[ $value - 1 ] ) ) {
                        $split_title[ $value - 1 ] = '<span class="mkdf-st-title-bold">' . $split_title[ $value - 1 ] . '</span>';
                    }
                }
            }

            if ( ! empty( $title_light_words ) ) {
                foreach ( $light_words as $value ) {
					$value = intval($value);
                    if ( ! empty( $split_title[ $value - 1 ] ) ) {
                        $split_title[ $value - 1 ] = '<span class="mkdf-st-title-light">' . $split_title[ $value - 1 ] . '</span>';
                    }
                }
            }

            if ( ! empty( $title_break_words ) ) {
				$title_break_words = intval($title_break_words);
                if ( ! empty( $split_title[ $title_break_words - 1 ] ) ) {
                    $split_title[ $title_break_words - 1 ] = $split_title[ $title_break_words - 1 ] . '<br />';
                }
            }

            $title = implode( ' ', $split_title );
        }

        return $title;
    }

    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        return implode( ';', $styles );
    }

    private function getTextStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['text_color'] ) ) {
            $styles[] = 'color: ' . $params['text_color'];
        }

        if ( ! empty( $params['text_font_size'] ) ) {
            $styles[] = 'font-size: ' . backpacktraveler_mikado_filter_px( $params['text_font_size'] ) . 'px';
        }

        if ( ! empty( $params['text_line_height'] ) ) {
            $styles[] = 'line-height: ' . backpacktraveler_mikado_filter_px( $params['text_line_height'] ) . 'px';
        }

        if ( ! empty( $params['text_font_weight'] ) ) {
            $styles[] = 'font-weight: ' . $params['text_font_weight'];
        }

        if ( $params['text_margin'] !== '' ) {
            $styles[] = 'margin-top: ' . backpacktraveler_mikado_filter_px( $params['text_margin'] ) . 'px';
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorSectionTitle() );