<?php
namespace BackpackTravelerCore\CPT\Shortcodes\NumberedList;

use BackpackTravelerCore\Lib;

class NumberedList implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'mkdf_numbered_list';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Numbered List', 'backpacktraveler-core' ),
					'base'                      => $this->base,
					'icon'                      => 'icon-wpb-numbered-list extended-custom-icon',
					'category'                  => esc_html__( 'by BACKPACKTRAVELER', 'backpacktraveler-core' ),
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
							array(
								'type'        => 'textfield',
								'param_name'  => 'custom_class',
								'heading'     => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
								'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'textfield',
								'param_name' => 'number',
								'heading'    => esc_html__( 'Number', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'colorpicker',
								'param_name' => 'number_color',
								'heading'    => esc_html__( 'Number Color', 'backpacktraveler-core' ),
							),
							array(
								'type'       => 'textfield',
								'param_name' => 'title',
								'heading'    => esc_html__( 'Title', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'colorpicker',
								'param_name' => 'title_color',
								'heading'    => esc_html__( 'Title Color', 'backpacktraveler-core' ),
								'dependency' => array( 'element' => 'title', 'not_empty' => true ),
								'group'      => esc_html__( 'Text Settings', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'textarea',
								'param_name' => 'text',
								'heading'    => esc_html__( 'Text', 'backpacktraveler-core' )
							),
							array(
								'type'       => 'colorpicker',
								'param_name' => 'text_color',
								'heading'    => esc_html__( 'Text Color', 'backpacktraveler-core' ),
								'dependency' => array( 'element' => 'text', 'not_empty' => true ),
								'group'      => esc_html__( 'Text Settings', 'backpacktraveler-core' )
							),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$default_atts = array(
			'custom_class'                => '',
			'number'                      => '',
			'number_color'                  => '',
			'title'                       => '',
			'title_color'                 => '',
			'text'                        => '',
			'text_color'                  => '',
		);

		$params       = shortcode_atts( $default_atts, $atts );

		$params['holder_classes']  = $this->getHolderClasses( $params );
		$params['number_styles']    = $this->getNumberStyles( $params );
		$params['title_styles']    = $this->getTitleStyles( $params );
		$params['text_styles']     = $this->getTextStyles( $params );
		
		return backpacktraveler_core_get_shortcode_module_template_part( 'templates/numbered-list', 'numbered-list', '', $params );
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array( 'mkdf-numbered-list', 'clearfix' );
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

		return $holderClasses;
	}

    private function getNumberStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['number_color'] ) ) {
            $styles[] = 'color: ' . $params['number_color'];
        }

        return implode( ';', $styles );
    }

	
	private function getTitleStyles( $params ) {
		$styles = array();
		
		if ( ! empty( $params['title_color'] ) ) {
			$styles[] = 'color: ' . $params['title_color'];
		}
		
		return implode( ';', $styles );
	}
	
	private function getTextStyles( $params ) {
		$styles = array();
		
		if ( ! empty( $params['text_color'] ) ) {
			$styles[] = 'color: ' . $params['text_color'];
		}
		
		return implode( ';', $styles );
	}
}