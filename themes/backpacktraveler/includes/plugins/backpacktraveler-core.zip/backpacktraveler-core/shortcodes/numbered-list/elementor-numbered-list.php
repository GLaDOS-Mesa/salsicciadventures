<?php

class BackpackTravelerCoreElementorNumberedList extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_numbered_list';
    }

    public function get_title() {
        return esc_html__( 'Numbered List', 'backpacktraveler-core' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-numbered-list';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'custom_class',
            [
                'label'       => esc_html__( 'Custom CSS Class', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'backpacktraveler-core' )
            ]
        );

        $this->add_control(
            'number',
            [
                'label'       => esc_html__( 'Number', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'number_color',
            [
                'label'       => esc_html__( 'Number Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__( 'Title', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'text',
            [
                'label'       => esc_html__( 'Text', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'text_setting',
            [
                'label' => esc_html__( 'Text Settings', 'backpacktraveler-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__( 'Title Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'title!' => ''
                ]
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__( 'Text Color', 'backpacktraveler-core' ),
                'type'        => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'text!' => ''
                ]
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $default_atts = array(
            'custom_class'                => '',
            'number'                      => '',
            'number_color'                  => '',
            'title'                       => '',
            'title_color'                 => '',
            'text'                        => '',
            'text_color'                  => '',
        );

        $params       = shortcode_atts( $default_atts, $params );

        $params['holder_classes']  = $this->getHolderClasses( $params );
        $params['number_styles']    = $this->getNumberStyles( $params );
        $params['title_styles']    = $this->getTitleStyles( $params );
        $params['text_styles']     = $this->getTextStyles( $params );

        echo backpacktraveler_core_get_shortcode_module_template_part( 'templates/numbered-list', 'numbered-list', '', $params );
    }

    private function getHolderClasses( $params ) {
        $holderClasses = array( 'mkdf-numbered-list', 'clearfix' );

        $holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';

        return $holderClasses;
    }

    private function getNumberStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['number_color'] ) ) {
            $styles[] = 'color: ' . $params['number_color'];
        }

        return implode( ';', $styles );
    }


    private function getTitleStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['title_color'] ) ) {
            $styles[] = 'color: ' . $params['title_color'];
        }

        return implode( ';', $styles );
    }

    private function getTextStyles( $params ) {
        $styles = array();

        if ( ! empty( $params['text_color'] ) ) {
            $styles[] = 'color: ' . $params['text_color'];
        }

        return implode( ';', $styles );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerCoreElementorNumberedList() );