<div <?php backpacktraveler_mikado_class_attribute($holder_classes); ?>>
	<div class="mkdf-nl-content">
        <div class="mkdf-nl-content-left">
            <?php if(!empty($number)) { ?>
                <span class="mkdf-nl-number" <?php backpacktraveler_mikado_inline_style($number_styles); ?>><?php echo esc_html($number); ?></span>
            <?php } ?>
        </div>
        <div class="mkdf-nl-content-right">
            <?php if(!empty($title)) { ?>
                <span class="mkdf-iwt-title" <?php backpacktraveler_mikado_inline_style($title_styles); ?>>
                    <?php echo esc_html($title); ?>
                </span>
            <?php } ?>
            <?php if(!empty($text)) { ?>
                <span class="mkdf-iwt-text" <?php backpacktraveler_mikado_inline_style($text_styles); ?>><?php echo esc_html($text); ?></span>
            <?php } ?>
        </div>
	</div>
</div>