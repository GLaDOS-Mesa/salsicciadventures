<?php

include_once BACKPACKTRAVELER_CORE_SHORTCODES_PATH . '/numbered-list/functions.php';
include_once BACKPACKTRAVELER_CORE_SHORTCODES_PATH . '/numbered-list/numbered-list.php';