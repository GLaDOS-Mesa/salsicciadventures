<?php
if ( ! function_exists( 'backpacktraveler_core_dashboard_load_files' ) ) {
	function backpacktraveler_core_dashboard_load_files() {
		require_once BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/core-dashboard.php';
		require_once BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/rest/include.php';
		require_once BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/registration-rest.php';
		require_once BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/theme-validation.php';
		require_once BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/sub-pages/sub-page.php';

		foreach (glob(BACKPACKTRAVELER_CORE_ABS_PATH . '/core-dashboard/sub-pages/*/load.php') as $subpages) {
			include_once $subpages;
		}
	}

	add_action('after_setup_theme', 'backpacktraveler_core_dashboard_load_files', 0);
}