<?php

class BackpackTravelerTwitterTwitterList extends \Elementor\Widget_Base {

    public function get_name() {
        return 'mkdf_twitter_list';
    }

    public function get_title() {
        return esc_html__( 'Twitter List', 'backpacktraveler-twitter-feed' );
    }

    public function get_icon() {
        return 'backpacktraveler-elementor-custom-icon backpacktraveler-elementor-twitter-list';
    }

    public function get_categories() {
        return [ 'backpacktraveler' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'general',
            [
                'label' => esc_html__( 'General', 'backpacktraveler-twitter-feed' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'user_id',
            [
                'label'       => esc_html__( 'User ID', 'backpacktraveler-twitter-feed' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'number_of_columns',
            [
                'label'       => esc_html__( 'Number of Columns', 'backpacktraveler-twitter-feed' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_number_of_columns_array( false, array( 'one' ) ),
                'default' => 'four'
            ]
        );

        $this->add_control(
            'space_between_columns',
            [
                'label'       => esc_html__( 'Space Between Columns', 'backpacktraveler-twitter-feed' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options' => backpacktraveler_mikado_get_space_between_items_array(),
                'default' => 'normal'
            ]
        );

        $this->add_control(
            'number_of_tweets',
            [
                'label'       => esc_html__( 'Number of Tweets', 'backpacktraveler-twitter-feed' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->add_control(
            'transient_time',
            [
                'label'       => esc_html__( 'Tweets Cache Time', 'backpacktraveler-twitter-feed' ),
                'type'        => \Elementor\Controls_Manager::TEXT
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $params = $this->get_settings_for_display();

        $args   = array(
            'user_id'               => '',
            'number_of_columns'     => 'four',
            'space_between_columns' => 'normal',
            'number_of_tweets'      => '',
            'transient_time'        => ''
        );
        $params = shortcode_atts( $args, $params );
        extract( $params );

        $params['holder_classes'] = $this->getHolderClasses( $params, $args );

        $twitter_api           = new \BackpackTravelerTwitterApi();
        $params['twitter_api'] = $twitter_api;

        if ( $twitter_api->hasUserConnected() ) {
            $response = $twitter_api->fetchTweets( $user_id, $number_of_tweets, array(
                'transient_time' => $transient_time,
                'transient_id'   => 'mkdf_twitter_' . rand( 0, 1000 )
            ) );

            $params['response'] = $response;
        }

        //Get HTML from template based on type of team
        echo backpacktraveler_twitter_get_shortcode_module_template_part( 'holder', 'twitter-list', '', $params );
    }

    public function getHolderClasses( $params, $args ) {
        $holderClasses = array();

        $holderClasses[] = ! empty( $params['number_of_columns'] ) ? 'mkdf-' . $params['number_of_columns'] . '-columns' : 'mkdf-' . $args['number_of_columns'] . '-columns';
        $holderClasses[] = ! empty( $params['space_between_columns'] ) ? 'mkdf-' . $params['space_between_columns'] . '-space' : 'mkdf-' . $args['space_between_columns'] . '-space';

        return implode( ' ', $holderClasses );
    }
}

backpacktraveler_mikado_register_new_elementor_widget( new BackpackTravelerTwitterTwitterList() );